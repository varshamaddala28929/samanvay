import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { AuthPage } from './components/auth/AuthPage';
import { Navbar } from './components/Navbar';
import { MobileBottomNav } from './components/MobileBottomNav';
import { LiveDemoModal } from './components/LiveDemoModal';
import { ToastContainer } from './components/ToastContainer';
import { VoiceAssistantModal } from './components/VoiceAssistantModal';
import { DigiLockerModal } from './components/DigiLockerModal';
import { CameraScanModal } from './components/CameraScanModal';
import { ServiceDetailsModal } from './components/citizen/ServiceDetailsModal';
import { SamanvayCoordinationBackground } from './components/SamanvayCoordinationBackground';

// Views
import { CitizenHome } from './components/citizen/CitizenHome';
import { PublicServicesView } from './components/citizen/PublicServicesView';
import { GrievanceWizard } from './components/citizen/GrievanceWizard';
import { ApplicationTracker } from './components/citizen/ApplicationTracker';
import { GrievanceTracker } from './components/citizen/GrievanceTracker';
import { CitizenProfileView } from './components/citizen/CitizenProfileView';
import { OfficerDashboard } from './components/OfficerDashboard';
import { HigherOfficerDashboard } from './components/HigherOfficerDashboard';
import { ShieldCheck, Heart, ExternalLink } from 'lucide-react';

const MainContent: React.FC = () => {
  const { isAuthenticated, isAuthModalOpen, setIsAuthModalOpen, activeRole, activeTab, t } = useApp();

  return (
    <div className="relative min-h-screen flex flex-col bg-slate-50 text-slate-900 font-sans antialiased selection:bg-emerald-200">
      <SamanvayCoordinationBackground />
      {/* Primary Brand Navbar */}
      <div className="relative z-10">
        <Navbar />

        {/* Main Container */}
        <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 lg:px-8 py-4 sm:py-6 lg:py-8 pb-24 md:pb-8">
        {activeRole === 'CITIZEN' && (
          <>
            {activeTab === 'HOME' && <CitizenHome />}
            {activeTab === 'SERVICES' && <PublicServicesView />}
            {activeTab === 'GRIEVANCES' && <GrievanceWizard />}
            {activeTab === 'MY_APPLICATIONS' && (
              isAuthenticated ? (
                <ApplicationTracker />
              ) : (
                <div className="max-w-xl mx-auto py-12 text-center bg-white rounded-3xl border border-slate-200 p-8 shadow-xs">
                  <div className="w-12 h-12 bg-emerald-100 text-emerald-800 rounded-2xl flex items-center justify-center mx-auto mb-4 font-bold text-xl">
                    🔐
                  </div>
                  <h2 className="text-xl font-bold text-slate-900 mb-2">{t('loginToViewApplications', 'Login to View Your Applications')}</h2>
                  <p className="text-sm text-slate-600 mb-6">
                    {t('loginToViewApplicationsDesc', 'Sign in with your mobile number, Citizen ID, or DigiLocker to track and view your submitted applications and certificates.')}
                  </p>
                  <button
                    type="button"
                    onClick={() => setIsAuthModalOpen(true)}
                    className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-sm transition-all shadow-md shadow-emerald-700/20 cursor-pointer"
                  >
                    {t('login')}
                  </button>
                </div>
              )
            )}
            {activeTab === 'MY_GRIEVANCES' && <GrievanceTracker />}
            {activeTab === 'PROFILE' && (
              isAuthenticated ? (
                <CitizenProfileView />
              ) : (
                <div className="max-w-xl mx-auto py-12 text-center bg-white rounded-3xl border border-slate-200 p-8 shadow-xs">
                  <div className="w-12 h-12 bg-emerald-100 text-emerald-800 rounded-2xl flex items-center justify-center mx-auto mb-4 font-bold text-xl">
                    👤
                  </div>
                  <h2 className="text-xl font-bold text-slate-900 mb-2">{t('profileAndDocumentLocker', 'Citizen Profile & Document Locker')}</h2>
                  <p className="text-sm text-slate-600 mb-6">
                    {t('profileLoginPrompt', 'Log in with DigiLocker or create an account to view and manage your verified government identity profile.')}
                  </p>
                  <button
                    type="button"
                    onClick={() => setIsAuthModalOpen(true)}
                    className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-sm transition-all shadow-md shadow-emerald-700/20 cursor-pointer"
                  >
                    {t('login')}
                  </button>
                </div>
              )
            )}
          </>
        )}

        {activeRole === 'OFFICER' && <OfficerDashboard />}

        {activeRole === 'HIGHER_OFFICER' && <HigherOfficerDashboard />}
        </main>

        {/* Mobile Bottom Navigation for Citizen */}
        <MobileBottomNav />

        {/* Global Modals & Controls */}
        {isAuthModalOpen && <AuthPage isModal onClose={() => setIsAuthModalOpen(false)} />}
        <LiveDemoModal />
        <ServiceDetailsModal />
        <DigiLockerModal />
        <CameraScanModal />
        <VoiceAssistantModal />
        <ToastContainer />

        {/* Footer */}
        <footer className="border-t border-slate-200 bg-white py-6 sm:py-8 hidden md:block">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-center md:text-left">
            <div>
              <div className="flex items-center justify-center md:justify-start gap-2">
                <span className="font-extrabold text-slate-900 text-sm tracking-wider">SAMANVAY</span>
                <span className="text-xs text-slate-400">|</span>
                <span className="text-xs text-slate-600 font-medium">{t('platformName', 'Unified Public Services & Grievance Platform')}</span>
              </div>
              <p className="text-xs text-slate-500 mt-1 max-w-md">
                {t('platformQuote', 'The citizen understands their need. Samanvay understands the government structure.')}
              </p>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-3 text-xs text-slate-500">
              <span className="flex items-center gap-1 text-emerald-700 font-semibold">
                <ShieldCheck className="w-4 h-4" />
                <span>{t('interoperabilityLayer', 'Govt Interoperability Layer')}</span>
              </span>
              <span>•</span>
              <span>{t('digiLockerIntegrated', 'DigiLocker Integrated')}</span>
              <span>•</span>
              <span>{t('sevenDayRedressal', '7-Day SLA Redressal')}</span>
            </div>
          </div>
        </div>
        </footer>
      </div>
    </div>
  );
};

export function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}

export default App;

