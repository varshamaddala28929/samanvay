import React, { useState, useEffect, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { Application, Grievance, ApplicationStatus, GrievanceStatus } from '../types';
import {
  ShieldCheck,
  FileText,
  AlertCircle,
  CheckCircle2,
  XCircle,
  Clock,
  Search,
  Filter,
  User,
  MapPin,
  RefreshCw,
  AlertTriangle,
  ChevronRight,
  ArrowLeft,
  Phone,
  Calendar,
  BadgeCheck,
  History,
  Building2,
  Check,
  Sparkles,
  FileCheck,
  Eye,
  SlidersHorizontal,
} from 'lucide-react';
import { api } from '../services/api';

type TabType = 'APPLICATIONS' | 'GRIEVANCES' | 'RECENT_ACTIVITY';
type AppFilter = 'ALL' | 'PENDING' | 'UNDER_VERIFICATION' | 'APPROVED' | 'REJECTED';
type GrvFilter = 'ALL' | 'ACTIVE' | 'IN_PROGRESS' | 'SLA_BREACHED' | 'ESCALATED' | 'RESOLVED';

export const OfficerDashboard: React.FC = () => {
  const {
    currentUser,
    applications,
    grievances,
    documents,
    t,
    refreshAllData,
    addNotification,
    demoDesk,
  } = useApp();

  const [activeTab, setActiveTab] = useState<TabType>('APPLICATIONS');
  const [appFilter, setAppFilter] = useState<AppFilter>('ALL');
  const [grvFilter, setGrvFilter] = useState<GrvFilter>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  // Selected items
  const [selectedAppId, setSelectedAppId] = useState<string | null>(null);
  const [selectedGrvId, setSelectedGrvId] = useState<string | null>(null);

  // Mobile detail view toggle
  const [showMobileDetail, setShowMobileDetail] = useState(false);

  // Officer action inputs
  const [officerRemarks, setOfficerRemarks] = useState('');
  const [benefitAmount, setBenefitAmount] = useState('₹65,000 Tuition Fee Waiver + ₹15,000 Maintenance Grant');
  const [grievanceActionChoice, setGrievanceActionChoice] = useState<'ASSIGNED' | 'IN_PROGRESS' | 'RESOLVED' | 'ESCALATED'>('ASSIGNED');
  const [actionInProgress, setActionInProgress] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  useEffect(() => {
    setActiveTab(demoDesk === 'GRIEVANCES' ? 'GRIEVANCES' : 'APPLICATIONS');
  }, [demoDesk]);

  // Seed / sync selected IDs when data loads or changes
  useEffect(() => {
    if (applications.length > 0) {
      if (!selectedAppId || !applications.some((a) => a.id === selectedAppId)) {
        setSelectedAppId(applications[0].id);
      }
    }
  }, [applications, selectedAppId]);

  useEffect(() => {
    if (grievances.length > 0) {
      if (!selectedGrvId || !grievances.some((g) => g.id === selectedGrvId)) {
        setSelectedGrvId(grievances[0].id);
      }
    }
  }, [grievances, selectedGrvId]);

  // Derived selected objects
  const selectedApp = useMemo(() => {
    return applications.find((a) => a.id === selectedAppId) || applications[0] || null;
  }, [applications, selectedAppId]);

  const selectedGrv = useMemo(() => {
    return grievances.find((g) => g.id === selectedGrvId) || grievances[0] || null;
  }, [grievances, selectedGrvId]);

  // KPI Calculations
  const pendingApps = applications.filter((a) => a.status === 'SUBMITTED' || a.status === 'UNDER_VERIFICATION');
  const underVerificationApps = applications.filter((a) => a.status === 'UNDER_VERIFICATION');
  const activeGrvs = grievances.filter((g) => g.status !== 'RESOLVED');
  const slaBreachedGrvs = grievances.filter((g) => g.isSlaBreached || g.status === 'ESCALATED');

  // Filtered lists
  const filteredApplications = useMemo(() => {
    return applications.filter((app) => {
      // Filter tab
      if (appFilter === 'PENDING') {
        if (app.status !== 'SUBMITTED' && app.status !== 'UNDER_VERIFICATION' && app.status !== 'DOCUMENTS_REQUIRED') return false;
      } else if (appFilter === 'UNDER_VERIFICATION') {
        if (app.status !== 'UNDER_VERIFICATION') return false;
      } else if (appFilter === 'APPROVED') {
        if (app.status !== 'APPROVED' && app.status !== 'BENEFIT_DISBURSED') return false;
      } else if (appFilter === 'REJECTED') {
        if (app.status !== 'REJECTED') return false;
      }

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchId = app.id.toLowerCase().includes(q);
        const matchTitle = app.serviceTitle.toLowerCase().includes(q);
        const matchName = app.citizenName.toLowerCase().includes(q);
        const matchCitId = app.citizenId.toLowerCase().includes(q);
        if (!matchId && !matchTitle && !matchName && !matchCitId) return false;
      }

      return true;
    });
  }, [applications, appFilter, searchQuery]);

  const filteredGrievances = useMemo(() => {
    return grievances.filter((grv) => {
      // Filter tab
      if (grvFilter === 'ACTIVE') {
        if (grv.status === 'RESOLVED') return false;
      } else if (grvFilter === 'IN_PROGRESS') {
        if (grv.status !== 'IN_PROGRESS') return false;
      } else if (grvFilter === 'SLA_BREACHED') {
        if (!grv.isSlaBreached) return false;
      } else if (grvFilter === 'ESCALATED') {
        if (grv.status !== 'ESCALATED' && !grv.isSlaBreached) return false;
      } else if (grvFilter === 'RESOLVED') {
        if (grv.status !== 'RESOLVED') return false;
      }

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchId = grv.id.toLowerCase().includes(q);
        const matchType = grv.issueType.toLowerCase().includes(q);
        const matchCat = grv.category.toLowerCase().includes(q);
        const matchName = grv.citizenName.toLowerCase().includes(q);
        const matchMandal = grv.location.mandal.toLowerCase().includes(q);
        if (!matchId && !matchType && !matchCat && !matchName && !matchMandal) return false;
      }

      return true;
    });
  }, [grievances, grvFilter, searchQuery]);

  // Recent timeline events aggregate
  const recentActivityCases = useMemo(() => {
    const events: Array<{
      id: string;
      caseType: 'APPLICATION' | 'GRIEVANCE';
      title: string;
      citizenName: string;
      status: string;
      timestamp: string;
      remarks: string;
      actor: string;
    }> = [];

    applications.forEach((app) => {
      const latest = app.timeline[app.timeline.length - 1];
      if (latest) {
        events.push({
          id: app.id,
          caseType: 'APPLICATION',
          title: app.serviceTitle,
          citizenName: app.citizenName,
          status: latest.status,
          timestamp: latest.timestamp,
          remarks: latest.remarks || app.officerRemarks || 'Application processed.',
          actor: latest.actor,
        });
      }
    });

    grievances.forEach((grv) => {
      const latest = grv.timeline[grv.timeline.length - 1];
      if (latest) {
        events.push({
          id: grv.id,
          caseType: 'GRIEVANCE',
          title: grv.issueType,
          citizenName: grv.citizenName,
          status: latest.status,
          timestamp: latest.timestamp,
          remarks: latest.remarks || grv.officerRemarks || 'Grievance updated.',
          actor: latest.actor,
        });
      }
    });

    return events.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }, [applications, grievances]);

  // Refresh handler
  const handleRefresh = async () => {
    setIsRefreshing(true);
    await refreshAllData();
    setIsRefreshing(false);
    addNotification('info', 'Workbench Refreshed', 'Latest applications, DigiLocker records, and grievances synchronized.');
  };

  // Application Action Handlers
  const handleUpdateApplication = async (newStatus: ApplicationStatus) => {
    if (!selectedApp) return;
    setActionInProgress(true);

    try {
      let remarks = officerRemarks.trim();
      if (!remarks) {
        if (newStatus === 'APPROVED') {
          remarks = `Eligibility criteria verified against DigiLocker and institutional database. Sanctioned entitlement: ${benefitAmount}.`;
        } else if (newStatus === 'UNDER_VERIFICATION') {
          remarks = 'Under direct scrutiny. Academic marks, income declaration, and domicile certificates verified.';
        } else if (newStatus === 'REJECTED') {
          remarks = 'Application rejected due to incomplete income criteria documentation.';
        } else {
          remarks = `Status updated to ${newStatus}.`;
        }
      }

      await api.updateApplicationStatus(
        selectedApp.id,
        newStatus,
        remarks,
        currentUser.name || 'Officer Ravi Kumar'
      );

      await refreshAllData();
      setActionInProgress(false);
      setOfficerRemarks('');

      const statusLabels: Record<string, string> = {
        APPROVED: 'Approved & Sanctioned',
        UNDER_VERIFICATION: 'Marked Under Verification',
        REJECTED: 'Rejected',
      };

      addNotification(
        'success',
        `Application ${statusLabels[newStatus] || newStatus}`,
        `Application ID: ${selectedApp.id} for ${selectedApp.citizenName} updated. Citizen and Higher Monitoring Authority notified.`
      );
    } catch (err) {
      console.error('App update error:', err);
      setActionInProgress(false);
      addNotification('error', 'Update Failed', 'Could not update application status. Please try again.');
    }
  };

  const handleVerifyAndForwardApplication = async () => {
    if (!selectedApp) return;
    setActionInProgress(true);
    try {
      const remarks = officerRemarks.trim() || 'Documents verified by Officer and forwarded for Higher Officer final approval.';
      await api.updateApplicationStatus(selectedApp.id, 'UNDER_VERIFICATION', remarks, currentUser.name, 'OFFICER');
      await api.escalateApplication(selectedApp.id, remarks, currentUser.name);
      await refreshAllData();
      setOfficerRemarks('');
      addNotification('success', 'Application Verified & Forwarded', `Application ${selectedApp.id} sent to Higher Officer for final approval.`);
    } catch (err) {
      console.error('Application verification error:', err);
      addNotification('error', 'Verification Failed', 'Could not forward the verified application. Please try again.');
    } finally {
      setActionInProgress(false);
    }
  };

  // Grievance Action Handlers
  const handleUpdateGrievance = async () => {
    if (!selectedGrv) return;
    setActionInProgress(true);

    try {
      let remarks = officerRemarks.trim();
      if (!remarks) {
        if (grievanceActionChoice === 'RESOLVED') {
          remarks = 'Field engineering inspection completed. Repair work executed and normal service restored on site.';
        } else if (grievanceActionChoice === 'IN_PROGRESS') {
          remarks = 'Field maintenance team dispatched with required machinery and spare parts.';
        } else if (grievanceActionChoice === 'ESCALATED') {
          remarks = 'Escalated to Higher Monitoring Authority for administrative clearance and central budget sanction.';
        }
      }

      if (grievanceActionChoice === 'ESCALATED') {
        await api.simulateSlaBreach(selectedGrv.id);
      } else {
        await api.updateGrievanceStatus(
          selectedGrv.id,
          grievanceActionChoice,
          remarks,
          currentUser.name || 'Officer Ravi Kumar'
        );
      }

      await refreshAllData();
      setActionInProgress(false);
      setOfficerRemarks('');

      const actionLabels: Record<string, string> = {
        IN_PROGRESS: 'Marked In Progress',
        RESOLVED: 'Marked as Resolved',
        ESCALATED: 'Escalated to Higher Authority',
      };

      addNotification(
        'success',
        `Grievance ${actionLabels[grievanceActionChoice]}`,
        `Grievance ID: ${selectedGrv.id} updated. Citizen timeline and SLA tracking refreshed.`
      );
    } catch (err) {
      console.error('Grv update error:', err);
      setActionInProgress(false);
      addNotification('error', 'Update Failed', 'Could not update grievance status. Please try again.');
    }
  };

  const handleVerifyAndForwardGrievance = async () => {
    if (!selectedGrv) return;
    setActionInProgress(true);
    try {
      await api.updateGrievanceStatus(selectedGrv.id, 'IN_PROGRESS', officerRemarks.trim() || 'Complaint verified by Officer.', currentUser.name);
      await api.forwardGrievance(selectedGrv.id, officerRemarks.trim() || 'Complaint verified and forwarded to Higher Officer.', currentUser.name);
      await refreshAllData();
      setOfficerRemarks('');
      addNotification('success', 'Complaint Verified & Forwarded', `Grievance ${selectedGrv.id} sent to Higher Officer.`);
    } catch (err) {
      console.error('Grievance verification error:', err);
      addNotification('error', 'Forwarding Failed', 'Could not forward the verified complaint. Please try again.');
    } finally {
      setActionInProgress(false);
    }
  };

  // Helper to resolve attached supporting documents safely
  const getAttachedDocuments = (app: Application) => {
    const docIds = app.attachedDocumentIds || [];
    if (docIds.length === 0) {
      return [
        {
          id: 'doc_1',
          title: 'Aadhaar Card (UIDAI Verified)',
          documentNumber: 'XXXX-XXXX-8924',
          issuer: 'UIDAI',
          source: 'DIGILOCKER' as const,
          verified: true,
        },
        {
          id: 'doc_2',
          title: 'Class 12 Intermediate Consolidated Marks Memo (86.4%)',
          documentNumber: 'BIE-AP-2022-849201',
          issuer: 'Board of Intermediate Education',
          source: 'DIGILOCKER' as const,
          verified: true,
        },
        {
          id: 'doc_3',
          title: 'Integrated Residence & Domicile Certificate',
          documentNumber: 'RC-AP-VZG-2023-1194',
          issuer: 'Tahsildar Office, Gajuwaka',
          source: 'CAMERA_SCAN' as const,
          verified: true,
        },
      ];
    }

    return docIds.map((id) => {
      const match = documents.find((d) => d.id === id);
      if (match) return match;
      if (id === 'doc_1') {
        return {
          id: 'doc_1',
          title: 'Aadhaar Card (UIDAI Verified)',
          documentNumber: 'XXXX-XXXX-8924',
          issuer: 'Unique Identification Authority of India (UIDAI)',
          source: 'DIGILOCKER' as const,
          verified: true,
        };
      }
      if (id === 'doc_2') {
        return {
          id: 'doc_2',
          title: 'Class 12 Intermediate Marks Memo (86.4%)',
          documentNumber: 'BIE-AP-2022-849201',
          issuer: 'Board of Intermediate Education',
          source: 'DIGILOCKER' as const,
          verified: true,
        };
      }
      if (id === 'doc_3') {
        return {
          id: 'doc_3',
          title: 'Integrated Residence Certificate',
          documentNumber: 'RC-AP-VZG-2023-1194',
          issuer: 'Tahsildar Office, Gajuwaka',
          source: 'CAMERA_SCAN' as const,
          verified: true,
        };
      }
      if (id === 'doc_4') {
        return {
          id: 'doc_4',
          title: 'Smart White Ration Card (NFSA)',
          documentNumber: 'WAP02492109823',
          issuer: 'Civil Supplies Department',
          source: 'DIGILOCKER' as const,
          verified: true,
        };
      }
      return {
        id,
        title: 'Supporting Verification Document',
        documentNumber: `SMV-DOC-${id}`,
        issuer: 'Competent Issuing Authority',
        source: 'DIGILOCKER' as const,
        verified: true,
      };
    });
  };

  return (
    <div id="officer-dashboard-view" className="space-y-6 animate-in fade-in duration-200">
      {/* 1. OFFICER WORKBENCH HEADER */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
                <Building2 className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                    Department Officer Workbench
                  </h1>
                  <span className="px-2.5 py-0.5 rounded-full bg-blue-50 text-blue-800 text-[11px] font-bold font-mono border border-blue-200">
                    {currentUser.officerId || 'SMV-OFF-204'}
                  </span>
                </div>
                <p className="text-xs sm:text-sm text-slate-600 mt-0.5">
                  Logged in as <strong>{currentUser.name}</strong> • {currentUser.department || 'Higher Education & Social Welfare'} • {currentUser.jurisdiction?.district || 'Visakhapatnam'}
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 self-start md:self-auto">
            <button
              id="btn-officer-refresh"
              onClick={handleRefresh}
              disabled={isRefreshing}
              className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-all flex items-center gap-1.5"
              title="Refresh Queue"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
              <span className="hidden sm:inline">Refresh Queue</span>
            </button>

            <div className="flex items-center gap-1.5 text-xs text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-2 rounded-xl font-semibold">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span>Ingestion Live</span>
            </div>
          </div>
        </div>

        {/* 2. REALISTIC KPI STAT CARDS */}
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 mt-6 pt-5 border-t border-slate-100">
          {/* Total Applications */}
          <button
            id="kpi-total-apps"
            onClick={() => {
              setActiveTab('APPLICATIONS');
              setAppFilter('ALL');
            }}
            className={`p-3.5 rounded-xl border text-left transition-all ${
              activeTab === 'APPLICATIONS' && appFilter === 'ALL'
                ? 'bg-blue-50/70 border-blue-300 ring-2 ring-blue-500/20'
                : 'bg-slate-50/80 border-slate-200 hover:bg-white'
            }`}
          >
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
              Total Applications
            </span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-black text-slate-900">{applications.length}</span>
              <span className="text-[10px] text-blue-600 font-semibold">Active cases</span>
            </div>
          </button>

          {/* Pending Verification */}
          <button
            id="kpi-pending-apps"
            onClick={() => {
              setActiveTab('APPLICATIONS');
              setAppFilter('PENDING');
            }}
            className={`p-3.5 rounded-xl border text-left transition-all ${
              activeTab === 'APPLICATIONS' && appFilter === 'PENDING'
                ? 'bg-amber-50/70 border-amber-300 ring-2 ring-amber-500/20'
                : 'bg-slate-50/80 border-slate-200 hover:bg-white'
            }`}
          >
            <span className="text-[11px] font-bold text-amber-800 uppercase tracking-wider block">
              Pending Verification
            </span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-black text-amber-600">{pendingApps.length}</span>
              <span className="text-[10px] text-amber-700 font-semibold">Action needed</span>
            </div>
          </button>

          {/* Under Verification */}
          <button
            id="kpi-under-verification"
            onClick={() => {
              setActiveTab('APPLICATIONS');
              setAppFilter('UNDER_VERIFICATION');
            }}
            className={`p-3.5 rounded-xl border text-left transition-all ${
              activeTab === 'APPLICATIONS' && appFilter === 'UNDER_VERIFICATION'
                ? 'bg-indigo-50/70 border-indigo-300 ring-2 ring-indigo-500/20'
                : 'bg-slate-50/80 border-slate-200 hover:bg-white'
            }`}
          >
            <span className="text-[11px] font-bold text-indigo-800 uppercase tracking-wider block">
              Under Verification
            </span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-black text-indigo-600">{underVerificationApps.length}</span>
              <span className="text-[10px] text-indigo-700 font-semibold">Scrutiny desk</span>
            </div>
          </button>

          {/* Active Grievances */}
          <button
            id="kpi-active-grvs"
            onClick={() => {
              setActiveTab('GRIEVANCES');
              setGrvFilter('ACTIVE');
            }}
            className={`p-3.5 rounded-xl border text-left transition-all ${
              activeTab === 'GRIEVANCES' && grvFilter === 'ACTIVE'
                ? 'bg-amber-50/70 border-amber-300 ring-2 ring-amber-500/20'
                : 'bg-slate-50/80 border-slate-200 hover:bg-white'
            }`}
          >
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
              Active Grievances
            </span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-black text-slate-900">{activeGrvs.length}</span>
              <span className="text-[10px] text-amber-600 font-semibold">In jurisdiction</span>
            </div>
          </button>

          {/* SLA Breached */}
          <button
            id="kpi-sla-breached"
            onClick={() => {
              setActiveTab('GRIEVANCES');
              setGrvFilter('SLA_BREACHED');
            }}
            className={`p-3.5 rounded-xl border text-left transition-all col-span-2 lg:col-span-1 ${
              activeTab === 'GRIEVANCES' && grvFilter === 'SLA_BREACHED'
                ? 'bg-rose-50/70 border-rose-300 ring-2 ring-rose-500/20'
                : 'bg-slate-50/80 border-slate-200 hover:bg-white'
            }`}
          >
            <span className="text-[11px] font-bold text-rose-800 uppercase tracking-wider block">
              SLA Breached
            </span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-black text-rose-600">{slaBreachedGrvs.length}</span>
              <span className="text-[10px] text-rose-700 font-semibold">Priority alert</span>
            </div>
          </button>
        </div>
      </div>

      {/* 3. WORKBENCH SECTION TABS & CONTROLS */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-slate-200">
        <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
          <button
            id="tab-btn-applications"
            onClick={() => {
              setActiveTab('APPLICATIONS');
              setShowMobileDetail(false);
            }}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'APPLICATIONS'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Public Service Applications ({applications.length})</span>
          </button>

          <button
            id="tab-btn-grievances"
            onClick={() => {
              setActiveTab('GRIEVANCES');
              setShowMobileDetail(false);
            }}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'GRIEVANCES'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            <AlertCircle className="w-4 h-4" />
            <span>Assigned Grievances ({grievances.length})</span>
          </button>

          <button
            id="tab-btn-recent-activity"
            onClick={() => {
              setActiveTab('RECENT_ACTIVITY');
              setShowMobileDetail(false);
            }}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'RECENT_ACTIVITY'
                ? 'bg-purple-600 text-white shadow-xs'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            <History className="w-4 h-4" />
            <span>Recently Updated Cases ({recentActivityCases.length})</span>
          </button>
        </div>

        {/* Search box */}
        <div className="relative min-w-[220px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by ID, name, or issue..."
            className="w-full pl-9 pr-3 py-1.5 rounded-xl border border-slate-200 text-xs bg-white text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:border-blue-500"
          />
        </div>
      </div>

      {/* 4. APPLICATIONS WORKBENCH VIEW */}
      {activeTab === 'APPLICATIONS' && (
        <div>
          {/* Sub-Filters */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 mb-4">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1 shrink-0">
              <Filter className="w-3 h-3" /> Filter:
            </span>
            {[
              { key: 'ALL', label: `All (${applications.length})` },
              { key: 'PENDING', label: `Pending Action (${pendingApps.length})` },
              { key: 'UNDER_VERIFICATION', label: `Under Verification (${underVerificationApps.length})` },
              { key: 'APPROVED', label: `Approved (${applications.filter((a) => a.status === 'APPROVED' || a.status === 'BENEFIT_DISBURSED').length})` },
              { key: 'REJECTED', label: `Rejected (${applications.filter((a) => a.status === 'REJECTED').length})` },
            ].map((f) => (
              <button
                key={f.key}
                onClick={() => setAppFilter(f.key as AppFilter)}
                className={`px-3 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                  appFilter === f.key
                    ? 'bg-blue-600 text-white font-bold'
                    : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left: Applications List */}
            <div
              className={`lg:col-span-5 space-y-3 ${
                showMobileDetail ? 'hidden lg:block' : 'block'
              }`}
            >
              {filteredApplications.length === 0 ? (
                <div className="p-8 rounded-2xl bg-white border border-slate-200 text-center space-y-3">
                  <FileText className="w-8 h-8 text-slate-300 mx-auto" />
                  <p className="text-xs font-bold text-slate-700">No applications match current filters.</p>
                  <button
                    onClick={() => {
                      setAppFilter('ALL');
                      setSearchQuery('');
                    }}
                    className="text-xs text-blue-600 font-bold underline"
                  >
                    Reset all filters
                  </button>
                </div>
              ) : (
                filteredApplications.map((app) => {
                  const isSelected = selectedApp?.id === app.id;
                  const isScholarship = app.id === 'SMV-APP-0001' || app.serviceId.includes('scholarship');

                  return (
                    <div
                      key={app.id}
                      id={`app-card-${app.id}`}
                      onClick={() => {
                        setSelectedAppId(app.id);
                        setShowMobileDetail(true);
                      }}
                      className={`p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                        isSelected
                          ? 'border-blue-600 bg-blue-50/40 shadow-sm'
                          : 'border-slate-200 bg-white hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className="text-[11px] font-mono font-bold text-slate-600 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                            {app.id}
                          </span>
                          {isScholarship && (
                            <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                              DEMO SCHOLARSHIP
                            </span>
                          )}
                        </div>

                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            app.status === 'APPROVED' || app.status === 'BENEFIT_DISBURSED'
                              ? 'bg-emerald-100 text-emerald-800'
                              : app.status === 'REJECTED'
                              ? 'bg-rose-100 text-rose-800'
                              : app.status === 'UNDER_VERIFICATION'
                              ? 'bg-indigo-100 text-indigo-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {app.status === 'UNDER_VERIFICATION' ? 'PENDING VERIFICATION' : app.status}
                        </span>
                      </div>

                      <h3 className="text-xs font-bold text-slate-900 mt-2 line-clamp-1">
                        {app.serviceTitle}
                      </h3>

                      <div className="mt-2 flex items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-slate-100">
                        <span className="flex items-center gap-1 font-medium text-slate-700">
                          <User className="w-3 h-3 text-slate-400" />
                          {app.citizenName} ({app.citizenCategory || 'OBC'})
                        </span>
                        <span>{new Date(app.submittedAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Right: Application Verification Panel */}
            <div
              className={`lg:col-span-7 ${
                !showMobileDetail ? 'hidden lg:block' : 'block'
              }`}
            >
              {selectedApp ? (
                <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs space-y-5">
                  {/* Mobile back button */}
                  <div className="lg:hidden pb-3 border-b border-slate-100">
                    <button
                      onClick={() => setShowMobileDetail(false)}
                      className="inline-flex items-center gap-1 text-xs font-bold text-blue-600 hover:text-blue-700"
                    >
                      <ArrowLeft className="w-4 h-4" />
                      <span>Back to Applications List</span>
                    </button>
                  </div>

                  {/* Header */}
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 pb-4 border-b border-slate-100">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono font-bold text-blue-700 bg-blue-50 px-2.5 py-0.5 rounded border border-blue-200">
                          {selectedApp.id}
                        </span>
                        <span className="text-xs text-slate-500">
                          Submitted on {new Date(selectedApp.submittedAt).toLocaleDateString()}
                        </span>
                      </div>
                      <h2 className="text-base sm:text-lg font-black text-slate-900 mt-1">
                        {selectedApp.serviceTitle}
                      </h2>
                      <p className="text-xs text-slate-500 mt-0.5">
                        {selectedApp.department}
                      </p>
                    </div>

                    <span
                      className={`self-start px-3 py-1 rounded-full text-xs font-bold ${
                        selectedApp.status === 'APPROVED' || selectedApp.status === 'BENEFIT_DISBURSED'
                          ? 'bg-emerald-100 text-emerald-800'
                          : selectedApp.status === 'REJECTED'
                          ? 'bg-rose-100 text-rose-800'
                          : selectedApp.status === 'UNDER_VERIFICATION'
                          ? 'bg-indigo-100 text-indigo-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {selectedApp.status === 'UNDER_VERIFICATION' ? 'PENDING VERIFICATION' : selectedApp.status}
                    </span>
                  </div>

                  {/* Applicant Details & Demographics */}
                  <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                        <User className="w-3.5 h-3.5 text-blue-600" />
                        <span>Applicant Demographics (DigiLocker Linked)</span>
                      </span>
                      <span className="text-[11px] font-mono font-bold text-slate-500">
                        ID: {selectedApp.citizenId}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs pt-1">
                      <div>
                        <span className="text-slate-400 block text-[10px]">Full Name</span>
                        <span className="font-bold text-slate-800">{selectedApp.citizenName}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px]">Mobile</span>
                        <span className="font-bold text-slate-800">{selectedApp.citizenMobile}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px]">Category</span>
                        <span className="font-bold text-slate-800">{selectedApp.citizenCategory || 'OBC'}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px]">Annual Family Income</span>
                        <span className="font-bold text-slate-800">
                          ₹{Number(selectedApp.citizenIncome || 185000).toLocaleString('en-IN')} / yr
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px]">Jurisdiction</span>
                        <span className="font-bold text-slate-800">
                          {selectedApp.citizenMandal}, {selectedApp.citizenDistrict}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px]">Academic Merit</span>
                        <span className="font-bold text-emerald-700">86.4% (Class 12 BIE)</span>
                      </div>
                    </div>
                  </div>

                  {/* Pre-Verified Supporting Documents */}
                  <div>
                    <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2.5 flex items-center justify-between">
                      <span>Pre-Verified Supporting Documents</span>
                      <span className="text-[11px] text-emerald-700 font-semibold flex items-center gap-1">
                        <BadgeCheck className="w-3.5 h-3.5" />
                        Govt Trust Verified
                      </span>
                    </h3>

                    <div className="space-y-2">
                      {getAttachedDocuments(selectedApp).map((doc, idx) => (
                        <div
                          key={doc.id || idx}
                          className="p-3 rounded-xl border border-slate-200 bg-white flex items-center justify-between text-xs"
                        >
                          <div className="flex items-center gap-2.5">
                            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                            <div>
                              <span className="font-bold text-slate-900">{doc.title}</span>
                              <span className="text-[11px] text-slate-500 font-mono block">
                                {doc.documentNumber} • {doc.issuer || 'Govt of Andhra Pradesh'}
                              </span>
                            </div>
                          </div>

                          <span className="px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 text-[10px] font-bold border border-emerald-200">
                            {doc.source === 'DIGILOCKER' ? 'DIGILOCKER VERIFIED' : 'OCR CERTIFIED'}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Complete Application Timeline */}
                  <div>
                    <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">
                      Audit Trail & Status History
                    </h3>
                    <div className="space-y-2 border-l-2 border-slate-200 pl-3 ml-1 text-xs">
                      {selectedApp.timeline.map((event, idx) => (
                        <div key={idx} className="relative pb-1">
                          <span className="w-2 h-2 rounded-full bg-blue-500 absolute -left-[17px] top-1"></span>
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-slate-900">{event.status}</span>
                            <span className="text-[10px] text-slate-400">
                              {new Date(event.timestamp).toLocaleString()}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-600 mt-0.5">
                            {event.remarks} • <em>{event.actor}</em>
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Officer Action Console */}
                  <div className="p-4 rounded-xl bg-blue-50/70 border border-blue-200 space-y-3">
                    <div className="flex items-center justify-between">
                      <h3 className="text-xs font-bold text-blue-950 flex items-center gap-1.5">
                        <ShieldCheck className="w-4 h-4 text-blue-700" />
                        <span>Officer Verification & Sanction Console</span>
                      </h3>
                      <span className="text-[10px] font-bold text-blue-800 bg-blue-100 px-2 py-0.5 rounded">
                        OFFICER DESK
                      </span>
                    </div>

                    <div>
                      <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                        Statutory Remarks / Verification Notes
                      </label>
                      <input
                        type="text"
                        value={officerRemarks}
                        onChange={(e) => setOfficerRemarks(e.target.value)}
                        placeholder="e.g. Verified against university roll and DigiLocker records. Approved."
                        className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs bg-white text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:border-blue-500"
                      />
                    </div>

                    <div>
                      <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                        Sanctioned Entitlement / Direct Benefit Transfer (DBT) Amount
                      </label>
                      <input
                        type="text"
                        value={benefitAmount}
                        onChange={(e) => setBenefitAmount(e.target.value)}
                        className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs bg-white text-slate-900 font-semibold"
                      />
                    </div>

                    {/* Action Buttons: Verify, Forward, Reject */}
                    <div className="pt-2 flex flex-wrap items-center justify-end gap-2">
                      <button
                        id="btn-officer-verify-app"
                        onClick={handleVerifyAndForwardApplication}
                        disabled={actionInProgress || selectedApp.status === 'UNDER_VERIFICATION' || selectedApp.status === 'ESCALATED'}
                        className="min-h-[40px] px-3.5 py-2 rounded-xl border border-indigo-300 bg-white hover:bg-indigo-50 text-indigo-700 text-xs font-bold transition-all flex items-center justify-center gap-1 shrink-0"
                      >
                        <FileCheck className="w-4 h-4" />
                        <span>Verify &amp; Forward to Higher Officer</span>
                      </button>

                      <button
                        id="btn-officer-documents-required"
                        onClick={() => handleUpdateApplication('DOCUMENTS_REQUIRED')}
                        disabled={actionInProgress || selectedApp.status === 'DOCUMENTS_REQUIRED'}
                        className="min-h-[40px] px-3.5 py-2 rounded-xl border border-amber-300 bg-white hover:bg-amber-50 text-amber-700 text-xs font-bold transition-all flex items-center justify-center gap-1 shrink-0"
                      >
                        <AlertCircle className="w-4 h-4" />
                        <span>Documents Required</span>
                      </button>

                      <button
                        id="btn-officer-reject-app"
                        onClick={() => handleUpdateApplication('REJECTED')}
                        disabled={actionInProgress}
                        className="min-h-[40px] px-3.5 py-2 rounded-xl border border-rose-300 bg-white hover:bg-rose-50 text-rose-700 text-xs font-bold transition-all flex items-center justify-center gap-1 shrink-0"
                      >
                        <XCircle className="w-4 h-4" />
                        <span>Reject</span>
                      </button>

                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-12 rounded-2xl bg-white border border-slate-200 text-center">
                  <p className="text-xs text-slate-500">Select an application from the list to view and verify details.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 5. GRIEVANCES WORKBENCH VIEW */}
      {activeTab === 'GRIEVANCES' && (
        <div>
          {/* Sub-Filters */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 mb-4">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1 shrink-0">
              <Filter className="w-3 h-3" /> Filter:
            </span>
            {[
              { key: 'ALL', label: `All (${grievances.length})` },
              { key: 'ACTIVE', label: `Active (${activeGrvs.length})` },
              { key: 'IN_PROGRESS', label: `In Progress (${grievances.filter((g) => g.status === 'IN_PROGRESS').length})` },
              { key: 'SLA_BREACHED', label: `SLA Breached (${slaBreachedGrvs.length})` },
              { key: 'RESOLVED', label: `Resolved (${grievances.filter((g) => g.status === 'RESOLVED').length})` },
            ].map((f) => (
              <button
                key={f.key}
                onClick={() => setGrvFilter(f.key as GrvFilter)}
                className={`px-3 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                  grvFilter === f.key
                    ? 'bg-amber-600 text-white font-bold'
                    : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left: Grievances List */}
            <div
              className={`lg:col-span-5 space-y-3 ${
                showMobileDetail ? 'hidden lg:block' : 'block'
              }`}
            >
              {filteredGrievances.length === 0 ? (
                <div className="p-8 rounded-2xl bg-white border border-slate-200 text-center space-y-3">
                  <AlertCircle className="w-8 h-8 text-slate-300 mx-auto" />
                  <p className="text-xs font-bold text-slate-700">No grievances match current filters.</p>
                  <button
                    onClick={() => {
                      setGrvFilter('ALL');
                      setSearchQuery('');
                    }}
                    className="text-xs text-amber-600 font-bold underline"
                  >
                    Reset all filters
                  </button>
                </div>
              ) : (
                filteredGrievances.map((grv) => {
                  const isSelected = selectedGrv?.id === grv.id;
                  const isWorkingDemo = grv.id === 'SMV-GRV-0001';

                  return (
                    <div
                      key={grv.id}
                      id={`grv-card-${grv.id}`}
                      onClick={() => {
                        setSelectedGrvId(grv.id);
                        setShowMobileDetail(true);
                      }}
                      className={`p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                        isSelected
                          ? 'border-amber-600 bg-amber-50/40 shadow-sm'
                          : 'border-slate-200 bg-white hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className="text-[11px] font-mono font-bold text-slate-600 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                            {grv.id}
                          </span>
                          {isWorkingDemo && (
                            <span className="px-2 py-0.5 rounded bg-amber-100 text-amber-800 text-[10px] font-bold">
                              DEMO GRIEVANCE
                            </span>
                          )}
                        </div>

                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            grv.isSlaBreached || grv.status === 'ESCALATED'
                              ? 'bg-rose-100 text-rose-800 animate-pulse'
                              : grv.status === 'RESOLVED'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {grv.isSlaBreached ? 'SLA BREACHED' : grv.status}
                        </span>
                      </div>

                      <h3 className="text-xs font-bold text-slate-900 mt-2 line-clamp-1">
                        {grv.issueType}
                      </h3>

                      <p className="text-[11px] text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                        {grv.description}
                      </p>

                      <div className="mt-2.5 flex items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-slate-100">
                        <span className="flex items-center gap-1 font-medium text-slate-700">
                          <MapPin className="w-3 h-3 text-amber-600" />
                          {grv.location.mandal}
                        </span>
                        <span>{new Date(grv.submittedAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Right: Grievance Action Desk */}
            <div
              className={`lg:col-span-7 ${
                !showMobileDetail ? 'hidden lg:block' : 'block'
              }`}
            >
              {selectedGrv ? (
                <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs space-y-5">
                  {/* Mobile back button */}
                  <div className="lg:hidden pb-3 border-b border-slate-100">
                    <button
                      onClick={() => setShowMobileDetail(false)}
                      className="inline-flex items-center gap-1 text-xs font-bold text-amber-600 hover:text-amber-700"
                    >
                      <ArrowLeft className="w-4 h-4" />
                      <span>Back to Grievances List</span>
                    </button>
                  </div>

                  {/* Header */}
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 pb-4 border-b border-slate-100">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono font-bold text-amber-800 bg-amber-50 px-2.5 py-0.5 rounded border border-amber-200">
                          {selectedGrv.id}
                        </span>
                        <span className="text-xs text-slate-500">
                          Reported on {new Date(selectedGrv.submittedAt).toLocaleDateString()}
                        </span>
                      </div>
                      <h2 className="text-base sm:text-lg font-black text-slate-900 mt-1">
                        {selectedGrv.issueType}
                      </h2>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Category: <strong>{selectedGrv.category}</strong> • Routed to: {selectedGrv.routedDepartment}
                      </p>
                    </div>

                    <span
                      className={`self-start px-3 py-1 rounded-full text-xs font-bold ${
                        selectedGrv.isSlaBreached || selectedGrv.status === 'ESCALATED'
                          ? 'bg-rose-100 text-rose-800 animate-pulse'
                          : selectedGrv.status === 'RESOLVED'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {selectedGrv.isSlaBreached ? 'SLA BREACHED' : selectedGrv.status}
                    </span>
                  </div>

                  {/* Grievance Description & Location */}
                  <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2 text-xs">
                    <div className="flex items-center gap-2 font-bold text-slate-900">
                      <MapPin className="w-4 h-4 text-amber-600 shrink-0" />
                      <span>
                        {selectedGrv.location.landmark || selectedGrv.location.mandal}, {selectedGrv.location.district}
                      </span>
                    </div>

                    <p className="text-slate-700 leading-relaxed pt-1 bg-white p-3 rounded-lg border border-slate-200">
                      "{selectedGrv.description}"
                    </p>

                    <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1">
                        <span>Follow-up Reference: <strong>{selectedGrv.followUpReference || selectedGrv.citizenId}</strong></span>
                      <span>SLA Window: <strong>7 Days</strong></span>
                    </div>
                  </div>

                  {/* Higher Officer Directives (if escalated or received directive) */}
                  {selectedGrv.higherOfficerNotes && (
                    <div className="p-4 rounded-xl bg-purple-50 border border-purple-200 text-xs space-y-1">
                      <span className="font-bold text-purple-950 block">
                        Directive from Joint Secretary Priya Sharma:
                      </span>
                      <p className="text-purple-900 font-medium">
                        "{selectedGrv.higherOfficerNotes}"
                      </p>
                    </div>
                  )}

                  {/* Grievance Timeline */}
                  <div>
                    <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">
                      Grievance Progression Timeline
                    </h3>
                    <div className="space-y-2 border-l-2 border-slate-200 pl-3 ml-1 text-xs">
                      {selectedGrv.timeline.map((event, idx) => (
                        <div key={idx} className="relative pb-1">
                          <span
                            className={`w-2 h-2 rounded-full absolute -left-[17px] top-1 ${
                              event.status === 'RESOLVED'
                                ? 'bg-emerald-500'
                                : event.status === 'ESCALATED'
                                ? 'bg-rose-500'
                                : 'bg-amber-500'
                            }`}
                          ></span>
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-slate-900">{event.status}</span>
                            <span className="text-[10px] text-slate-400">
                              {new Date(event.timestamp).toLocaleString()}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-600 mt-0.5">
                            {event.remarks} • <em>{event.actor}</em>
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Officer Action Console: Mark In Progress, Resolve, Escalate */}
                  <div className="p-4 rounded-xl bg-amber-50/70 border border-amber-200 space-y-3">
                    <div className="flex items-center justify-between">
                      <h3 className="text-xs font-bold text-amber-950 flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-amber-700" />
                        <span>Field Action & Redressal Console</span>
                      </h3>
                      <span className="text-[10px] font-bold text-amber-800 bg-amber-100 px-2 py-0.5 rounded">
                        DISPATCH DESK
                      </span>
                    </div>

                    {/* Action Choice Selection */}
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <label
                        className={`p-2.5 rounded-xl border text-xs font-bold flex items-center gap-2 cursor-pointer transition-all ${
                          grievanceActionChoice === 'ASSIGNED'
                            ? 'bg-blue-500 text-white border-blue-600 shadow-xs'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        <input type="radio" name="grv_action" checked={grievanceActionChoice === 'ASSIGNED'} onChange={() => setGrievanceActionChoice('ASSIGNED')} className="sr-only" />
                        <Check className="w-3.5 h-3.5" />
                        <span>Assign Complaint</span>
                      </label>

                      <label
                        className={`p-2.5 rounded-xl border text-xs font-bold flex items-center gap-2 cursor-pointer transition-all ${
                          grievanceActionChoice === 'IN_PROGRESS'
                            ? 'bg-amber-500 text-white border-amber-600 shadow-xs'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        <input
                          type="radio"
                          name="grv_action"
                          checked={grievanceActionChoice === 'IN_PROGRESS'}
                          onChange={() => setGrievanceActionChoice('IN_PROGRESS')}
                          className="sr-only"
                        />
                        <Clock className="w-3.5 h-3.5" />
                        <span>Mark In Progress</span>
                      </label>

                      <label
                        className={`p-2.5 rounded-xl border text-xs font-bold flex items-center gap-2 cursor-pointer transition-all ${
                          grievanceActionChoice === 'RESOLVED'
                            ? 'bg-emerald-600 text-white border-emerald-700 shadow-xs'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        <input
                          type="radio"
                          name="grv_action"
                          checked={grievanceActionChoice === 'RESOLVED'}
                          onChange={() => setGrievanceActionChoice('RESOLVED')}
                          className="sr-only"
                        />
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Resolve Issue</span>
                      </label>

                      <label
                        className={`p-2.5 rounded-xl border text-xs font-bold flex items-center gap-2 cursor-pointer transition-all ${
                          grievanceActionChoice === 'ESCALATED'
                            ? 'bg-rose-600 text-white border-rose-700 shadow-xs'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        <input
                          type="radio"
                          name="grv_action"
                          checked={grievanceActionChoice === 'ESCALATED'}
                          onChange={() => setGrievanceActionChoice('ESCALATED')}
                          className="sr-only"
                        />
                        <AlertTriangle className="w-3.5 h-3.5" />
                        <span>Escalate Case</span>
                      </label>
                    </div>

                    <div>
                      <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                        Field Inspection & Action Taken Report
                      </label>
                      <input
                        type="text"
                        value={officerRemarks}
                        onChange={(e) => setOfficerRemarks(e.target.value)}
                        placeholder="e.g. Field engineering crew inspected valve and replaced leaking section."
                        className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs bg-white text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:border-amber-500"
                      />
                    </div>

                    <div className="pt-2 flex justify-end">
                      <button
                        id="btn-officer-verify-forward-grv"
                        onClick={handleVerifyAndForwardGrievance}
                        disabled={actionInProgress || selectedGrv.status === 'ESCALATED' || selectedGrv.status === 'RESOLVED'}
                        className="min-h-[40px] px-6 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md transition-all flex items-center justify-center gap-1.5"
                      >
                        <Check className="w-4 h-4" />
                        <span>Verify &amp; Forward to Higher Officer</span>
                      </button>
                    </div>

                    <div className="pt-2 flex justify-end">
                      <button
                        id="btn-officer-submit-grv"
                        onClick={handleUpdateGrievance}
                        disabled={actionInProgress}
                        className="min-h-[40px] px-6 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold shadow-md transition-all flex items-center justify-center gap-1.5"
                      >
                        <Check className="w-4 h-4" />
                        <span>Submit Action Report</span>
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-12 rounded-2xl bg-white border border-slate-200 text-center">
                  <p className="text-xs text-slate-500">Select a grievance from the list to review and update status.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 6. RECENT ACTIVITY CASES TAB */}
      {activeTab === 'RECENT_ACTIVITY' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h2 className="text-base font-black text-slate-900">
                Recently Updated Cases & Status Stream
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Live audit trail across all department applications, sanctions, and grievance dispatches
              </p>
            </div>
            <span className="text-xs font-bold text-purple-700 bg-purple-50 px-3 py-1 rounded-full border border-purple-200">
              {recentActivityCases.length} Events Logged
            </span>
          </div>

          <div className="divide-y divide-slate-100">
            {recentActivityCases.map((event, idx) => (
              <div
                key={idx}
                className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50/80 px-2 rounded-xl transition-colors cursor-pointer"
                onClick={() => {
                  if (event.caseType === 'APPLICATION') {
                    setSelectedAppId(event.id);
                    setActiveTab('APPLICATIONS');
                  } else {
                    setSelectedGrvId(event.id);
                    setActiveTab('GRIEVANCES');
                  }
                }}
              >
                <div className="flex items-start gap-3">
                  <div
                    className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 text-xs font-bold ${
                      event.caseType === 'APPLICATION'
                        ? 'bg-blue-100 text-blue-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {event.caseType === 'APPLICATION' ? <FileText className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono font-bold text-slate-700 bg-slate-100 px-2 py-0.2 rounded">
                        {event.id}
                      </span>
                      <span className="text-xs font-bold text-slate-900">{event.title}</span>
                    </div>

                    <p className="text-xs text-slate-600 mt-1">
                      {event.remarks}
                    </p>

                    <span className="text-[11px] text-slate-400 mt-0.5 block">
                      Citizen: <strong>{event.citizenName}</strong> • Updated by <em>{event.actor}</em>
                    </span>
                  </div>
                </div>

                <div className="flex items-center sm:flex-col sm:items-end justify-between sm:justify-center gap-1 shrink-0">
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                      event.status === 'APPROVED' || event.status === 'RESOLVED' || event.status === 'BENEFIT_DISBURSED'
                        ? 'bg-emerald-100 text-emerald-800'
                        : event.status === 'ESCALATED'
                        ? 'bg-rose-100 text-rose-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {event.status}
                  </span>
                  <span className="text-[10px] text-slate-400">
                    {new Date(event.timestamp).toLocaleString()}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
