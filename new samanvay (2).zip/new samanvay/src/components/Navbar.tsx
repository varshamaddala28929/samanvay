import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { SamanvayLogo } from './SamanvayLogo';
import { Language } from '../types';
import {
  Globe,
  Mic,
  FileText,
  AlertCircle,
  FolderLock,
  ChevronDown,
  Building2,
  Check,
  SlidersHorizontal,
  LogOut,
  Menu,
  X,
  UserCircle,
} from 'lucide-react';

const LANGUAGES: Array<{ code: Language; label: string; nativeName: string }> = [
  { code: 'te', label: 'Telugu', nativeName: 'తెలుగు' },
  { code: 'en', label: 'English', nativeName: 'English' },
  { code: 'hi', label: 'Hindi', nativeName: 'हिन्दी' },
  { code: 'mr', label: 'Marathi', nativeName: 'मराठी' },
  { code: 'ta', label: 'Tamil', nativeName: 'தமிழ்' },
];

export const Navbar: React.FC = () => {
  const {
    language,
    setLanguage,
    t,
    activeRole,
    isAuthenticated,
    currentUser,
    activeTab,
    setActiveTab,
    applications,
    grievances,
    setIsVoiceModalOpen,
    setIsLiveDemoModalOpen,
    logout,
  } = useApp();

  const [isLangDropdownOpen, setIsLangDropdownOpen] = useState(false);
  const [isServicesMenuOpen, setIsServicesMenuOpen] = useState(false);
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  const currentLangObj = LANGUAGES.find((l) => l.code === language) || LANGUAGES[0];
  const activeAppCount = applications.length;
  const trackedGrievanceCount = grievances.length;
  const hasOpenItems = activeAppCount > 0 || trackedGrievanceCount > 0;

  const handleLogoutClick = () => {
    if (hasOpenItems) {
      setShowLogoutConfirm(true);
      return;
    }

    logout();
  };

  return (
    <nav id="main-navigation-bar" className="bg-white border-b border-slate-200 sticky top-0 z-40 shadow-xs">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-17">
          {/* Logo & Platform identity */}
          <div
            className="cursor-pointer flex items-center shrink-0 mr-4"
            onClick={() => {
              if (activeRole === 'CITIZEN') setActiveTab('HOME');
              else if (activeRole === 'OFFICER') setActiveTab('OFFICER_DESK');
              else setActiveTab('HIGHER_OFFICER_DESK');
            }}
          >
            <SamanvayLogo size="md" showTagline={true} />
          </div>

          {/* Primary Navigation Links */}
          <div className="hidden md:flex items-center gap-1">
            {activeRole === 'CITIZEN' && (
              <>
                <div className="relative">
                  <button
                    id="nav-public-services"
                    onClick={() => setIsServicesMenuOpen(!isServicesMenuOpen)}
                    className={`px-3 py-2 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
                    activeTab === 'SERVICES'
                      ? 'bg-emerald-50 text-emerald-800 font-bold border border-emerald-200/60'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                    }`}
                    aria-expanded={isServicesMenuOpen}
                  >
                    <Building2 className="w-3.5 h-3.5" />
                    <span>{t('publicServices')}</span>
                    <ChevronDown className="w-3 h-3" />
                  </button>
                  {isServicesMenuOpen && (
                    <div className="absolute left-0 mt-1.5 w-56 rounded-2xl bg-white border border-slate-200 shadow-xl p-2 z-50">
                      {[
                        ['Scholarships', '🎓'],
                        ['Certificates', '📄'],
                        ['Pensions', '🛡️'],
                        ['Housing', '🏠'],
                        ['Other Public Services', '▦'],
                      ].map(([label, icon]) => (
                        <button
                          key={label}
                          type="button"
                          onClick={() => { setActiveTab('SERVICES'); setIsServicesMenuOpen(false); }}
                          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left text-xs font-semibold text-slate-700 hover:bg-emerald-50 hover:text-emerald-800"
                        >
                          <span className="text-base">{icon}</span><span>{label}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                <button
                  id="nav-grievances"
                  onClick={() => setActiveTab('GRIEVANCES')}
                  className={`px-3 py-2 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
                    activeTab === 'GRIEVANCES'
                      ? 'bg-amber-50 text-amber-800 font-bold border border-amber-200/60'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                >
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>{t('grievances')}</span>
                </button>

                <button
                  id="nav-my-applications"
                  onClick={() => setActiveTab('MY_APPLICATIONS')}
                  className={`px-3 py-2 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
                    activeTab === 'MY_APPLICATIONS'
                      ? 'bg-slate-100 text-slate-900 font-bold'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>{t('myApplications')}</span>
                  {applications.length > 0 && (
                    <span className="px-1.5 py-0.2 rounded-full text-[11px] bg-emerald-100 text-emerald-800 font-bold">
                      {applications.length}
                    </span>
                  )}
                </button>

                <button
                  id="nav-my-grievances"
                  onClick={() => setActiveTab('MY_GRIEVANCES')}
                  className={`px-3 py-2 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
                    activeTab === 'MY_GRIEVANCES'
                      ? 'bg-slate-100 text-slate-900 font-bold'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                >
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>{t('myGrievances')}</span>
                  {grievances.length > 0 && (
                    <span className="px-1.5 py-0.2 rounded-full text-[11px] bg-amber-100 text-amber-800 font-bold">
                      {grievances.length}
                    </span>
                  )}
                </button>

              </>
            )}

            {activeRole === 'OFFICER' && (
              <div className="flex items-center gap-2">
                <span className="px-3 py-1 rounded-lg bg-blue-50 text-blue-700 text-xs font-bold border border-blue-200">
                  {currentUser.department || 'Department Operational Desk'}
                </span>
                <span className="text-xs text-slate-500 font-medium hidden xl:inline">
                  Jurisdiction: {currentUser.jurisdiction?.district} ({currentUser.jurisdiction?.mandal})
                </span>
              </div>
            )}

            {activeRole === 'HIGHER_OFFICER' && (
              <div className="flex items-center gap-2">
                <span className="px-3 py-1 rounded-lg bg-purple-50 text-purple-700 text-xs font-bold border border-purple-200">
                  State Directorate & Monitoring Desk
                </span>
                <span className="text-xs text-slate-500 font-medium hidden xl:inline">
                  Joint Secretary: {currentUser.name}
                </span>
              </div>
            )}
          </div>

          {/* Right Action Items: Voice Input, Language Selector, Live Demo, User Badge */}
          <div className="flex items-center gap-2 sm:gap-2.5">
            {activeRole === 'CITIZEN' && (
              <button
                type="button"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="md:hidden p-2 rounded-xl text-slate-600 hover:bg-slate-100"
                aria-label={t('openNavigationMenu')}
                aria-expanded={isMobileMenuOpen}
              >
                {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            )}
            {/* Voice Assistant Trigger */}
            <button
              id="btn-voice-assistant-trigger"
              onClick={() => setIsVoiceModalOpen(true)}
              className="flex items-center gap-1.5 min-h-[38px] px-2.5 sm:px-3 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 text-xs font-semibold transition-all shadow-2xs group"
              title={t('voiceSearch')}
            >
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <Mic className="w-3.5 h-3.5 text-emerald-700 group-hover:scale-110 transition-transform" />
              <span className="hidden lg:inline font-bold">{t('voiceSearch')}</span>
            </button>

            {/* Language Selector Dropdown */}
            <div className="relative">
              <button
                id="btn-language-selector"
                onClick={() => setIsLangDropdownOpen(!isLangDropdownOpen)}
                className="flex items-center gap-1.5 min-h-[38px] px-2.5 sm:px-3 py-1.5 rounded-xl border border-slate-200 hover:border-slate-300 bg-slate-50 text-slate-800 text-xs font-semibold transition-colors"
                aria-expanded={isLangDropdownOpen}
              >
                <Globe className="w-3.5 h-3.5 text-slate-600" />
                <span className="font-semibold">{currentLangObj.nativeName}</span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </button>

              {isLangDropdownOpen && (
                <div
                  id="language-dropdown-menu"
                  className="absolute right-0 mt-1.5 w-48 rounded-2xl bg-white border border-slate-200 shadow-xl py-1.5 z-50 animate-in fade-in zoom-in-95 duration-100"
                >
                  <div className="px-3.5 py-1 text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                    {t('selectLanguage')}
                  </div>
                  {LANGUAGES.map((l) => (
                    <button
                      key={l.code}
                      onClick={() => {
                        setLanguage(l.code);
                        setIsLangDropdownOpen(false);
                      }}
                      className={`w-full text-left px-3.5 py-2.5 text-xs flex items-center justify-between hover:bg-slate-50 transition-colors ${
                        language === l.code ? 'font-bold text-emerald-700 bg-emerald-50/60' : 'text-slate-700'
                      }`}
                    >
                      <div className="flex flex-col">
                        <span className="font-semibold text-slate-900">{l.nativeName}</span>
                        <span className="text-[10px] text-slate-400">{l.label}</span>
                      </div>
                      {language === l.code && <Check className="w-4 h-4 text-emerald-600" />}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Subtle Live Demo Trigger Button (Requested) */}
            <button
              id="btn-live-demo-trigger"
              onClick={() => setIsLiveDemoModalOpen(true)}
              className="flex items-center gap-1.5 min-h-[38px] px-2.5 sm:px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold transition-colors shadow-2xs"
              title={t('liveDemo')}
            >
              <SlidersHorizontal className="w-3.5 h-3.5 text-emerald-400" />
              <span className="font-bold">{t('liveDemo')}</span>
            </button>

            {/* Compact Profile Menu */}
            {isAuthenticated && (
              <div className="relative flex items-center gap-1.5 pl-2 border-l border-slate-200">
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white shadow-2xs shrink-0 ${
                    activeRole === 'CITIZEN'
                      ? 'bg-emerald-700'
                      : activeRole === 'OFFICER'
                      ? 'bg-blue-700'
                      : 'bg-purple-700'
                  }`}
                  title={t('myProfile')}
                  onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
                >
                  {currentUser.name.charAt(0)}
                </div>
                <button type="button" onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)} className="hidden xl:flex flex-col text-left leading-tight mr-1">
                  <span className="text-xs font-bold text-slate-900 line-clamp-1">{currentUser.name}</span>
                  <span className="text-[10px] text-slate-500 font-mono">
                    {currentUser.citizenId || currentUser.officerId || currentUser.higherOfficerId}
                  </span>
                </button>

                {isProfileMenuOpen && (
                  <div className="absolute right-0 top-11 w-48 rounded-2xl bg-white border border-slate-200 shadow-xl p-2 z-50">
                    <button type="button" onClick={() => { setActiveTab('PROFILE'); setIsProfileMenuOpen(false); }} className="w-full flex items-center gap-2 px-3 py-2.5 rounded-xl text-left text-xs font-semibold text-slate-700 hover:bg-slate-50"><UserCircle className="w-4 h-4" />{t('myProfile')}</button>
                    <button type="button" onClick={() => { setActiveTab('PROFILE'); setIsProfileMenuOpen(false); }} className="w-full flex items-center gap-2 px-3 py-2.5 rounded-xl text-left text-xs font-semibold text-slate-700 hover:bg-slate-50"><FolderLock className="w-4 h-4" />{t('verifiedDocuments')}</button>
                    <button type="button" onClick={() => setIsProfileMenuOpen(false)} className="w-full flex items-center gap-2 px-3 py-2.5 rounded-xl text-left text-xs font-semibold text-slate-700 hover:bg-slate-50"><SlidersHorizontal className="w-4 h-4" />{t('accountSettings', 'Account Settings')}</button>
                    <button type="button" onClick={() => { setIsProfileMenuOpen(false); handleLogoutClick(); }} className="w-full flex items-center gap-2 px-3 py-2.5 rounded-xl text-left text-xs font-semibold text-red-600 hover:bg-red-50"><LogOut className="w-4 h-4" />{t('logout')}</button>
                  </div>
                )}

              </div>
            )}
          </div>
        </div>

        {isMobileMenuOpen && activeRole === 'CITIZEN' && (
          <div className="md:hidden border-t border-slate-100 py-3 space-y-1">
            {[
              [t('publicServices'), 'SERVICES', Building2],
              [t('grievances'), 'GRIEVANCES', AlertCircle],
              [t('myApplications'), 'MY_APPLICATIONS', FileText],
              [t('myGrievances'), 'MY_GRIEVANCES', AlertCircle],
              [t('myProfile'), 'PROFILE', FolderLock],
            ].map(([label, tab, Icon]) => (
              <button
                key={String(tab)}
                type="button"
                onClick={() => { setActiveTab(tab); setIsMobileMenuOpen(false); }}
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left text-sm font-semibold text-slate-700 hover:bg-slate-50"
              >
                {React.createElement(Icon as React.ElementType, { className: 'w-4 h-4' })}<span>{label}</span>
              </button>
            ))}
          </div>
        )}
      </div>

      {showLogoutConfirm && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-slate-900/50 p-4">
          <div className="w-full max-w-md rounded-2xl bg-white border border-slate-200 shadow-2xl p-6">
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-full bg-red-100 text-red-600">
                <LogOut className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900">{t('confirmLogout', 'Confirm Logout')}</h3>
                <p className="text-xs text-slate-500">{t('recordsStaySaved', 'Your records stay saved')}</p>
              </div>
            </div>

            <p className="mt-4 text-sm text-slate-600">
              {t('logoutItemsPrompt', 'You currently have')} <span className="font-bold text-slate-900">{activeAppCount} {t('active')}</span> {t('and', 'and')}{' '}
              <span className="font-bold text-slate-900">{trackedGrievanceCount} {t('tracked')}</span> {t('itemsLogoutPrompt', 'items. Are you sure you want to log out?')}
            </p>

            <div className="mt-6 flex justify-end gap-3">
              <button
                onClick={() => setShowLogoutConfirm(false)}
                className="px-4 py-2 rounded-xl border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 text-sm font-semibold transition-colors"
              >
                {t('close')}
              </button>
              <button
                onClick={() => {
                  setShowLogoutConfirm(false);
                  logout();
                }}
                className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-sm font-semibold transition-colors shadow-sm"
              >
                {t('logout')}
              </button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

