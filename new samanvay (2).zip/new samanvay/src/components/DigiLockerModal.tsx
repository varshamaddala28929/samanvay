import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { ShieldCheck, Check, Lock, FileText, ArrowRight, X, ExternalLink } from 'lucide-react';
import { api } from '../services/api';

export const DigiLockerModal: React.FC = () => {
  const {
    isDigiLockerModalOpen,
    setIsDigiLockerModalOpen,
    currentUser,
    refreshProfile,
    refreshAllData,
    addNotification,
  } = useApp();

  const [vaultItems, setVaultItems] = useState<any[]>([]);
  const [consentGiven, setConsentGiven] = useState(true);
  const [isFetching, setIsFetching] = useState<string | null>(null);

  useEffect(() => {
    if (isDigiLockerModalOpen) {
      api.getDigiLockerVault().then(setVaultItems);
    }
  }, [isDigiLockerModalOpen]);

  const handleFetchDoc = async (docType: string, title: string) => {
    if (!consentGiven) {
      alert('Please provide consent to fetch documents from DigiLocker.');
      return;
    }

    setIsFetching(docType);
    try {
      await api.fetchDigiLockerDoc(currentUser.citizenId || 'SMV-CIT-10245', docType);
      await refreshAllData();
      await refreshProfile();

      addNotification(
        'success',
        'DigiLocker Document Retrieved',
        `${title} verified and added to your Samanvay Locker.`
      );
      setIsFetching(null);
      setIsDigiLockerModalOpen(false);
    } catch (err) {
      console.error('DigiLocker fetch error:', err);
      setIsFetching(null);
    }
  };

  if (!isDigiLockerModalOpen) return null;

  return (
    <div
      id="digilocker-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200"
    >
      <div
        id="digilocker-dialog"
        className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 relative"
      >
        {/* DigiLocker Brand Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-md">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-blue-900 text-sm tracking-wide">DIGILOCKER</span>
                <span className="px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                  Govt Authorized
                </span>
              </div>
              <p className="text-xs text-slate-500">Direct Citizen Document Gateway</p>
            </div>
          </div>
          <button
            onClick={() => setIsDigiLockerModalOpen(false)}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="my-5">
          <p className="text-xs text-slate-600 mb-4">
            Retrieve authentic, digitally signed government certificates without physical paper or manual scans.
          </p>

          <div className="space-y-2.5">
            {vaultItems.map((item) => (
              <div
                key={item.type}
                className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/50 hover:bg-blue-50/40 hover:border-blue-300 transition-all flex items-center justify-between"
              >
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center shrink-0 mt-0.5">
                    <FileText className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">{item.title}</h4>
                    <p className="text-[11px] text-slate-500 font-mono mt-0.5">
                      Doc #{item.documentNumber} • {item.issuer}
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => handleFetchDoc(item.type, item.title)}
                  disabled={isFetching === item.type}
                  className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shrink-0 transition-colors flex items-center gap-1.5 disabled:opacity-50"
                >
                  {isFetching === item.type ? (
                    <span className="text-[11px]">Fetching...</span>
                  ) : (
                    <>
                      <span>Import</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </>
                  )}
                </button>
              </div>
            ))}
          </div>

          {/* Citizen Consent */}
          <div className="mt-5 p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-start gap-2.5">
            <input
              type="checkbox"
              id="digilocker-consent-checkbox"
              checked={consentGiven}
              onChange={(e) => setConsentGiven(e.target.checked)}
              className="mt-0.5 h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
            />
            <label htmlFor="digilocker-consent-checkbox" className="text-[11px] text-slate-600 cursor-pointer">
              I hereby authorize Samanvay to fetch my digitally signed documents from DigiLocker under the National Data Sharing & Accessibility Policy.
            </label>
          </div>
        </div>
      </div>
    </div>
  );
};
