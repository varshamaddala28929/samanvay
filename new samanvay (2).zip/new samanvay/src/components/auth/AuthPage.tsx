import React, { useRef, useState } from 'react';
import { useApp } from '../../context/AppContext';
import { SamanvayLogo } from '../SamanvayLogo';
import {
  ShieldCheck,
  Camera,
  FileText,
  Lock,
  User as UserIcon,
  Phone,
  Mail,
  MapPin,
  FileCheck,
  ArrowRight,
  Sparkles,
  CheckCircle2,
  KeyRound,
  Eye,
  EyeOff,
  Building2,
  Layers,
  Globe,
  Radio,
  X,
  RefreshCw,
} from 'lucide-react';
import { Language, Role } from '../../types';
import { api } from '../../services/api';

interface AuthPageProps {
  onOpenLiveDemo?: () => void;
  isModal?: boolean;
  onClose?: () => void;
}

export const AuthPage: React.FC<AuthPageProps> = ({ onOpenLiveDemo, isModal = false, onClose }) => {
  const {
    language,
    setLanguage,
    t,
    loginUser,
    signUpUser,
    loginWithDigiLocker,
    switchRole,
    setIsLiveDemoModalOpen,
    selectedService,
    currentUser,
    refreshAllData,
    addNotification,
  } = useApp();

  const [authMode, setAuthMode] = useState<'LOGIN' | 'SIGNUP' | 'DIGILOCKER'>('LOGIN');

  // Login form state
  const [loginIdentifier, setLoginIdentifier] = useState('9848022338');
  const [loginPassword, setLoginPassword] = useState('samanvay2026');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [faceVerificationPending, setFaceVerificationPending] = useState(false);
  const [faceMode, setFaceMode] = useState<'login' | 'enroll' | null>(null);
  const [faceMessage, setFaceMessage] = useState('Position your face inside the frame.');
  const [faceStage, setFaceStage] = useState<'camera' | 'captured' | 'verified'>('camera');
  const [capturedFacePreview, setCapturedFacePreview] = useState<string | null>(null);
  const faceVideoRef = useRef<HTMLVideoElement | null>(null);
  const faceStreamRef = useRef<MediaStream | null>(null);

  // Sign up form state
  const [signupForm, setSignupForm] = useState({
    fullName: '',
    mobile: '',
    email: '',
    district: 'Visakhapatnam',
    mandal: 'Gajuwaka',
    gender: 'Female',
    socialCategory: 'OBC',
    annualFamilyIncome: '180000',
    dateOfBirth: '2002-05-14',
    educationLevel: 'Undergraduate',
  });
  const [isSigningUp, setIsSigningUp] = useState(false);

  // DigiLocker Consent Flow Modal
  const [showDigiLockerConsent, setShowDigiLockerConsent] = useState(false);
  const [isDigiLockerConnecting, setIsDigiLockerConnecting] = useState(false);
  const [digiLockerSuccess, setDigiLockerSuccess] = useState(false);
  const [digiLockerStage, setDigiLockerStage] = useState<'connect' | 'permission' | 'connected'>('connect');
  const [digiLockerMobile, setDigiLockerMobile] = useState('');
  const [selectedDemoDocument, setSelectedDemoDocument] = useState<string | null>(null);
  const [isFetchingDemoDocument, setIsFetchingDemoDocument] = useState<string | null>(null);
  const isScholarshipFlow = selectedService?.id === 'srv-post-matric-scholarship';

  const scholarshipFaceVerificationRequired = () => {
    return isScholarshipFlow;
  };

  const demoDigiLockerDocuments = [
    { type: 'MARKS_MEMO', title: '10th Education Certificate' },
    { type: 'INCOME_CERTIFICATE', title: 'Income Certificate' },
    { type: 'CASTE_CERTIFICATE', title: 'Caste Certificate' },
    { type: 'AADHAAR', title: 'Identity Document' },
  ];

  // Forgot password modal
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [resetIdentifier, setResetIdentifier] = useState('');
  const [resetOtpSent, setResetOtpSent] = useState(false);
  const [resetOtp, setResetOtp] = useState('');
  const [resetSuccess, setResetSuccess] = useState(false);

  const languages: { code: Language; label: string; native: string }[] = [
    { code: 'te', label: 'Telugu', native: 'తెలుగు' },
    { code: 'en', label: 'English', native: 'English' },
    { code: 'hi', label: 'Hindi', native: 'हिन्दी' },
    { code: 'mr', label: 'Marathi', native: 'मराठी' },
    { code: 'ta', label: 'Tamil', native: 'தமிழ்' },
  ];

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginIdentifier) return;
    if (scholarshipFaceVerificationRequired()) {
      setFaceVerificationPending(true);
      return;
    }
    setIsLoggingIn(true);
    try {
      await loginUser(loginIdentifier);
    } finally {
      setIsLoggingIn(false);
    }
  };

  const stopFaceCamera = () => {
    faceStreamRef.current?.getTracks().forEach((track) => track.stop());
    faceStreamRef.current = null;
    if (faceVideoRef.current) faceVideoRef.current.srcObject = null;
    setFaceMode(null);
  };

  const openFaceCamera = async (mode: 'login' | 'enroll') => {
    setFaceMode(mode);
    setFaceStage('camera');
    setCapturedFacePreview(null);
    setFaceMessage('Position your face inside the frame.');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' }, audio: false });
      faceStreamRef.current = stream;
      await new Promise((resolve) => setTimeout(resolve, 0));
      if (!faceVideoRef.current) throw new Error('Camera preview unavailable');
      faceVideoRef.current.srcObject = stream;
      await faceVideoRef.current.play();
    } catch (error) {
      stopFaceCamera();
      throw new Error((error as DOMException)?.name === 'NotAllowedError'
        ? 'Camera access is required for Face Authentication. Please allow camera access and try again.'
        : 'Camera could not be opened. Please try again.');
    }
  };

  const captureLivePhoto = () => {
    const video = faceVideoRef.current;
    if (!video || video.readyState < 2) {
      addNotification('error', 'Camera not ready', 'Please wait for the live camera preview and try again.');
      return;
    }
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    canvas.getContext('2d')?.drawImage(video, 0, 0, canvas.width, canvas.height);
    setCapturedFacePreview(canvas.toDataURL('image/jpeg', 0.85));
    setFaceStage('captured');
    setFaceMessage('Face Captured Successfully.');
    stopFaceCamera();
    setFaceMode(faceMode);
  };

  const handleFaceVerification = async () => {
    try {
      if (faceStage === 'captured') {
        setFaceStage('verified');
        setFaceMessage('Face Verified Successfully.');
        return;
      }
      if (!faceStreamRef.current) {
        await openFaceCamera('login');
        return;
      }
      if (faceStage === 'camera') {
        captureLivePhoto();
        return;
      }
      setFaceStage('verified');
      setFaceMessage('Face Verified Successfully — Demo Verification');
    } catch (error) {
      addNotification('error', 'Camera error', (error as Error).message || 'Please try again.');
      stopFaceCamera();
    }
  };

  const continueAfterFaceVerification = async () => {
    setIsLoggingIn(true);
    try {
      const loggedIn = await loginUser(loginIdentifier);
      if (!loggedIn) throw new Error('Scholarship login failed after face verification');
      setFaceVerificationPending(false);
      addNotification('success', 'Face Verified Successfully', 'Demo Verification complete. Continuing to the Scholarship application.');
    } catch (error) {
      addNotification('error', 'Login failed', (error as Error).message || 'Please try again.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleSignUpSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!signupForm.fullName || !signupForm.mobile) return;
    setIsSigningUp(true);
    try {
      if (isScholarshipFlow) {
        setFaceVerificationPending(true);
        setFaceMode('enroll');
        setFaceStage('camera');
        setFaceMessage('Your live face will be used for Scholarship login verification.');
        return;
      }
      await signUpUser({
        ...signupForm,
        annualFamilyIncome: Number(signupForm.annualFamilyIncome) || 180000,
        age: 23,
      });
    } catch (error) {
      console.error('Scholarship face enrollment error:', error);
      addNotification('error', 'Face enrollment failed', 'Please try again to create your Scholarship account.');
    } finally {
      setIsSigningUp(false);
    }
  };

  const handleFaceEnrollment = async () => {
    setIsSigningUp(true);
    try {
      if (faceStage === 'captured') {
        setFaceStage('verified');
        setFaceMessage('Face Verified Successfully.');
        return;
      }
      if (!faceStreamRef.current) {
        await openFaceCamera('enroll');
        return;
      }
      if (faceStage === 'camera') {
        captureLivePhoto();
        return;
      }
      if (faceStage === 'captured') {
        setFaceStage('verified');
        setFaceMessage('Face Verified Successfully — Demo Verification');
        return;
      }
      const created = await signUpUser({
        ...signupForm,
        annualFamilyIncome: Number(signupForm.annualFamilyIncome) || 180000,
        age: 23,
      });
      if (!created) throw new Error('Scholarship account creation failed');
      setFaceVerificationPending(false);
      addNotification('success', 'Identity Verified Successfully', 'Demo Verification complete.');
    } catch (error) {
      console.error('Scholarship face enrollment error:', error);
      addNotification('error', 'Face enrollment failed', (error as Error).message || 'Please try again.');
      stopFaceCamera();
    } finally {
      setIsSigningUp(false);
    }
  };

  const handleDigiLockerConnectFlow = async () => {
    if (isScholarshipFlow && digiLockerStage === 'connect') {
      setDigiLockerStage('permission');
      return;
    }

    if (isScholarshipFlow) {
      setIsDigiLockerConnecting(true);
      await new Promise((r) => setTimeout(r, 1200));
      setDigiLockerStage('connected');
      setIsDigiLockerConnecting(false);
      return;
    }

    setIsDigiLockerConnecting(true);
    // Simulate realistic consent and certificate linkage
    await new Promise((r) => setTimeout(r, 1400));
    setDigiLockerSuccess(true);
    await new Promise((r) => setTimeout(r, 900));
    setIsDigiLockerConnecting(false);
    setShowDigiLockerConsent(false);
    await loginWithDigiLocker();
  };

  const openDigiLockerFlow = () => {
    setDigiLockerStage('connect');
    setDigiLockerMobile('');
    setSelectedDemoDocument(null);
    setIsFetchingDemoDocument(null);
    setDigiLockerSuccess(false);
    setShowDigiLockerConsent(true);
  };

  const handleDemoDocumentSelect = async (docType: string) => {
    setIsFetchingDemoDocument(docType);
    try {
      await api.fetchDigiLockerDoc(currentUser.citizenId || 'SMV-CIT-10245', docType);
      await refreshAllData();
      setSelectedDemoDocument(docType);
      addNotification('success', 'Document added successfully', 'Document received from DigiLocker — Prototype.');
    } catch (err) {
      console.error('Prototype DigiLocker document fetch error:', err);
    } finally {
      setIsFetchingDemoDocument(null);
    }
  };

  const handleForgotPasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!resetIdentifier) return;
    setResetOtpSent(true);
  };

  const handleVerifyOtpAndReset = (e: React.FormEvent) => {
    e.preventDefault();
    setResetSuccess(true);
    setTimeout(() => {
      setShowForgotPassword(false);
      setResetOtpSent(false);
      setResetSuccess(false);
      setResetIdentifier('');
      setResetOtp('');
    }, 1800);
  };

  if (isModal) {
    return (
      <div
        id="samanvay-auth-modal-backdrop"
        className={`fixed inset-0 ${isScholarshipFlow ? 'z-[60]' : 'z-50'} flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-200`}
      >
        <div className="w-full max-w-xl my-8 relative">
          <div
            id="auth-main-card"
            className="bg-white rounded-3xl border border-slate-200 shadow-2xl p-6 sm:p-8 relative overflow-hidden"
          >
            {/* Modal Header */}
            <div className="flex items-start justify-between gap-4 pb-4 mb-4 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <SamanvayLogo size="sm" showTagline={false} />
                <div>
                  <h3 className="text-lg font-extrabold text-slate-900">Samanvay Identity Gateway</h3>
                  <p className="text-xs text-slate-500">Citizen Single-Sign-On & DigiLocker Access</p>
                </div>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
                title="Close"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {faceVerificationPending && (
              <div className="absolute inset-0 z-10 flex items-center justify-center p-6 bg-white/95 animate-in fade-in duration-150">
                <div className="w-full max-w-sm text-center">
                  {faceMode && faceStage === 'camera' && <video ref={faceVideoRef} autoPlay muted playsInline className="w-full aspect-video rounded-2xl bg-slate-900 object-cover" />}
                  {capturedFacePreview && <img src={capturedFacePreview} alt="Captured live face" className="w-full aspect-video rounded-2xl bg-slate-900 object-cover" />}
                  {!faceMode && <div className="w-16 h-16 mx-auto rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center"><Camera className="w-8 h-8" /></div>}
                  <h3 className="mt-4 text-lg font-extrabold text-slate-900">Verify Face & Continue</h3>
                  <p className="mt-2 text-xs text-slate-600">{faceMessage}</p>
                  {faceStage === 'verified' && <p className="mt-2 text-xs font-bold text-emerald-700">Live Camera Demo Verification</p>}
                  <button
                    type="button"
                    onClick={faceStage === 'verified'
                      ? (faceMode === 'enroll' ? handleFaceEnrollment : continueAfterFaceVerification)
                      : (faceMode === 'enroll' ? handleFaceEnrollment : handleFaceVerification)}
                    disabled={isLoggingIn}
                    className="mt-6 w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold rounded-xl transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {isLoggingIn ? <RefreshCw className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-4 h-4" />}
                    <span>{isLoggingIn ? 'Checking Live Face...' : faceStage === 'camera' ? (faceStreamRef.current ? 'Take Live Photo' : 'Open Camera') : faceStage === 'captured' ? 'Verify Live Face' : 'Continue'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setFaceVerificationPending(false)}
                    disabled={isLoggingIn}
                    className="mt-3 text-xs font-semibold text-slate-500 hover:text-slate-700"
                  >
                    Back to Login
                  </button>
                </div>
              </div>
            )}

            {/* Mode Switcher Tabs */}
            <div
              id="auth-tabs"
              className="grid grid-cols-3 p-1 rounded-xl bg-slate-100 border border-slate-200 mb-6 gap-1"
            >
              <button
                id="tab-login"
                type="button"
                onClick={() => setAuthMode('LOGIN')}
                className={`py-2 text-xs sm:text-sm font-semibold rounded-lg transition-all ${
                  authMode === 'LOGIN'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {t('login')}
              </button>

              <button
                id="tab-signup"
                type="button"
                onClick={() => setAuthMode('SIGNUP')}
                className={`py-2 text-xs sm:text-sm font-semibold rounded-lg transition-all ${
                  authMode === 'SIGNUP'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {t('signUp')}
              </button>

              <button
                id="tab-digilocker"
                type="button"
                onClick={() => setAuthMode('DIGILOCKER')}
                className={`py-2 text-xs sm:text-sm font-semibold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                  authMode === 'DIGILOCKER'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-blue-700'
                }`}
              >
                <ShieldCheck className="w-3.5 h-3.5 text-blue-500" />
                <span>DigiLocker</span>
              </button>
            </div>

            {/* TAB 1: LOGIN */}
            {authMode === 'LOGIN' && (
              <form onSubmit={handleLoginSubmit} className="space-y-4 animate-in fade-in duration-150">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    {t('enterMobileOrId')}
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                      <UserIcon className="w-4 h-4" />
                    </div>
                    <input
                      id="login-identifier-input"
                      type="text"
                      required
                      value={loginIdentifier}
                      onChange={(e) => setLoginIdentifier(e.target.value)}
                      placeholder="e.g. 9848022338 or SMV-CIT-10245"
                      className="w-full pl-9 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 transition-all font-mono"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-semibold text-slate-700">{t('password')}</label>
                    <button
                      type="button"
                      id="forgot-password-link"
                      onClick={() => setShowForgotPassword(true)}
                      className="text-xs font-medium text-emerald-700 hover:text-emerald-800 hover:underline"
                    >
                      {t('forgotPassword')}
                    </button>
                  </div>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                      <Lock className="w-4 h-4" />
                    </div>
                    <input
                      id="login-password-input"
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      placeholder="••••••••••••"
                      className="w-full pl-9 pr-10 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 transition-all"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <button
                  id="submit-login-button"
                  type="submit"
                  disabled={isLoggingIn}
                  className="w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold rounded-xl transition-all flex items-center justify-center gap-2 shadow-md shadow-emerald-700/20 cursor-pointer disabled:opacity-50"
                >
                  {isLoggingIn ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <>
                      <span>{t('login')}</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>

                {/* Direct DigiLocker One-Click Divider */}
                <div className="relative my-4 text-center">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-slate-200" />
                  </div>
                  <span className="relative px-3 bg-white text-xs text-slate-400">or connect with</span>
                </div>

                <button
                  id="login-digilocker-action-btn"
                  type="button"
                  onClick={openDigiLockerFlow}
                  className="w-full py-2.5 px-4 bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-semibold rounded-xl border border-blue-200 transition-all flex items-center justify-center gap-2"
                >
                  <ShieldCheck className="w-4 h-4 text-blue-600" />
                  <span>{isScholarshipFlow ? 'Connect DigiLocker' : t('continueWithDigiLocker')}</span>
                </button>
              </form>
            )}

            {/* TAB 2: CREATE ACCOUNT */}
            {authMode === 'SIGNUP' && (
              <form onSubmit={handleSignUpSubmit} className="space-y-3.5 animate-in fade-in duration-150">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Full Legal Name *</label>
                    <input
                      id="signup-name-input"
                      type="text"
                      required
                      value={signupForm.fullName}
                      onChange={(e) => setSignupForm({ ...signupForm, fullName: e.target.value })}
                      placeholder="e.g. Ramesh Varma"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Mobile Number (Aadhaar-linked) *</label>
                    <input
                      id="signup-mobile-input"
                      type="tel"
                      required
                      maxLength={10}
                      value={signupForm.mobile}
                      onChange={(e) => setSignupForm({ ...signupForm, mobile: e.target.value })}
                      placeholder="9848012345"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-emerald-600 font-mono"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Email Address</label>
                    <input
                      id="signup-email-input"
                      type="email"
                      value={signupForm.email}
                      onChange={(e) => setSignupForm({ ...signupForm, email: e.target.value })}
                      placeholder="citizen@example.gov.in"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">District</label>
                    <select
                      id="signup-district-select"
                      value={signupForm.district}
                      onChange={(e) => setSignupForm({ ...signupForm, district: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-hidden focus:border-emerald-600"
                    >
                      <option value="Visakhapatnam">Visakhapatnam</option>
                      <option value="Vijayawada (NTR)">Vijayawada (NTR)</option>
                      <option value="Guntur">Guntur</option>
                      <option value="Tirupati">Tirupati</option>
                      <option value="Kurnool">Kurnool</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">Mandal</label>
                    <input
                      type="text"
                      value={signupForm.mandal}
                      onChange={(e) => setSignupForm({ ...signupForm, mandal: e.target.value })}
                      className="w-full px-2.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">Category</label>
                    <select
                      value={signupForm.socialCategory}
                      onChange={(e) => setSignupForm({ ...signupForm, socialCategory: e.target.value })}
                      className="w-full px-2.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900"
                    >
                      <option value="OBC">OBC / BC</option>
                      <option value="SC">SC</option>
                      <option value="ST">ST</option>
                      <option value="EWS">EWS</option>
                      <option value="General">General</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">Annual Income</label>
                    <input
                      type="number"
                      value={signupForm.annualFamilyIncome}
                      onChange={(e) => setSignupForm({ ...signupForm, annualFamilyIncome: e.target.value })}
                      className="w-full px-2.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900"
                    />
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900 flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                  <span>
                    Upon registration, a permanent <strong>Samanvay Citizen ID</strong> will be generated for seamless single-window public services.
                  </span>
                </div>

                <button
                  id="submit-signup-button"
                  type="submit"
                  disabled={isSigningUp}
                  className="w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold rounded-xl transition-all flex items-center justify-center gap-2 shadow-md shadow-emerald-700/20 cursor-pointer disabled:opacity-50"
                >
                  {isSigningUp ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <>
                      <span>{t('createCitizenAccount')}</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>
            )}

            {/* TAB 3: DIGILOCKER CONNECTION */}
            {authMode === 'DIGILOCKER' && (
              <div className="space-y-4 animate-in fade-in duration-150">
                <div className="p-4 rounded-xl bg-blue-50 border border-blue-200 text-center">
                  <div className="w-12 h-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center mx-auto mb-3 shadow-md">
                    <ShieldCheck className="w-7 h-7" />
                  </div>
                  <h3 className="text-base font-bold text-slate-900 mb-1">
                    {t('connectWithDigiLocker')}
                  </h3>
                  <p className="text-xs text-slate-600 leading-relaxed mb-4">
                    {t('digiLockerAuthDesc')}
                  </p>

                  <div className="bg-white rounded-xl p-3 text-left space-y-2 mb-4 border border-blue-100 shadow-2xs">
                    <div className="flex items-center gap-2 text-xs text-slate-700">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>Instant verification of Aadhaar, Caste & Income records</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-slate-700">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>Zero paper uploads & instant eligibility evaluation</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-slate-700">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>End-to-end digital consent governed by MeitY standards</span>
                    </div>
                  </div>

                  <button
                    id="connect-digilocker-modal-trigger"
                    type="button"
                    onClick={openDigiLockerFlow}
                    className="w-full py-3 px-4 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-xl transition-all flex items-center justify-center gap-2 shadow-md shadow-blue-700/20 cursor-pointer"
                  >
                    <ShieldCheck className="w-4 h-4" />
                    <span>{t('continueWithDigiLocker')}</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* DigiLocker Consent Flow Modal */}
        {showDigiLockerConsent && (
          <div
            id="digilocker-consent-modal"
            className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs animate-in fade-in duration-200"
          >
            <div className="bg-white text-slate-900 rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 relative overflow-hidden">
              {/* Header with DigiLocker Logo */}
              <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-md">
                    <ShieldCheck className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-extrabold text-blue-900 text-sm tracking-wide">DIGILOCKER</span>
                      <span className="px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                        Verified Gateway
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500">Government of India • MeriPehchaan</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setShowDigiLockerConsent(false)}
                  className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {isScholarshipFlow ? (
                <div className="my-5 space-y-4">
                  <span className="inline-flex px-2 py-1 rounded bg-amber-100 text-amber-800 text-[10px] font-bold">
                    DigiLocker Integration — Prototype Demo
                  </span>
                  {digiLockerStage === 'connect' && (
                    <>
                      <div>
                        <h4 className="text-sm font-bold text-slate-900">Connect your DigiLocker account</h4>
                        <p className="text-xs text-slate-600 leading-relaxed mt-1">Connect securely to access available documents for this scholarship application.</p>
                      </div>
                      <div>
                        <label className="text-[11px] font-semibold text-slate-700 block mb-1">Mobile Number / User ID</label>
                        <input
                          value={digiLockerMobile}
                          onChange={(e) => setDigiLockerMobile(e.target.value)}
                          placeholder="Enter demo mobile number or User ID"
                          className="w-full px-3 py-2.5 rounded-xl border border-slate-300 bg-slate-50 text-sm text-slate-900"
                        />
                      </div>
                    </>
                  )}
                  {digiLockerStage === 'permission' && (
                    <>
                      <div>
                        <h4 className="text-sm font-bold text-slate-900">Permission Required</h4>
                        <p className="text-xs text-slate-600 leading-relaxed mt-1">Samanvay wants permission to access available documents for this scholarship application.</p>
                      </div>
                      <div className="bg-slate-50 rounded-xl p-3 border border-slate-200 space-y-2 text-xs text-slate-700">
                        {['Identity document', 'Education certificate', 'Income certificate', 'Other required documents'].map((item) => (
                          <div key={item} className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-600" /><span>{item}</span></div>
                        ))}
                      </div>
                    </>
                  )}
                  {digiLockerStage === 'connected' && (
                    <>
                      <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-center">
                        <CheckCircle2 className="w-7 h-7 text-emerald-600 mx-auto mb-1" />
                        <h4 className="text-sm font-bold text-emerald-900">DigiLocker Connected</h4>
                        <p className="text-xs text-emerald-800 mt-1">Your available documents have been retrieved.</p>
                      </div>
                      <p className="text-xs font-bold text-slate-900">Documents available:</p>
                      <div className="space-y-2">
                        {demoDigiLockerDocuments.map((item) => (
                          <div key={item.type} className="p-3 rounded-xl border border-slate-200 bg-slate-50 flex items-center justify-between gap-3">
                            <div className="flex items-center gap-2"><FileText className="w-4 h-4 text-blue-600" /><div><p className="text-xs font-bold text-slate-900">{item.title}</p><span className="text-[10px] text-emerald-700 font-semibold">Verified • Demo</span></div></div>
                            <button
                              type="button"
                              onClick={() => handleDemoDocumentSelect(item.type)}
                              disabled={Boolean(isFetchingDemoDocument) || selectedDemoDocument === item.type}
                              className="px-3 py-1.5 rounded-lg bg-blue-600 text-white text-[11px] font-bold disabled:bg-emerald-600"
                            >{isFetchingDemoDocument === item.type ? 'Fetching document...' : selectedDemoDocument === item.type ? 'Added' : 'Select'}</button>
                          </div>
                        ))}
                      </div>
                      {selectedDemoDocument && <p className="text-xs font-semibold text-emerald-700">Document received from DigiLocker — Prototype</p>}
                    </>
                  )}
                  <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                    {digiLockerStage !== 'connected' && (
                      <button
                        type="button"
                        onClick={() => setShowDigiLockerConsent(false)}
                        disabled={isDigiLockerConnecting}
                        className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
                      >Cancel</button>
                    )}
                    {digiLockerStage === 'connect' && (
                      <button
                        type="button"
                        onClick={handleDigiLockerConnectFlow}
                        disabled={!digiLockerMobile.trim()}
                        className="px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-50"
                      >Continue</button>
                    )}
                    {digiLockerStage === 'permission' && (
                      <button
                        type="button"
                        onClick={handleDigiLockerConnectFlow}
                        disabled={isDigiLockerConnecting}
                        className="px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-60 flex items-center gap-2"
                      >
                        {isDigiLockerConnecting ? <><RefreshCw className="w-3.5 h-3.5 animate-spin" />Connecting to DigiLocker...</> : 'Allow'}
                      </button>
                    )}
                    {digiLockerStage === 'connected' && (
                      <button
                        type="button"
                        onClick={() => { setShowDigiLockerConsent(false); setAuthMode('LOGIN'); }}
                        className="px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700"
                      >Continue Existing Flow</button>
                    )}
                  </div>
                </div>
              ) : (
              <>
              {/* Consent Details */}
              <div className="my-5 space-y-4">
                <div>
                  <h4 className="text-sm font-bold text-slate-900 mb-1">
                    {t('digiLockerConsentPrompt')}
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Samanvay is requesting your authorized permission to securely retrieve and verify the following eligible digital certificates:
                  </p>
                </div>

                <div className="bg-slate-50 rounded-xl p-3 border border-slate-200 space-y-2">
                  <div className="flex items-center gap-2.5 text-xs text-slate-700 font-medium">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Aadhaar Identity Card (UIDAI)</span>
                  </div>
                  <div className="flex items-center gap-2.5 text-xs text-slate-700 font-medium">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Integrated Caste / Community Certificate (Revenue Dept)</span>
                  </div>
                  <div className="flex items-center gap-2.5 text-xs text-slate-700 font-medium">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Annual Family Income Certificate (Tahsil Office)</span>
                  </div>
                  <div className="flex items-center gap-2.5 text-xs text-slate-700 font-medium">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>White Ration Card (Civil Supplies)</span>
                  </div>
                  <div className="flex items-center gap-2.5 text-xs text-slate-700 font-medium">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Secondary School Examination Marks Memo (State Board)</span>
                  </div>
                </div>

                <p className="text-[11px] text-slate-500 italic">
                  * Note: Your DigiLocker password is never stored or accessed by Samanvay. Consent is read-only for public scheme processing.
                </p>
              </div>

              {/* Actions */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowDigiLockerConsent(false)}
                  disabled={isDigiLockerConnecting}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition-all"
                >
                  Cancel
                </button>

                <button
                  id="digilocker-confirm-consent-btn"
                  type="button"
                  onClick={handleDigiLockerConnectFlow}
                  disabled={isDigiLockerConnecting}
                  className="px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 shadow-md shadow-blue-600/30 flex items-center gap-2 transition-all cursor-pointer disabled:opacity-60"
                >
                  {isDigiLockerConnecting ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Connecting & Verifying...</span>
                    </>
                  ) : digiLockerSuccess ? (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300" />
                      <span>✓ DigiLocker Connected</span>
                    </>
                  ) : (
                    <>
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>Allow & Connect DigiLocker</span>
                    </>
                  )}
                </button>
              </div>
              </>
              )}
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div
      id="samanvay-auth-page"
      className="min-h-screen bg-slate-50 text-slate-900 flex flex-col justify-between selection:bg-emerald-200"
    >
      {/* Top Header Bar with Language Selector and Subtle Live Demo Access */}
      <header className="w-full max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between border-b border-slate-200 bg-white">
        <div className="flex items-center gap-3">
          <SamanvayLogo size="md" showTagline={false} />
          <div className="hidden sm:block">
            <span className="text-xs font-semibold uppercase tracking-widest text-emerald-700">
              National Direct Citizen Portal
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Multilingual Selector */}
          <div
            id="auth-language-selector"
            className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 shadow-xs"
          >
            <div className="flex items-center gap-1 px-2 text-slate-500">
              <Globe className="w-3.5 h-3.5" />
            </div>
            <div className="flex items-center gap-0.5">
              {languages.map((lang) => (
                <button
                  key={lang.code}
                  id={`auth-lang-${lang.code}`}
                  onClick={() => setLanguage(lang.code)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                    language === lang.code
                      ? 'bg-emerald-600 text-white font-semibold shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                  }`}
                >
                  {lang.native}
                </button>
              ))}
            </div>
          </div>

          {/* Presentation Live Demo Trigger */}
          <button
            id="auth-live-demo-button"
            onClick={() => {
              if (onOpenLiveDemo) onOpenLiveDemo();
              else setIsLiveDemoModalOpen(true);
            }}
            className="hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium bg-slate-900 hover:bg-slate-800 text-white border border-slate-800 transition-all shadow-xs"
            title="Open Presentation Controls"
          >
            <Radio className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            <span>{t('liveDemo')}</span>
          </button>
        </div>
      </header>

      {/* Main Authentication Center */}
      <main className="flex-1 flex items-center justify-center p-4 sm:p-6 lg:p-8">
        <div className="w-full max-w-xl">
          {/* Platform Identity Title */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-medium mb-4">
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
              <span>Unified Public Services & Direct Grievance Redressal</span>
            </div>

            <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-900 mb-2">
              {t('appName')}
            </h1>
            <p className="text-lg font-medium text-emerald-700 mb-2">{t('tagline')}</p>
            <p className="text-sm text-slate-600 max-w-md mx-auto leading-relaxed">
              {t('authHeadline')}
            </p>
          </div>

          {/* Authentication Container Box */}
          <div
            id="auth-main-card"
            className="bg-white rounded-2xl border border-slate-200 shadow-xl p-6 sm:p-8 relative overflow-hidden"
          >
            {/* Mode Switcher Tabs */}
            <div
              id="auth-tabs"
              className="grid grid-cols-3 p-1 rounded-xl bg-slate-100 border border-slate-200 mb-6 gap-1"
            >
              <button
                id="tab-login"
                type="button"
                onClick={() => setAuthMode('LOGIN')}
                className={`py-2 text-xs sm:text-sm font-semibold rounded-lg transition-all ${
                  authMode === 'LOGIN'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {t('login')}
              </button>

              <button
                id="tab-signup"
                type="button"
                onClick={() => setAuthMode('SIGNUP')}
                className={`py-2 text-xs sm:text-sm font-semibold rounded-lg transition-all ${
                  authMode === 'SIGNUP'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {t('signUp')}
              </button>

              <button
                id="tab-digilocker"
                type="button"
                onClick={() => setAuthMode('DIGILOCKER')}
                className={`py-2 text-xs sm:text-sm font-semibold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                  authMode === 'DIGILOCKER'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-blue-700'
                }`}
              >
                <ShieldCheck className="w-3.5 h-3.5 text-blue-500" />
                <span>DigiLocker</span>
              </button>
            </div>

            {/* TAB 1: LOGIN */}
            {authMode === 'LOGIN' && (
              <form onSubmit={handleLoginSubmit} className="space-y-4 animate-in fade-in duration-150">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    {t('enterMobileOrId')}
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                      <UserIcon className="w-4 h-4" />
                    </div>
                    <input
                      id="login-identifier-input"
                      type="text"
                      required
                      value={loginIdentifier}
                      onChange={(e) => setLoginIdentifier(e.target.value)}
                      placeholder="e.g. 9848022338 or SMV-CIT-10245"
                      className="w-full pl-9 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 transition-all font-mono"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-semibold text-slate-700">{t('password')}</label>
                    <button
                      type="button"
                      id="forgot-password-link"
                      onClick={() => setShowForgotPassword(true)}
                      className="text-xs font-medium text-emerald-700 hover:text-emerald-800 hover:underline"
                    >
                      {t('forgotPassword')}
                    </button>
                  </div>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                      <Lock className="w-4 h-4" />
                    </div>
                    <input
                      id="login-password-input"
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      placeholder="••••••••••••"
                      className="w-full pl-9 pr-10 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 transition-all"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <button
                  id="submit-login-button"
                  type="submit"
                  disabled={isLoggingIn}
                  className="w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold rounded-xl transition-all flex items-center justify-center gap-2 shadow-md shadow-emerald-700/20 cursor-pointer disabled:opacity-50"
                >
                  {isLoggingIn ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <>
                      <span>{t('login')}</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>

                {/* Direct DigiLocker One-Click Divider */}
                <div className="relative my-4 text-center">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-slate-200" />
                  </div>
                  <span className="relative px-3 bg-white text-xs text-slate-400">or connect with</span>
                </div>

                <button
                  id="login-digilocker-action-btn"
                  type="button"
                  onClick={() => setShowDigiLockerConsent(true)}
                  className="w-full py-2.5 px-4 bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-semibold rounded-xl border border-blue-200 transition-all flex items-center justify-center gap-2"
                >
                  <ShieldCheck className="w-4 h-4 text-blue-600" />
                  <span>{t('continueWithDigiLocker')}</span>
                </button>
              </form>
            )}

            {/* TAB 2: CREATE ACCOUNT */}
            {authMode === 'SIGNUP' && (
              <form onSubmit={handleSignUpSubmit} className="space-y-3.5 animate-in fade-in duration-150">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Full Legal Name *</label>
                    <input
                      id="signup-name-input"
                      type="text"
                      required
                      value={signupForm.fullName}
                      onChange={(e) => setSignupForm({ ...signupForm, fullName: e.target.value })}
                      placeholder="e.g. Ramesh Varma"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Mobile Number (Aadhaar-linked) *</label>
                    <input
                      id="signup-mobile-input"
                      type="tel"
                      required
                      maxLength={10}
                      value={signupForm.mobile}
                      onChange={(e) => setSignupForm({ ...signupForm, mobile: e.target.value })}
                      placeholder="9848012345"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-emerald-600 font-mono"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Email Address</label>
                    <input
                      id="signup-email-input"
                      type="email"
                      value={signupForm.email}
                      onChange={(e) => setSignupForm({ ...signupForm, email: e.target.value })}
                      placeholder="citizen@example.gov.in"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">District</label>
                    <select
                      id="signup-district-select"
                      value={signupForm.district}
                      onChange={(e) => setSignupForm({ ...signupForm, district: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-hidden focus:border-emerald-600"
                    >
                      <option value="Visakhapatnam">Visakhapatnam</option>
                      <option value="Vijayawada (NTR)">Vijayawada (NTR)</option>
                      <option value="Guntur">Guntur</option>
                      <option value="Tirupati">Tirupati</option>
                      <option value="Kurnool">Kurnool</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">Mandal</label>
                    <input
                      type="text"
                      value={signupForm.mandal}
                      onChange={(e) => setSignupForm({ ...signupForm, mandal: e.target.value })}
                      className="w-full px-2.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">Category</label>
                    <select
                      value={signupForm.socialCategory}
                      onChange={(e) => setSignupForm({ ...signupForm, socialCategory: e.target.value })}
                      className="w-full px-2.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900"
                    >
                      <option value="OBC">OBC / BC</option>
                      <option value="SC">SC</option>
                      <option value="ST">ST</option>
                      <option value="EWS">EWS</option>
                      <option value="General">General</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">Annual Income</label>
                    <input
                      type="number"
                      value={signupForm.annualFamilyIncome}
                      onChange={(e) => setSignupForm({ ...signupForm, annualFamilyIncome: e.target.value })}
                      className="w-full px-2.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900"
                    />
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900 flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                  <span>
                    Upon registration, a permanent <strong>Samanvay Citizen ID</strong> will be generated for seamless single-window public services.
                  </span>
                </div>

                <button
                  id="submit-signup-button"
                  type="submit"
                  disabled={isSigningUp}
                  className="w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold rounded-xl transition-all flex items-center justify-center gap-2 shadow-md shadow-emerald-700/20 cursor-pointer disabled:opacity-50"
                >
                  {isSigningUp ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <>
                      <span>{t('createCitizenAccount')}</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>
            )}

            {/* TAB 3: DIGILOCKER CONNECTION */}
            {authMode === 'DIGILOCKER' && (
              <div className="space-y-4 animate-in fade-in duration-150">
                <div className="p-4 rounded-xl bg-blue-50 border border-blue-200 text-center">
                  <div className="w-12 h-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center mx-auto mb-3 shadow-md">
                    <ShieldCheck className="w-7 h-7" />
                  </div>
                  <h3 className="text-base font-bold text-slate-900 mb-1">
                    {t('connectWithDigiLocker')}
                  </h3>
                  <p className="text-xs text-slate-600 leading-relaxed mb-4">
                    {t('digiLockerAuthDesc')}
                  </p>

                  <div className="bg-white rounded-xl p-3 text-left space-y-2 mb-4 border border-blue-100 shadow-2xs">
                    <div className="flex items-center gap-2 text-xs text-slate-700">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>Instant verification of Aadhaar, Caste & Income records</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-slate-700">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>Zero paper uploads & instant eligibility evaluation</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-slate-700">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>End-to-end digital consent governed by MeitY standards</span>
                    </div>
                  </div>

                  <button
                    id="connect-digilocker-modal-trigger"
                    type="button"
                    onClick={() => setShowDigiLockerConsent(true)}
                    className="w-full py-3 px-4 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-xl transition-all flex items-center justify-center gap-2 shadow-md shadow-blue-700/20 cursor-pointer"
                  >
                    <ShieldCheck className="w-4 h-4" />
                    <span>{t('continueWithDigiLocker')}</span>
                  </button>
                </div>
              </div>
            )}

            {/* Evaluation & Quick Demo Switcher Section */}
            <div className="mt-6 pt-5 border-t border-slate-200">
              <div className="flex items-center justify-between mb-3">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
                  {t('quickDemoAccess')}
                </span>
                <span className="text-[10px] text-slate-400">1-Click Evaluation</span>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <button
                  id="demo-user-citizen"
                  type="button"
                  onClick={() => switchRole('CITIZEN')}
                  className="p-2 rounded-xl bg-slate-50 hover:bg-emerald-50 border border-slate-200 hover:border-emerald-300 text-left transition-all group cursor-pointer"
                >
                  <div className="flex items-center gap-1.5 text-emerald-700 mb-0.5">
                    <UserIcon className="w-3.5 h-3.5" />
                    <span className="text-xs font-bold truncate">Citizen</span>
                  </div>
                  <p className="text-[10px] text-slate-500 truncate">Ananya Reddy</p>
                </button>

                <button
                  id="demo-user-officer"
                  type="button"
                  onClick={() => switchRole('OFFICER')}
                  className="p-2 rounded-xl bg-slate-50 hover:bg-blue-50 border border-slate-200 hover:border-blue-300 text-left transition-all group cursor-pointer"
                >
                  <div className="flex items-center gap-1.5 text-blue-700 mb-0.5">
                    <Building2 className="w-3.5 h-3.5" />
                    <span className="text-xs font-bold truncate">Officer</span>
                  </div>
                  <p className="text-[10px] text-slate-500 truncate">Ravi Kumar</p>
                </button>

                <button
                  id="demo-user-higher-officer"
                  type="button"
                  onClick={() => switchRole('HIGHER_OFFICER')}
                  className="p-2 rounded-xl bg-slate-50 hover:bg-purple-50 border border-slate-200 hover:border-purple-300 text-left transition-all group cursor-pointer"
                >
                  <div className="flex items-center gap-1.5 text-purple-700 mb-0.5">
                    <Layers className="w-3.5 h-3.5" />
                    <span className="text-xs font-bold truncate">Higher Auth</span>
                  </div>
                  <p className="text-[10px] text-slate-500 truncate">Priya Sharma</p>
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="w-full max-w-7xl mx-auto px-4 py-4 text-center text-xs text-slate-500 border-t border-slate-200 bg-white">
        <p>
          Samanvay Platform • Developed for Transparent Public Governance & Citizen Empowerment •
          Digital India & State Citizen Service Architecture
        </p>
      </footer>

      {/* DigiLocker Consent Flow Modal */}
      {showDigiLockerConsent && (
        <div
          id="digilocker-consent-modal"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs animate-in fade-in duration-200"
        >
          <div className="bg-white text-slate-900 rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 relative overflow-hidden">
            {/* Header with DigiLocker Logo */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-md">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-blue-900 text-sm tracking-wide">DIGILOCKER</span>
                    <span className="px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                      Verified Gateway
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500">Government of India • MeriPehchaan</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowDigiLockerConsent(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Consent Details */}
            <div className="my-5 space-y-4">
              <div>
                <h4 className="text-sm font-bold text-slate-900 mb-1">
                  {t('digiLockerConsentPrompt')}
                </h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Samanvay is requesting your authorized permission to securely retrieve and verify the following eligible digital certificates:
                </p>
              </div>

              <div className="bg-slate-50 rounded-xl p-3 border border-slate-200 space-y-2">
                <div className="flex items-center gap-2.5 text-xs text-slate-700 font-medium">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Aadhaar Identity Card (UIDAI)</span>
                </div>
                <div className="flex items-center gap-2.5 text-xs text-slate-700 font-medium">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Integrated Caste / Community Certificate (Revenue Dept)</span>
                </div>
                <div className="flex items-center gap-2.5 text-xs text-slate-700 font-medium">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Annual Family Income Certificate (Tahsil Office)</span>
                </div>
                <div className="flex items-center gap-2.5 text-xs text-slate-700 font-medium">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>White Ration Card (Civil Supplies)</span>
                </div>
                <div className="flex items-center gap-2.5 text-xs text-slate-700 font-medium">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Secondary School Examination Marks Memo (State Board)</span>
                </div>
              </div>

              <p className="text-[11px] text-slate-500 italic">
                * Note: Your DigiLocker password is never stored or accessed by Samanvay. Consent is read-only for public scheme processing.
              </p>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setShowDigiLockerConsent(false)}
                disabled={isDigiLockerConnecting}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition-all"
              >
                Cancel
              </button>

              <button
                id="digilocker-confirm-consent-btn"
                type="button"
                onClick={handleDigiLockerConnectFlow}
                disabled={isDigiLockerConnecting}
                className="px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 shadow-md shadow-blue-600/30 flex items-center gap-2 transition-all cursor-pointer disabled:opacity-60"
              >
                {isDigiLockerConnecting ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Connecting & Verifying...</span>
                  </>
                ) : digiLockerSuccess ? (
                  <>
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300" />
                    <span>✓ DigiLocker Connected</span>
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Allow & Connect DigiLocker</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Forgot Password Modal */}
      {showForgotPassword && (
        <div
          id="forgot-password-modal"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs animate-in fade-in duration-200"
        >
          <div className="bg-slate-900 text-slate-100 rounded-2xl max-w-sm w-full p-6 shadow-2xl border border-slate-750 relative">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <KeyRound className="w-5 h-5 text-teal-400" />
                <h3 className="text-sm font-bold text-white">Reset Account Access</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowForgotPassword(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {!resetOtpSent ? (
              <form onSubmit={handleForgotPasswordSubmit} className="my-4 space-y-3">
                <p className="text-xs text-slate-400">
                  Enter your registered mobile number or email to receive a secure OTP verification code.
                </p>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Mobile or Email
                  </label>
                  <input
                    type="text"
                    required
                    value={resetIdentifier}
                    onChange={(e) => setResetIdentifier(e.target.value)}
                    placeholder="9848022338"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-hidden focus:border-teal-500 font-mono"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full py-2.5 bg-teal-600 hover:bg-teal-500 text-white text-xs font-semibold rounded-xl transition-all"
                >
                  Send OTP Code
                </button>
              </form>
            ) : !resetSuccess ? (
              <form onSubmit={handleVerifyOtpAndReset} className="my-4 space-y-3">
                <div className="p-2.5 rounded-lg bg-teal-950/60 border border-teal-500/30 text-xs text-teal-300">
                  OTP sent to <strong>{resetIdentifier || '98480*****'}</strong>. Enter <strong>1234</strong> for quick demo verification.
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Enter 4-Digit OTP
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={4}
                    value={resetOtp}
                    onChange={(e) => setResetOtp(e.target.value)}
                    placeholder="1234"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-sm text-center tracking-widest text-white focus:outline-hidden focus:border-teal-500 font-mono"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full py-2.5 bg-teal-600 hover:bg-teal-500 text-white text-xs font-semibold rounded-xl transition-all"
                >
                  Verify & Reset Password
                </button>
              </form>
            ) : (
              <div className="my-6 text-center space-y-2">
                <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
                <p className="text-xs font-bold text-white">Access Credentials Verified</p>
                <p className="text-[11px] text-slate-400">Returning to login screen...</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
