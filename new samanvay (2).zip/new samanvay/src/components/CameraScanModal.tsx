import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { Camera, RefreshCw, CheckCircle2, X, Sparkles, FileSearch, ShieldCheck } from 'lucide-react';
import { api } from '../services/api';
import { DocumentType } from '../types';

export const CameraScanModal: React.FC = () => {
  const {
    isCameraModalOpen,
    setIsCameraModalOpen,
    cameraTargetDocType,
    currentUser,
    refreshAllData,
    refreshProfile,
    addNotification,
  } = useApp();

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [detectedDoc, setDetectedDoc] = useState<any>(null);

  // Setup video stream on open
  useEffect(() => {
    if (isCameraModalOpen && !capturedImage) {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        navigator.mediaDevices
          .getUserMedia({ video: { facingMode: 'environment' } })
          .then((mediaStream) => {
            setStream(mediaStream);
            setIsCameraActive(true);
            if (videoRef.current) {
              videoRef.current.srcObject = mediaStream;
            }
          })
          .catch((err) => {
            console.warn('Camera access fallback (simulator active):', err);
            setIsCameraActive(false);
          });
      }
    }

    return () => {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [isCameraModalOpen, capturedImage]);

  const handleCapture = () => {
    // Generate simulated capture snapshot
    const defaultDocType: DocumentType = (cameraTargetDocType as DocumentType) || 'INCOME_CERTIFICATE';
    setCapturedImage('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjMwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZjhmYXBjIi8+PC9zdmc+');

    if (stream) {
      stream.getTracks().forEach((track) => track.stop());
      setStream(null);
    }

    setIsAnalyzing(true);

    // Simulated OCR extraction
    setTimeout(() => {
      let docTitle = 'Income Certificate';
      let docType = defaultDocType;
      let issuer = 'Tahsildar Revenue Office';

      if (defaultDocType === 'CASTE_CERTIFICATE' || !cameraTargetDocType) {
        docTitle = 'Caste & Community Certificate';
        docType = 'CASTE_CERTIFICATE';
        issuer = 'Revenue Department, Govt of Andhra Pradesh';
      } else if (defaultDocType === 'INCOME_CERTIFICATE') {
        docTitle = 'Annual Income Certificate';
        issuer = 'Mandal Revenue Officer';
      } else if (defaultDocType === 'MARKS_MEMO') {
        docTitle = 'Board Consolidated Marks Memo';
        issuer = 'State Board of Education';
      }

      const ocrResult = {
        type: docType,
        title: docTitle,
        issuer,
        documentNumber: `AP-${docType.substring(0, 3)}-2025-${Math.floor(10000 + Math.random() * 90000)}`,
        extractedDetails: {
          'Document Type': docTitle,
          'Issuing Authority': issuer,
          'Citizen Name': currentUser.name,
          'QR Stamp': 'Verified Statutory Seal',
          'Confidence': '99.2% via Samanvay Optical Engine',
        },
      };

      setDetectedDoc(ocrResult);
      setIsAnalyzing(false);
    }, 1800);
  };

  const handleConfirmAndSave = async () => {
    if (!detectedDoc) return;

    try {
      await api.uploadDocument({
        citizenId: currentUser.citizenId || 'SMV-CIT-10245',
        type: detectedDoc.type,
        title: detectedDoc.title,
        issuer: detectedDoc.issuer,
        documentNumber: detectedDoc.documentNumber,
        source: 'CAMERA_SCAN',
        extractedDetails: detectedDoc.extractedDetails,
      });

      await refreshAllData();
      await refreshProfile();

      addNotification(
        'success',
        'Document Scanned & Added',
        `${detectedDoc.title} has been successfully verified and added to your profile.`
      );

      handleClose();
    } catch (err) {
      console.error('Scan save error:', err);
    }
  };

  const handleClose = () => {
    if (stream) {
      stream.getTracks().forEach((track) => track.stop());
    }
    setStream(null);
    setCapturedImage(null);
    setDetectedDoc(null);
    setIsAnalyzing(false);
    setIsCameraModalOpen(false);
  };

  if (!isCameraModalOpen) return null;

  return (
    <div
      id="camera-scan-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200"
    >
      <div
        id="camera-scan-dialog"
        className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 relative overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-slate-900 flex items-center justify-center text-white">
              <Camera className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Scan & Upload Document</h3>
              <p className="text-xs text-slate-500">Instant AI OCR & Automatic Identification</p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Viewfinder / Capture View */}
        <div className="my-5">
          {!capturedImage ? (
            <div className="relative rounded-2xl overflow-hidden bg-slate-900 aspect-4/3 flex flex-col items-center justify-center border-2 border-slate-700 shadow-inner">
              {isCameraActive ? (
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  className="w-full h-full object-cover"
                />
              ) : (
                /* High-fidelity camera simulation preview */
                <div className="w-full h-full flex flex-col items-center justify-center bg-linear-to-b from-slate-800 to-slate-900 text-slate-300 p-6 text-center">
                  <div className="w-14 h-14 rounded-2xl bg-slate-700/60 border border-slate-600 flex items-center justify-center text-emerald-400 mb-3 shadow-lg">
                    <FileSearch className="w-7 h-7 animate-pulse" />
                  </div>
                  <p className="text-xs font-semibold text-white">High-Resolution Document Scanner</p>
                  <p className="text-[11px] text-slate-400 mt-1 max-w-xs">
                    Position document inside the frame. The system will automatically detect text, seals, and issuing authority.
                  </p>
                </div>
              )}

              {/* Viewfinder Reticle & Laser Scan effect */}
              <div className="absolute inset-4 border-2 border-dashed border-emerald-400/70 rounded-xl pointer-events-none flex flex-col justify-between p-2">
                <div className="flex justify-between text-[10px] text-emerald-400 font-mono">
                  <span>[ALIGN DOCUMENT]</span>
                  <span>99.4% AUTO-ALIGN</span>
                </div>
                <div className="w-full h-0.5 bg-linear-to-r from-transparent via-emerald-400 to-transparent animate-bounce opacity-80"></div>
                <div className="flex justify-between text-[10px] text-emerald-400 font-mono">
                  <span>GOVT OF AP / INDIA</span>
                  <span>SECURITY SEAL</span>
                </div>
              </div>
            </div>
          ) : (
            /* Analysis & Detected Details Result */
            <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
              {isAnalyzing ? (
                <div className="py-8 flex flex-col items-center justify-center text-center">
                  <RefreshCw className="w-8 h-8 text-emerald-600 animate-spin mb-3" />
                  <p className="text-xs font-bold text-slate-900">Scanning & Extracting Certificate Details...</p>
                  <p className="text-[11px] text-slate-500 mt-0.5">Matching government digital verification templates</p>
                </div>
              ) : detectedDoc ? (
                <div>
                  <div className="flex items-center gap-2 text-emerald-700 font-bold text-xs mb-3">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Document Recognized: {detectedDoc.title}</span>
                  </div>

                  <div className="bg-white rounded-xl p-3 border border-slate-200 space-y-1.5 text-xs">
                    <div className="flex justify-between py-1 border-b border-slate-100">
                      <span className="text-slate-500">Document Type:</span>
                      <span className="font-semibold text-slate-900">{detectedDoc.title}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-100">
                      <span className="text-slate-500">Certificate No:</span>
                      <span className="font-mono font-semibold text-slate-900">{detectedDoc.documentNumber}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-100">
                      <span className="text-slate-500">Issuing Authority:</span>
                      <span className="font-semibold text-slate-900">{detectedDoc.issuer}</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span className="text-slate-500">Citizen Name:</span>
                      <span className="font-semibold text-slate-900">{currentUser.name}</span>
                    </div>
                  </div>
                </div>
              ) : null}
            </div>
          )}
        </div>

        {/* Action Controls */}
        <div className="flex items-center justify-end gap-2.5 pt-2">
          {!capturedImage ? (
            <button
              id="btn-capture-scan"
              onClick={handleCapture}
              className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition-all shadow-md flex items-center justify-center gap-2"
            >
              <Camera className="w-4 h-4" />
              <span>Capture & Identify Document</span>
            </button>
          ) : (
            <>
              <button
                onClick={() => {
                  setCapturedImage(null);
                  setDetectedDoc(null);
                }}
                className="px-4 py-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-xs font-semibold text-slate-700"
              >
                Retake
              </button>
              <button
                id="btn-confirm-save-doc"
                onClick={handleConfirmAndSave}
                disabled={isAnalyzing || !detectedDoc}
                className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-colors disabled:opacity-50 flex items-center gap-1.5"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Confirm & Add to Profile</span>
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
