import React from 'react';

interface SamanvayCoordinationBackgroundProps {
  enabled?: boolean;
}

export const SamanvayCoordinationBackground: React.FC<SamanvayCoordinationBackgroundProps> = ({ enabled = true }) => {
  if (!enabled) return null;

  return (
    <div className="samanvay-coordination-background" aria-hidden="true">
      <svg viewBox="0 0 1600 900" preserveAspectRatio="xMidYMid slice" role="presentation">
        <defs>
          <radialGradient id="samanvay-coordination-halo">
            <stop offset="0" stopColor="#dff8ff" stopOpacity="0.75" />
            <stop offset="0.55" stopColor="#bae6fd" stopOpacity="0.2" />
            <stop offset="1" stopColor="#bae6fd" stopOpacity="0" />
          </radialGradient>
          <linearGradient id="samanvay-coordination-line" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#0f4c81" stopOpacity="0.04" />
            <stop offset="0.5" stopColor="#38bdf8" stopOpacity="0.5" />
            <stop offset="1" stopColor="#14b8a6" stopOpacity="0.08" />
          </linearGradient>
          <filter id="samanvay-coordination-glow" x="-100%" y="-100%" width="300%" height="300%">
            <feGaussianBlur stdDeviation="5" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        <circle className="samanvay-coordination-halo" cx="800" cy="430" r="230" fill="url(#samanvay-coordination-halo)" />
        <g className="samanvay-coordination-routes">
          <path id="route-citizen" d="M70 160 C300 190 430 300 800 430" />
          <path id="route-services" d="M1530 150 C1260 180 1080 310 800 430" />
          <path id="route-applications" d="M70 750 C330 650 510 560 800 430" />
          <path id="route-complaints" d="M1530 750 C1260 660 1080 550 800 430" />
          <path id="route-departments" d="M800 430 C800 270 820 160 900 55" />
          <path id="route-officers" d="M800 430 C800 590 780 730 700 855" />
        </g>

        <g className="samanvay-coordination-nodes" filter="url(#samanvay-coordination-glow)">
          <circle cx="70" cy="160" r="5" />
          <circle cx="1530" cy="150" r="5" />
          <circle cx="70" cy="750" r="5" />
          <circle cx="1530" cy="750" r="5" />
          <circle cx="900" cy="55" r="4" />
          <circle cx="700" cy="855" r="4" />
          <circle className="samanvay-coordination-center" cx="800" cy="430" r="9" />
        </g>

        <g className="samanvay-coordination-travelers">
          <circle r="4"><animateMotion dur="16s" repeatCount="indefinite"><mpath href="#route-citizen" /></animateMotion></circle>
          <circle r="3"><animateMotion dur="20s" begin="-7s" repeatCount="indefinite"><mpath href="#route-services" /></animateMotion></circle>
          <circle r="3"><animateMotion dur="18s" begin="-11s" repeatCount="indefinite"><mpath href="#route-applications" /></animateMotion></circle>
          <circle r="4"><animateMotion dur="22s" begin="-13s" repeatCount="indefinite"><mpath href="#route-complaints" /></animateMotion></circle>
        </g>
      </svg>
    </div>
  );
};
