import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Role } from '../types';
import {
  X,
  Play,
  RotateCcw,
  Sparkles,
  Radio,
  User,
  ShieldCheck,
  Building2,
  AlertCircle,
  GraduationCap,
  Zap,
  CheckCircle2,
  SlidersHorizontal,
} from 'lucide-react';
import { api } from '../services/api';

type DemoScenario = 'SCHOLARSHIP' | 'GRIEVANCE';
type DemoFlowMode = 'NORMAL' | 'SLA_ESCALATION';

export const LiveDemoModal: React.FC = () => {
  const {
    isLiveDemoModalOpen,
    setIsLiveDemoModalOpen,
    activeRole,
    switchRole,
    isRealTimeConnected,
    resetDemoData,
    grievances,
    services,
    setSelectedService,
    setActiveTab,
    addNotification,
    refreshAllData,
    demoDesk,
  } = useApp();

  const [selectedScenario, setSelectedScenario] = useState<DemoScenario>('SCHOLARSHIP');
  const [selectedFlowMode, setSelectedFlowMode] = useState<DemoFlowMode>('NORMAL');
  const [isStarting, setIsStarting] = useState(false);
  const [isResetting, setIsResetting] = useState(false);

  if (!isLiveDemoModalOpen) return null;

  const handleStartDemo = async () => {
    setIsStarting(true);

    try {
      if (selectedScenario === 'SCHOLARSHIP') {
        // Switch to Citizen and open the Scholarship Scheme
        await switchRole('CITIZEN');
        setActiveTab('SERVICES');
        const scholarshipService = services.find((s) => s.id === 'SCH-POST-MATRIC') || services[0];
        if (scholarshipService) {
          setSelectedService(scholarshipService);
        }
        addNotification(
          'info',
          'Scholarship Demo Active',
          'Citizen view ready: Post-Matric Scholarship Scheme with instant pre-filled eligibility.'
        );
      } else if (selectedScenario === 'GRIEVANCE') {
        if (selectedFlowMode === 'SLA_ESCALATION') {
          // Trigger SLA breach on active grievance and switch to Higher Officer
          const targetGrv = grievances.find((g) => g.status !== 'RESOLVED') || grievances[0];
          if (targetGrv) {
            await api.simulateSlaBreach(targetGrv.id);
            await refreshAllData();
            await switchRole('HIGHER_OFFICER');
            setActiveTab('HIGHER_OFFICER_DESK');
            addNotification(
              'warning',
              'SLA Breach Escalation Triggered',
              `Grievance ${targetGrv.id} timer exceeded 7-day limit. Auto-escalated to Higher Officer Desk.`
            );
          }
        } else {
          // Normal grievance submission flow
          await switchRole('CITIZEN');
          setActiveTab('GRIEVANCES');
          addNotification(
            'info',
            'Grievance Redressal Demo Active',
            'Citizen view ready: Report civic problem with intelligent automated department routing.'
          );
        }
      }

      setIsStarting(false);
      setIsLiveDemoModalOpen(false);
    } catch (err) {
      console.error('Failed to start demo:', err);
      setIsStarting(false);
    }
  };

  const handleReset = async () => {
    setIsResetting(true);
    try {
      await resetDemoData();
      setIsResetting(false);
      addNotification('success', 'Demo Data Cleared', 'All applications, documents, and grievances cleared.');
    } catch (err) {
      console.error('Reset error:', err);
      setIsResetting(false);
    }
  };

  const handleSimulateBreachDirect = async () => {
    const targetGrv = grievances.find((g) => g.status !== 'RESOLVED' && !g.isSlaBreached) || grievances[0];
    if (targetGrv) {
      try {
        await api.simulateSlaBreach(targetGrv.id);
        await refreshAllData();
        addNotification(
          'warning',
          'SLA Breach Simulated',
          `Grievance ${targetGrv.id} 7-day limit exceeded & escalated to Higher Officer.`
        );
      } catch (err) {
        console.error('Simulation error:', err);
      }
    }
  };

  return (
    <div
      id="live-demo-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150"
      onClick={(e) => {
        if (e.target === e.currentTarget) setIsLiveDemoModalOpen(false);
      }}
    >
      <div
        id="live-demo-modal-content"
        className="w-full max-w-xl rounded-2xl bg-white border border-slate-200 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-150 flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center">
              <SlidersHorizontal className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-tight">
                Samanvay Live Demo
              </h2>
              <p className="text-[11px] text-slate-400">
                Interactive presentation controls & cross-role workflows
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Live Sync Status */}
            <div
              className={`flex items-center gap-1.5 px-2.5 py-0.5 rounded-full border text-[10px] font-semibold ${
                isRealTimeConnected
                  ? 'bg-emerald-950/90 border-emerald-700 text-emerald-300'
                  : 'bg-amber-950/90 border-amber-700 text-amber-300'
              }`}
            >
              <Radio className={`w-3 h-3 ${isRealTimeConnected ? 'animate-pulse text-emerald-400' : ''}`} />
              <span>{isRealTimeConnected ? 'Live Sync Active' : 'Polling'}</span>
            </div>

            <button
              id="btn-close-demo-modal"
              onClick={() => setIsLiveDemoModalOpen(false)}
              className="w-8 h-8 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 flex items-center justify-center transition-colors"
              aria-label="Close demo modal"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-6 overflow-y-auto">
          {/* Section 1: Role Switcher */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-500">
                1. Select Active Role
              </label>
              <span className="text-[11px] text-slate-400">Switch views instantly</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
              {/* Citizen Role */}
              <button
                id="modal-role-citizen"
                onClick={async () => {
                  await switchRole('CITIZEN');
                  setIsLiveDemoModalOpen(false);
                  addNotification('info', 'Switched to Citizen Role', 'Citizen dashboard active (Ananya Reddy).');
                }}
                className={`p-3 rounded-xl border-2 text-left transition-all flex flex-col justify-between ${
                  activeRole === 'CITIZEN'
                    ? 'border-emerald-600 bg-emerald-50/70 text-emerald-950 shadow-xs ring-2 ring-emerald-500/20'
                    : 'border-slate-200 bg-white hover:border-slate-300 text-slate-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="w-6 h-6 rounded-md bg-emerald-100 text-emerald-700 flex items-center justify-center text-xs font-bold">
                    <User className="w-3.5 h-3.5" />
                  </span>
                  {activeRole === 'CITIZEN' && (
                    <span className="w-2 h-2 rounded-full bg-emerald-600"></span>
                  )}
                </div>
                <div className="mt-2">
                  <span className="text-xs font-bold block">Citizen</span>
                  <span className="text-[10px] text-slate-500 block truncate">Ananya Reddy</span>
                </div>
              </button>

              {/* Department Officer Role */}
              <button
                id="modal-role-officer"
                onClick={async () => {
                  await switchRole('OFFICER', 'PUBLIC_SERVICES');
                  setIsLiveDemoModalOpen(false);
                  addNotification('info', 'Switched to Officer Role', 'Department Officer Workbench active (Ravi Kumar).');
                }}
                className={`p-3 rounded-xl border-2 text-left transition-all flex flex-col justify-between ${
                    demoDesk === 'PUBLIC_SERVICES'
                    ? 'border-blue-600 bg-blue-50/70 text-blue-950 shadow-xs ring-2 ring-blue-500/20'
                    : 'border-slate-200 bg-white hover:border-slate-300 text-slate-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="w-6 h-6 rounded-md bg-blue-100 text-blue-700 flex items-center justify-center text-xs font-bold">
                    <Building2 className="w-3.5 h-3.5" />
                  </span>
                  {activeRole === 'OFFICER' && (
                    <span className="w-2 h-2 rounded-full bg-blue-600"></span>
                  )}
                </div>
                <div className="mt-2">
                  <span className="text-xs font-bold block">Officer</span>
                  <span className="text-[10px] text-slate-500 block truncate">Ravi Kumar</span>
                </div>
              </button>

              {/* Higher Officer Role */}
              <button
                id="modal-role-higher-officer"
                onClick={async () => {
                  await switchRole('HIGHER_OFFICER', 'PUBLIC_SERVICES_HIGHER');
                  setIsLiveDemoModalOpen(false);
                  addNotification('info', 'Switched to Higher Authority', 'State Monitoring Dashboard active (Priya Sharma).');
                }}
                className={`p-3 rounded-xl border-2 text-left transition-all flex flex-col justify-between ${
                    demoDesk === 'PUBLIC_SERVICES_HIGHER'
                    ? 'border-purple-600 bg-purple-50/70 text-purple-950 shadow-xs ring-2 ring-purple-500/20'
                    : 'border-slate-200 bg-white hover:border-slate-300 text-slate-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="w-6 h-6 rounded-md bg-purple-100 text-purple-700 flex items-center justify-center text-xs font-bold">
                    <ShieldCheck className="w-3.5 h-3.5" />
                  </span>
                  {activeRole === 'HIGHER_OFFICER' && (
                    <span className="w-2 h-2 rounded-full bg-purple-600"></span>
                  )}
                </div>
                <div className="mt-2">
                  <span className="text-xs font-bold block">Higher Officer</span>
                  <span className="text-[10px] text-slate-500 block truncate">Priya Sharma</span>
                </div>
              </button>

              <button
                id="modal-role-grievance-officer"
                onClick={async () => {
                  await switchRole('OFFICER', 'GRIEVANCES');
                  setIsLiveDemoModalOpen(false);
                  setActiveTab('OFFICER_DESK');
                  addNotification('info', 'Switched to Grievance Officer', 'Complaint operations desk active.');
                }}
                className={`p-3 rounded-xl border-2 text-left transition-all ${demoDesk === 'GRIEVANCES' ? 'border-amber-600 bg-amber-50/70' : 'border-slate-200 bg-white hover:border-slate-300'} text-slate-700`}
              >
                <AlertCircle className="w-5 h-5 text-amber-600 mb-2" />
                <span className="text-xs font-bold block">Grievance Officer</span>
                <span className="text-[10px] text-slate-500 block">Complaint Desk</span>
              </button>

              <button
                id="modal-role-grievance-higher-officer"
                onClick={async () => {
                  await switchRole('HIGHER_OFFICER', 'GRIEVANCES_HIGHER');
                  setIsLiveDemoModalOpen(false);
                  setActiveTab('HIGHER_OFFICER_DESK');
                  addNotification('info', 'Switched to Grievance Higher Officer', 'Escalated complaint monitoring desk active.');
                }}
                className={`p-3 rounded-xl border-2 text-left transition-all ${demoDesk === 'GRIEVANCES_HIGHER' ? 'border-purple-600 bg-purple-50/70' : 'border-slate-200 bg-white hover:border-slate-300'} text-slate-700`}
              >
                <ShieldCheck className="w-5 h-5 text-purple-600 mb-2" />
                <span className="text-xs font-bold block">Grievance Higher Officer</span>
                <span className="text-[10px] text-slate-500 block">Escalation Desk</span>
              </button>
            </div>
          </div>

          {/* Section 2: Scenario Selection */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-500">
                2. Select Scenario
              </label>
              <span className="text-[11px] text-slate-400">Choose demonstration track</span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {/* Scenario 1: Scholarship Application */}
              <button
                id="scenario-btn-scholarship"
                onClick={() => setSelectedScenario('SCHOLARSHIP')}
                className={`p-3.5 rounded-xl border-2 text-left transition-all ${
                  selectedScenario === 'SCHOLARSHIP'
                    ? 'border-slate-900 bg-slate-50 shadow-xs'
                    : 'border-slate-200 bg-white hover:border-slate-300'
                }`}
              >
                <div className="flex items-center gap-2">
                  <GraduationCap className="w-4 h-4 text-emerald-600" />
                  <span className="text-xs font-bold text-slate-900">Scholarship Application</span>
                </div>
                <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                  Post-Matric Scholarship pre-verification, document auto-fetch & officer sanction.
                </p>
              </button>

              {/* Scenario 2: Grievance */}
              <button
                id="scenario-btn-grievance"
                onClick={() => setSelectedScenario('GRIEVANCE')}
                className={`p-3.5 rounded-xl border-2 text-left transition-all ${
                  selectedScenario === 'GRIEVANCE'
                    ? 'border-slate-900 bg-slate-50 shadow-xs'
                    : 'border-slate-200 bg-white hover:border-slate-300'
                }`}
              >
                <div className="flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-amber-600" />
                  <span className="text-xs font-bold text-slate-900">Grievance Redressal</span>
                </div>
                <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                  Civic issue report, smart department auto-routing, SLA clock & resolution.
                </p>
              </button>
            </div>
          </div>

          {/* Section 3: Demonstration Scenario Mode (Normal vs SLA Escalation) */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-500">
                3. Demonstration Flow Mode
              </label>
              <span className="text-[11px] text-slate-400">Resolution vs. SLA Breach</span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <button
                id="mode-btn-normal"
                onClick={() => setSelectedFlowMode('NORMAL')}
                className={`p-3 rounded-xl border-2 text-left transition-all ${
                  selectedFlowMode === 'NORMAL'
                    ? 'border-emerald-600 bg-emerald-50/50 text-emerald-950'
                    : 'border-slate-200 bg-white hover:border-slate-300 text-slate-700'
                }`}
              >
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span className="text-xs font-bold">Normal Flow</span>
                </div>
                <p className="text-[10px] text-slate-500 mt-0.5">
                  Standard application lifecycle within statutory 7-day limits.
                </p>
              </button>

              <button
                id="mode-btn-escalation"
                onClick={() => setSelectedFlowMode('SLA_ESCALATION')}
                className={`p-3 rounded-xl border-2 text-left transition-all ${
                  selectedFlowMode === 'SLA_ESCALATION'
                    ? 'border-rose-600 bg-rose-50/50 text-rose-950'
                    : 'border-slate-200 bg-white hover:border-slate-300 text-slate-700'
                }`}
              >
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-rose-600" />
                  <span className="text-xs font-bold">SLA Escalation</span>
                </div>
                <p className="text-[10px] text-slate-500 mt-0.5">
                  Simulate statutory deadline expiry & auto-escalation to Higher Officer.
                </p>
              </button>
            </div>
          </div>
        </div>

        {/* Modal Footer Controls */}
        <div className="px-6 py-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between shrink-0">
          <button
            id="btn-modal-reset-demo"
            onClick={handleReset}
            disabled={isResetting}
            className="px-4 py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 text-xs font-semibold transition-colors flex items-center gap-1.5"
          >
            <RotateCcw className={`w-3.5 h-3.5 text-slate-500 ${isResetting ? 'animate-spin' : ''}`} />
            <span>{isResetting ? 'Resetting...' : 'Reset Demo'}</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              id="btn-modal-start-demo"
              onClick={handleStartDemo}
              disabled={isStarting}
              className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all shadow-md flex items-center gap-2"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>{isStarting ? 'Loading...' : 'Start Demo'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
