import React from 'react';

interface SamanvayLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showTagline?: boolean;
  inverted?: boolean;
  className?: string;
}

export const SamanvayLogo: React.FC<SamanvayLogoProps> = ({
  size = 'md',
  showTagline = true,
  inverted = false,
  className = '',
}) => {
  const iconDimensions = {
    sm: 'w-7 h-7',
    md: 'w-9 h-9',
    lg: 'w-12 h-12',
    xl: 'w-16 h-16',
  };

  const titleSizes = {
    sm: 'text-lg tracking-wider',
    md: 'text-xl tracking-wider',
    lg: 'text-2xl tracking-widest',
    xl: 'text-3xl tracking-widest',
  };

  const taglineSizes = {
    sm: 'text-[10px]',
    md: 'text-xs',
    lg: 'text-sm',
    xl: 'text-base',
  };

  return (
    <div id="samanvay-logo" className={`flex items-center gap-3 select-none ${className}`}>
      {/* Emblem: Connected Geometric Nodes (Citizen, Government, Services, Coordination) */}
      <div className={`relative flex items-center justify-center ${iconDimensions[size]} shrink-0`}>
        <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-sm" fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Outer Harmony Rings */}
          <circle cx="50" cy="50" r="44" stroke="#0F172A" strokeWidth="2.5" strokeDasharray="3 3" opacity="0.25" />
          
          {/* Interlocking S-curves representing Seamless Integration & Coordination */}
          <path
            d="M 28 65 C 28 35, 72 65, 72 35"
            stroke="#0284C7"
            strokeWidth="7"
            strokeLinecap="round"
          />
          <path
            d="M 35 28 C 65 28, 35 72, 65 72"
            stroke="#F59E0B"
            strokeWidth="7"
            strokeLinecap="round"
          />

          {/* Central Citizen Core Node */}
          <circle cx="50" cy="50" r="9" fill="#0F766E" />
          <circle cx="50" cy="50" r="4.5" fill="#FFFFFF" />

          {/* Interconnected Satellite Nodes (Citizen, Public Office, Service Gateway, Verification) */}
          <circle cx="28" cy="65" r="5.5" fill="#0284C7" />
          <circle cx="72" cy="35" r="5.5" fill="#0284C7" />
          <circle cx="35" cy="28" r="5.5" fill="#F59E0B" />
          <circle cx="65" cy="72" r="5.5" fill="#F59E0B" />
        </svg>
      </div>

      <div className="flex flex-col">
        <div className="flex items-center gap-1.5">
          <span
            className={`font-black tracking-widest ${titleSizes[size]} ${
              inverted ? 'text-white' : 'text-slate-900'
            }`}
            style={{ fontFamily: 'system-ui, -apple-system, sans-serif' }}
          >
            SAMANVAY
          </span>
          <span className="inline-block w-2 h-2 rounded-full bg-emerald-600 mb-0.5"></span>
        </div>
        {showTagline && (
          <span
            className={`font-medium ${taglineSizes[size]} ${
              inverted ? 'text-slate-300' : 'text-slate-600'
            }`}
          >
            One Citizen. One Journey.
          </span>
        )}
      </div>
    </div>
  );
};
