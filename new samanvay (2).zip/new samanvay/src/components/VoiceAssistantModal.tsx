import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { Mic, MicOff, Sparkles, X, Volume2, ArrowRight, CheckCircle2 } from 'lucide-react';
import { api } from '../services/api';

export const VoiceAssistantModal: React.FC = () => {
  const {
    isVoiceModalOpen,
    setIsVoiceModalOpen,
    language,
    t,
    setActiveTab,
    setSelectedService,
    services,
    addNotification,
  } = useApp();

  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [parsedResult, setParsedResult] = useState<any>(null);

  // Quick preset voice prompts tailored to the 5 languages
  const samplePromptsByLang: Record<string, Array<{ text: string; label: string; intentDesc: string }>> = {
    te: [
      { text: 'నాకు స్కాలర్షిప్ కావాలి', label: 'స్కాలర్‌షిప్ దరఖాస్తు', intentDesc: 'Post-Matric Scholarship' },
      { text: 'మా వీధిలో మంచినీటి పైప్‌లైన్ లీక్ అవుతోంది', label: 'నీటి సమస్య ఫిర్యాదు', intentDesc: 'Water Pipeline Grievance' },
      { text: 'కాలేజ్ అడ్మిషన్ కోసం ఆదాయ సర్టిఫికెట్ కావాలి', label: 'ఆదాయ ధృవీకరణ పత్రం', intentDesc: 'Income Certificate' },
      { text: 'వృద్ధాప్య పింఛను ఎలా పొందాలి?', label: 'వృద్ధుల పింఛను', intentDesc: 'Senior Citizen Pension' },
    ],
    en: [
      { text: 'I want to apply for post matric scholarship', label: 'Scholarship Application', intentDesc: 'Post-Matric Scholarship' },
      { text: 'Drinking water pipeline leaking near primary school', label: 'Water Leak Complaint', intentDesc: 'Water Grievance' },
      { text: 'Street light not working in my ward for 5 days', label: 'Streetlight Issue', intentDesc: 'Electricity Grievance' },
      { text: 'I need to apply for income certificate', label: 'Income Certificate', intentDesc: 'Income Certificate' },
    ],
    hi: [
      { text: 'मुझे पोस्ट-मैट्रिक स्कॉलरशिप के लिए आवेदन करना है', label: 'छात्रवृत्ति आवेदन', intentDesc: 'Post-Matric Scholarship' },
      { text: 'हमारे वार्ड में पीने के पानी का पाइप टूटा हुआ है', label: 'पानी की समस्या', intentDesc: 'Water Supply Grievance' },
      { text: 'सड़क पर स्ट्रीट लाइट खराब है', label: 'स्ट्रीट लाइट शिकायत', intentDesc: 'Streetlight Grievance' },
      { text: 'कॉलेज एडमिशन हेतु आय प्रमाणपत्र चाहिए', label: 'आय प्रमाणपत्र', intentDesc: 'Income Certificate' },
    ],
    mr: [
      { text: 'मला उच्च शिक्षणासाठी शिष्यवृत्ती हवी आहे', label: 'शिष्यवृत्ती अर्ज', intentDesc: 'Post-Matric Scholarship' },
      { text: 'आमच्या गल्लीत पाण्याची पाईपलाईन फुटली आहे', label: 'पाणी समस्या तक्रार', intentDesc: 'Water Supply Grievance' },
      { text: 'रस्त्यावरील दिवे अनेक दिवसांपासून बंद आहेत', label: 'स्ट्रीट लाईट तक्रार', intentDesc: 'Streetlight Grievance' },
      { text: 'उत्पन्न दाखला कसा काढायचा?', label: 'उत्पन्न दाखला', intentDesc: 'Income Certificate' },
    ],
    ta: [
      { text: 'எனக்கு உயர் கல்வி உதவித்தொகை வேண்டும்', label: 'ஸ்காலர்ஷிப் விண்ணப்பம்', intentDesc: 'Post-Matric Scholarship' },
      { text: 'எங்கள் தெருவில் குடிநீர் குழாய் உடைந்துள்ளது', label: 'குடிநீர் புகார்', intentDesc: 'Water Supply Grievance' },
      { text: 'தெரு விளக்கு எரியவில்லை', label: 'தெரு விளக்கு புகார்', intentDesc: 'Streetlight Grievance' },
      { text: 'வருமானச் சான்றிதழ் பெற விரும்புகிறேன்', label: 'வருமானச் சான்றிதழ்', intentDesc: 'Income Certificate' },
    ],
  };

  const activeSamplePrompts = samplePromptsByLang[language] || samplePromptsByLang.en;

  const handleVoiceIntentExecute = async (inputSpeech: string) => {
    setTranscript(inputSpeech);
    setIsListening(false);
    setIsProcessing(true);
    setParsedResult(null);

    try {
      const result = await api.parseVoiceIntent(inputSpeech, language);
      setParsedResult(result);
      setIsProcessing(false);

      // Trigger automatic navigation after brief visual confirmation
      setTimeout(() => {
        if (result.targetModule === 'SERVICES') {
          setActiveTab('SERVICES');
          if (result.serviceId) {
            const match = services.find((s) => s.id === result.serviceId);
            if (match) setSelectedService(match);
          }
        } else if (result.targetModule === 'GRIEVANCES') {
          setActiveTab('GRIEVANCES');
        }
        setIsVoiceModalOpen(false);
        addNotification('info', 'Voice Navigation', result.summary || 'Navigated based on voice input.');
      }, 1500);
    } catch (err) {
      console.error('Voice parse error:', err);
      setIsProcessing(false);
    }
  };

  // Browser Speech Recognition Support (if available)
  const startBrowserListening = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      try {
        const recognition = new SpeechRecognition();
        recognition.lang = language === 'te' ? 'te-IN' : language === 'hi' ? 'hi-IN' : language === 'ta' ? 'ta-IN' : language === 'mr' ? 'mr-IN' : 'en-IN';
        recognition.interimResults = false;
        recognition.maxAlternatives = 1;

        setIsListening(true);
        recognition.start();

        recognition.onresult = (event: any) => {
          const speech = event.results[0][0].transcript;
          handleVoiceIntentExecute(speech);
        };

        recognition.onerror = () => {
          setIsListening(false);
        };

        recognition.onend = () => {
          setIsListening(false);
        };
      } catch {
        setIsListening(false);
      }
    } else {
      // Fallback: trigger quick simulated listening
      setIsListening(true);
      setTimeout(() => {
        handleVoiceIntentExecute(activeSamplePrompts[0].text);
      }, 2000);
    }
  };

  if (!isVoiceModalOpen) return null;

  return (
    <div
      id="voice-assistant-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200"
    >
      <div
        id="voice-assistant-dialog"
        className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 relative overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-700">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">{t('voiceSearch')}</h3>
              <p className="text-xs text-slate-500">Multilingual Indian Civic Intent Engine</p>
            </div>
          </div>
          <button
            onClick={() => setIsVoiceModalOpen(false)}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Central Interactive Microphone Area */}
        <div className="my-6 flex flex-col items-center justify-center text-center">
          <button
            id="btn-voice-mic-record"
            onClick={isListening ? () => setIsListening(false) : startBrowserListening}
            className={`relative w-20 h-20 rounded-full flex items-center justify-center shadow-lg transition-all ${
              isListening
                ? 'bg-rose-600 text-white scale-110 shadow-rose-200 animate-pulse'
                : isProcessing
                ? 'bg-amber-600 text-white shadow-amber-200'
                : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-200 hover:scale-105'
            }`}
          >
            {isListening ? (
              <MicOff className="w-8 h-8" />
            ) : (
              <Mic className="w-8 h-8" />
            )}
            {isListening && (
              <span className="absolute -inset-2 rounded-full border-2 border-rose-400 animate-ping opacity-50"></span>
            )}
          </button>

          <p className="mt-4 text-sm font-semibold text-slate-800">
            {isListening
              ? t('listening')
              : isProcessing
              ? 'Analyzing Intent with Samanvay AI...'
              : t('speakPrompt')}
          </p>

          {transcript && (
            <div className="mt-3 px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-700 font-medium max-w-md">
              "{transcript}"
            </div>
          )}

          {parsedResult && (
            <div className="mt-3 flex items-center gap-2 px-3.5 py-2 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-xl text-xs font-semibold animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{parsedResult.summary}</span>
            </div>
          )}
        </div>

        {/* Preset Multilingual Quick Prompts for Demonstration */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              Try Speaking or Tap a Preset ({language.toUpperCase()})
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {activeSamplePrompts.map((p, idx) => (
              <button
                key={idx}
                onClick={() => handleVoiceIntentExecute(p.text)}
                className="text-left p-2.5 rounded-xl border border-slate-200 hover:border-emerald-300 hover:bg-emerald-50/50 transition-all text-xs group flex flex-col justify-between"
              >
                <span className="font-semibold text-slate-900 group-hover:text-emerald-800 line-clamp-1">
                  {p.label}
                </span>
                <span className="text-[11px] text-slate-500 italic mt-0.5 line-clamp-1">
                  "{p.text}"
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Footer Note */}
        <div className="mt-5 pt-3 border-t border-slate-100 text-center">
          <p className="text-[11px] text-slate-400">
            «The citizen understands their need. Samanvay understands the government structure.»
          </p>
        </div>
      </div>
    </div>
  );
};
