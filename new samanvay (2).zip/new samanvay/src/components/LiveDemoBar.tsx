import React from 'react';
import { useApp } from '../context/AppContext';
import { Role } from '../types';
import { Laptop, RefreshCw, AlertTriangle, Radio } from 'lucide-react';

export const LiveDemoBar: React.FC = () => {
  const {
    activeRole,
    switchRole,
    isRealTimeConnected,
    resetDemoData,
    grievances,
    addNotification,
  } = useApp();

  const handleSimulateSlaBreach = async () => {
    // Find active grievance to breach or use first
    const activeGrievance = grievances.find((g) => g.status !== 'RESOLVED' && !g.isSlaBreached) || grievances[0];
    if (activeGrievance) {
      try {
        const res = await fetch(`/api/grievances/${activeGrievance.id}/simulate-breach`, {
          method: 'POST',
        });
        if (res.ok) {
          addNotification(
            'warning',
            'SLA Breach Simulated',
            `Grievance ${activeGrievance.id} marked as breached (7-day SLA exceeded) & auto-escalated to Higher Officer!`
          );
        }
      } catch (err) {
        console.error('Breach simulation failed:', err);
      }
    } else {
      addNotification('info', 'No Active Grievance', 'All grievances are already resolved or escalated.');
    }
  };

  return (
    <header
      id="live-demo-control-bar"
      className="bg-slate-900 text-white border-b border-slate-800 px-3 sm:px-4 py-2 sm:py-1.5 text-xs font-medium sticky top-0 z-50 shadow-md"
    >
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-2.5">
        {/* Left: 5-Device Demo Switcher */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center gap-1.5 text-amber-400 font-bold uppercase tracking-wider text-[10px] sm:text-[11px] pr-2 sm:border-r border-slate-700 shrink-0">
            <Laptop className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">5-Device Live Demo:</span>
            <span className="sm:hidden">Demo:</span>
          </div>

          <div className="inline-flex rounded-lg p-0.5 bg-slate-800 border border-slate-700 overflow-x-auto max-w-full">
            <button
              id="role-btn-citizen"
              onClick={() => switchRole('CITIZEN')}
              className={`min-h-[36px] sm:min-h-[28px] px-2.5 sm:px-3 py-1 rounded-md transition-all flex items-center gap-1.5 whitespace-nowrap text-xs ${
                activeRole === 'CITIZEN'
                  ? 'bg-emerald-600 text-white font-bold shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/60'
              }`}
              title="Citizen View (Ananya Reddy)"
            >
              <span className="w-2 h-2 rounded-full bg-emerald-300 shrink-0"></span>
              <span>1: Citizen</span>
            </button>

            <button
              id="role-btn-officer"
              onClick={() => switchRole('OFFICER', 'PUBLIC_SERVICES')}
              className={`min-h-[36px] sm:min-h-[28px] px-2.5 sm:px-3 py-1 rounded-md transition-all flex items-center gap-1.5 whitespace-nowrap text-xs ${
                activeRole === 'OFFICER'
                  ? 'bg-blue-600 text-white font-bold shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/60'
              }`}
              title="Department Officer View (Ravi Kumar)"
            >
              <span className="w-2 h-2 rounded-full bg-blue-300 shrink-0"></span>
              <span>2: Officer</span>
            </button>

            <button
              id="role-btn-higher-officer"
              onClick={() => switchRole('HIGHER_OFFICER', 'PUBLIC_SERVICES_HIGHER')}
              className={`min-h-[36px] sm:min-h-[28px] px-2.5 sm:px-3 py-1 rounded-md transition-all flex items-center gap-1.5 whitespace-nowrap text-xs ${
                activeRole === 'HIGHER_OFFICER'
                  ? 'bg-purple-600 text-white font-bold shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/60'
              }`}
              title="Higher Officer Monitoring Desk (Priya Sharma)"
            >
              <span className="w-2 h-2 rounded-full bg-purple-300 shrink-0"></span>
              <span>3: Higher Officer</span>
            </button>

            <button id="role-btn-grievance-officer" onClick={() => switchRole('OFFICER', 'GRIEVANCES')} className="min-h-[36px] sm:min-h-[28px] px-2.5 sm:px-3 py-1 rounded-md text-slate-300 hover:text-white hover:bg-slate-700/60 transition-all flex items-center gap-1.5 whitespace-nowrap text-xs" title="Grievance Officer View">
              <span className="w-2 h-2 rounded-full bg-amber-300 shrink-0"></span>
              <span>4: Grievance Officer</span>
            </button>

            <button id="role-btn-grievance-higher-officer" onClick={() => switchRole('HIGHER_OFFICER', 'GRIEVANCES_HIGHER')} className="min-h-[36px] sm:min-h-[28px] px-2.5 sm:px-3 py-1 rounded-md text-slate-300 hover:text-white hover:bg-slate-700/60 transition-all flex items-center gap-1.5 whitespace-nowrap text-xs" title="Grievance Higher Officer View">
              <span className="w-2 h-2 rounded-full bg-purple-300 shrink-0"></span>
              <span>5: Grievance Higher</span>
            </button>
          </div>
        </div>

        {/* Right: Realtime status, Demo actions, SLA Simulation & Reset */}
        <div className="flex items-center justify-between sm:justify-end gap-2 flex-wrap">
          {/* Sync Status Badge */}
          <div
            id="sync-status-indicator"
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-[10px] sm:text-[11px] font-semibold shrink-0 ${
              isRealTimeConnected
                ? 'bg-emerald-950/80 border-emerald-700 text-emerald-300'
                : 'bg-amber-950/80 border-amber-700 text-amber-300'
            }`}
          >
            <Radio className={`w-3 h-3 ${isRealTimeConnected ? 'animate-pulse text-emerald-400' : ''}`} />
            <span>{isRealTimeConnected ? 'Live Sync' : 'Polling'}</span>
          </div>

          <div className="flex items-center gap-1.5">
            {/* Quick SLA Breach trigger button */}
            <button
              id="btn-simulate-sla"
              onClick={handleSimulateSlaBreach}
              className="min-h-[32px] flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-[11px] font-semibold transition-colors shrink-0"
              title="Demonstrate automated SLA breach detection and escalation to Higher Officer"
            >
              <AlertTriangle className="w-3 h-3 text-amber-400 shrink-0" />
              <span>Simulate Breach</span>
            </button>

            {/* Reset Demo Data */}
            <button
              id="btn-reset-demo"
              onClick={resetDemoData}
              className="min-h-[32px] flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-[11px] transition-colors shrink-0"
              title="Reset all applications & grievances to initial seed demo"
            >
              <RefreshCw className="w-3 h-3 shrink-0" />
              <span className="hidden sm:inline">Reset Demo</span>
              <span className="sm:hidden">Reset</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
