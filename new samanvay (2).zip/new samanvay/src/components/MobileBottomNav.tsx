import React from 'react';
import { useApp } from '../context/AppContext';
import {
  LayoutDashboard,
  Building2,
  AlertCircle,
  FileText,
  FolderLock,
  Mic,
} from 'lucide-react';

export const MobileBottomNav: React.FC = () => {
  const {
    activeRole,
    activeTab,
    setActiveTab,
    applications,
    grievances,
    setIsVoiceModalOpen,
    t,
  } = useApp();

  if (activeRole !== 'CITIZEN') return null;

  return (
    <nav
      id="mobile-bottom-navigation-bar"
      aria-label={t('mobileNavigation')}
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 shadow-lg px-2 py-1.5 safe-area-pb"
    >
      <div className="flex items-center justify-around max-w-md mx-auto">
        {/* Home */}
        <button
          id="mobile-nav-home"
          onClick={() => setActiveTab('HOME')}
          className={`flex flex-col items-center justify-center min-w-[56px] min-h-[48px] py-1 px-1 rounded-xl transition-colors ${
            activeTab === 'HOME'
              ? 'text-slate-900 font-bold'
              : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <div className={`p-1 rounded-lg ${activeTab === 'HOME' ? 'bg-slate-900 text-white' : ''}`}>
            <LayoutDashboard className="w-4 h-4" />
          </div>
          <span className="text-[10px] mt-0.5 whitespace-nowrap">{t('home')}</span>
        </button>

        {/* Public Services */}
        <button
          id="mobile-nav-services"
          onClick={() => setActiveTab('SERVICES')}
          className={`flex flex-col items-center justify-center min-w-[56px] min-h-[48px] py-1 px-1 rounded-xl transition-colors ${
            activeTab === 'SERVICES'
              ? 'text-emerald-700 font-bold'
              : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <div className={`p-1 rounded-lg ${activeTab === 'SERVICES' ? 'bg-emerald-600 text-white' : ''}`}>
            <Building2 className="w-4 h-4" />
          </div>
          <span className="text-[10px] mt-0.5 whitespace-nowrap">{t('services')}</span>
        </button>

        {/* Floating Voice Trigger in Center */}
        <button
          id="mobile-nav-voice"
          onClick={() => setIsVoiceModalOpen(true)}
          className="flex flex-col items-center justify-center min-w-[52px] min-h-[48px] py-1 px-1 -mt-4"
          title={t('voiceSearch')}
        >
          <div className="w-11 h-11 rounded-full bg-emerald-600 text-white flex items-center justify-center shadow-lg shadow-emerald-600/30 hover:scale-105 active:scale-95 transition-transform border-2 border-white">
            <Mic className="w-5 h-5" />
          </div>
          <span className="text-[10px] font-bold text-emerald-800 mt-0.5">{t('voice')}</span>
        </button>

        {/* Grievances */}
        <button
          id="mobile-nav-grievances"
          onClick={() => setActiveTab('GRIEVANCES')}
          className={`flex flex-col items-center justify-center min-w-[56px] min-h-[48px] py-1 px-1 rounded-xl transition-colors ${
            activeTab === 'GRIEVANCES'
              ? 'text-amber-700 font-bold'
              : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <div className={`p-1 rounded-lg ${activeTab === 'GRIEVANCES' ? 'bg-amber-600 text-white' : ''}`}>
            <AlertCircle className="w-4 h-4" />
          </div>
          <span className="text-[10px] mt-0.5 whitespace-nowrap">{t('grievance')}</span>
        </button>

        {/* Track Applications */}
        <button
          id="mobile-nav-apps"
          onClick={() => setActiveTab('MY_APPLICATIONS')}
          className={`relative flex flex-col items-center justify-center min-w-[56px] min-h-[48px] py-1 px-1 rounded-xl transition-colors ${
            activeTab === 'MY_APPLICATIONS' || activeTab === 'MY_GRIEVANCES'
              ? 'text-blue-700 font-bold'
              : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <div className={`p-1 rounded-lg ${activeTab === 'MY_APPLICATIONS' || activeTab === 'MY_GRIEVANCES' ? 'bg-blue-600 text-white' : ''}`}>
            <FileText className="w-4 h-4" />
          </div>
          <span className="text-[10px] mt-0.5 whitespace-nowrap">{t('track')}</span>
          {applications.length > 0 && (
            <span className="absolute top-1 right-2 w-2 h-2 rounded-full bg-emerald-500 ring-2 ring-white"></span>
          )}
        </button>

        {/* Profile / Documents */}
        <button
          id="mobile-nav-profile"
          onClick={() => setActiveTab('PROFILE')}
          className={`flex flex-col items-center justify-center min-w-[56px] min-h-[48px] py-1 px-1 rounded-xl transition-colors ${
            activeTab === 'PROFILE'
              ? 'text-slate-900 font-bold'
              : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <div className={`p-1 rounded-lg ${activeTab === 'PROFILE' ? 'bg-slate-900 text-white' : ''}`}>
            <FolderLock className="w-4 h-4" />
          </div>
          <span className="text-[10px] mt-0.5 whitespace-nowrap">{t('myProfile')}</span>
        </button>
      </div>
    </nav>
  );
};
