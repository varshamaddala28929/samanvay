import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  User as UserIcon,
  ShieldCheck,
  FolderLock,
  Plus,
  Camera,
  Download,
  Building2,
  Calendar,
  Phone,
  Mail,
  MapPin,
  GraduationCap,
  IndianRupee,
  CheckCircle2,
  Lock,
  FileText,
  LogOut,
} from 'lucide-react';
import { api } from '../../services/api';

export const CitizenProfileView: React.FC = () => {
  const {
    currentUser,
    setCurrentUser,
    profile,
    documents,
    applications,
    grievances,
    t,
    refreshProfile,
    refreshAllData,
    addNotification,
    setIsDigiLockerModalOpen,
    setIsCameraModalOpen,
    logout,
  } = useApp();

  const [isEditing, setIsEditing] = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const [formData, setFormData] = useState<any>(profile || {});

  const activeAppCount = applications.length;
  const trackedGrievanceCount = grievances.length;
  const hasOpenItems = activeAppCount > 0 || trackedGrievanceCount > 0;

  const handleLogoutClick = () => {
    if (hasOpenItems) {
      setShowLogoutConfirm(true);
      return;
    }

    logout();
  };

  const handleSaveProfile = async () => {
    try {
      const updatedProfile = await api.updateProfile(currentUser.citizenId || 'SMV-CIT-10245', formData);
      const updatedUser = { ...currentUser, name: updatedProfile.fullName };
      setCurrentUser(updatedUser);
      localStorage.setItem('samanvay_auth_user', JSON.stringify(updatedUser));
      await refreshProfile();
      setIsEditing(false);
      addNotification('success', 'Profile Updated', 'Reusable citizen profile updated across all services.');
    } catch (err) {
      console.error('Update error:', err);
    }
  };

  return (
    <div id="citizen-profile-view" className="space-y-8 animate-in fade-in duration-200">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-3 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-extrabold text-slate-900">{t('myProfile')}</h1>
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold font-mono">
              {currentUser.citizenId || 'SMV-CIT-10245'}
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Single reusable identity across all Indian public departments. Never re-enter details repeatedly.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {!isEditing ? (
            <>
              <button
                onClick={() => {
                  setFormData(profile || {});
                  setIsEditing(true);
                }}
                className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-colors shadow-xs"
              >
                Edit Profile
              </button>
              <button
                id="btn-profile-logout"
                onClick={handleLogoutClick}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-red-200 text-red-700 hover:bg-red-50 text-xs font-semibold transition-colors"
                title={t('logout')}
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>{t('logout')}</span>
              </button>
            </>
          ) : (
            <>
              <button
                onClick={() => setIsEditing(false)}
                className="px-3 py-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-xs font-semibold text-slate-700"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveProfile}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition-colors"
              >
                Save Changes
              </button>
            </>
          )}
        </div>
      </div>

      {showLogoutConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <div className="w-full max-w-md rounded-2xl bg-white border border-slate-200 shadow-2xl p-6">
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-full bg-red-100 text-red-600">
                <LogOut className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900">Confirm Logout</h3>
                <p className="text-xs text-slate-500">Your records stay saved</p>
              </div>
            </div>

            <p className="mt-4 text-sm text-slate-600">
              You currently have <span className="font-bold text-slate-900">{activeAppCount} active</span> and{' '}
              <span className="font-bold text-slate-900">{trackedGrievanceCount} tracked</span> items.
              Are you sure you want to log out?
            </p>

            <div className="mt-6 flex justify-end gap-3">
              <button
                onClick={() => setShowLogoutConfirm(false)}
                className="px-4 py-2 rounded-xl border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 text-sm font-semibold transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  setShowLogoutConfirm(false);
                  logout();
                }}
                className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-sm font-semibold transition-colors shadow-sm"
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left: Citizen Demographic Card */}
        <div className="lg:col-span-6 space-y-6">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-7 shadow-xs">
            <div className="flex items-center gap-3 pb-4 border-b border-slate-100">
              <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-extrabold text-lg">
                {profile?.fullName?.charAt(0) || 'A'}
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">{profile?.fullName}</h3>
                <span className="text-xs text-slate-500 font-mono">
                  Samanvay Citizen ID: {profile?.citizenId}
                </span>
              </div>
            </div>

            {/* Profile Fields */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-5 text-xs">
              <div>
                <span className="text-slate-400 block text-[10px] font-semibold">Full Legal Name</span>
                {isEditing ? (
                  <input
                    type="text"
                    value={formData.fullName || ''}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    className="w-full mt-1 px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs"
                  />
                ) : (
                  <span className="font-bold text-slate-900">{profile?.fullName}</span>
                )}
              </div>

              <div>
                <span className="text-slate-400 block text-[10px] font-semibold">Mobile (Aadhaar-Linked)</span>
                <span className="font-mono font-bold text-slate-900">+91 {profile?.mobile}</span>
              </div>

              <div>
                <span className="text-slate-400 block text-[10px] font-semibold">Date of Birth & Age</span>
                <span className="font-bold text-slate-900">{profile?.dateOfBirth} ({profile?.age} Years)</span>
              </div>

              <div>
                <span className="text-slate-400 block text-[10px] font-semibold">Social Category</span>
                {isEditing ? (
                  <select
                    value={formData.socialCategory || 'OBC'}
                    onChange={(e) => setFormData({ ...formData, socialCategory: e.target.value })}
                    className="w-full mt-1 px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs"
                  >
                    <option value="OBC">OBC</option>
                    <option value="SC">SC</option>
                    <option value="ST">ST</option>
                    <option value="EWS">EWS</option>
                    <option value="General">General</option>
                  </select>
                ) : (
                  <span className="font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    {profile?.socialCategory}
                  </span>
                )}
              </div>

              <div>
                <span className="text-slate-400 block text-[10px] font-semibold">Annual Family Income</span>
                {isEditing ? (
                  <input
                    type="number"
                    value={formData.annualFamilyIncome || ''}
                    onChange={(e) => setFormData({ ...formData, annualFamilyIncome: Number(e.target.value) })}
                    className="w-full mt-1 px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs"
                  />
                ) : (
                  <span className="font-bold text-slate-900">
                    ₹{Number(profile?.annualFamilyIncome).toLocaleString('en-IN')} / Year
                  </span>
                )}
              </div>

              <div>
                <span className="text-slate-400 block text-[10px] font-semibold">Education Qualification</span>
                {isEditing ? (
                  <input
                    type="text"
                    value={formData.educationLevel || ''}
                    onChange={(e) => setFormData({ ...formData, educationLevel: e.target.value })}
                    className="w-full mt-1 px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs"
                  />
                ) : (
                  <span className="font-bold text-slate-900">{profile?.educationLevel}</span>
                )}
              </div>

              <div className="sm:col-span-2">
                <span className="text-slate-400 block text-[10px] font-semibold">Current Course / Academic Program</span>
                <span className="font-bold text-slate-900">{profile?.currentCourse || 'B.Tech CSE (86.4%)'}</span>
              </div>

              <div className="sm:col-span-2">
                <span className="text-slate-400 block text-[10px] font-semibold">Permanent Residence Jurisdiction</span>
                <span className="font-bold text-slate-900">
                  {profile?.address}, {profile?.mandal}, {profile?.district}, {profile?.state} - {profile?.pincode}
                </span>
              </div>
            </div>

            <div className="mt-5 p-3 rounded-2xl bg-emerald-50/70 border border-emerald-200 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2 text-emerald-950 font-medium">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>DBT Aadhaar Bank Account Linked & Active</span>
              </div>
              <span className="font-mono text-[11px] text-emerald-800 font-bold">STATE BANK OF INDIA</span>
            </div>
          </div>
        </div>

        {/* Right: Reusable Document Locker */}
        <div className="lg:col-span-6 space-y-4">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-7 shadow-xs">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
                  <FolderLock className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">{t('verifiedDocuments')}</h3>
                  <p className="text-xs text-slate-500">Reusable Verified Vault</p>
                </div>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setIsDigiLockerModalOpen(true)}
                  className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-colors shadow-xs"
                >
                  DigiLocker
                </button>
                <button
                  onClick={() => setIsCameraModalOpen(true)}
                  className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-colors flex items-center gap-1 shadow-xs"
                >
                  <Camera className="w-3.5 h-3.5" />
                  <span>Scan</span>
                </button>
              </div>
            </div>

            {/* Document list */}
            <div className="space-y-3 mt-5">
              {documents.map((doc) => (
                <div
                  key={doc.id}
                  className="p-3.5 rounded-2xl border border-slate-200 bg-slate-50/70 hover:bg-emerald-50/40 hover:border-emerald-200 transition-colors flex items-center justify-between gap-3 text-xs"
                >
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0 mt-0.5">
                      <FileText className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold text-slate-900">{doc.title}</h4>
                        <span className="px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800 text-[9px] font-bold">
                          {doc.source === 'DIGILOCKER' ? 'DigiLocker' : 'OCR Scan'}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 font-mono mt-0.5">
                        #{doc.documentNumber} • {doc.issuer}
                      </p>
                    </div>
                  </div>

                  <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-extrabold shrink-0">
                    VERIFIED ✓
                  </span>
                </div>
              ))}
            </div>

            <div className="mt-5 p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs text-slate-500 leading-relaxed">
              <strong>Interoperability Guarantee:</strong> Verified documents stored in your Samanvay locker are securely shared with authorized department officers only when you apply for a scheme or service.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
