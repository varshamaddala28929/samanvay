import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Application } from '../../types';
import {
  FileText,
  CheckCircle2,
  Clock,
  AlertCircle,
  ShieldCheck,
  Building2,
  Calendar,
  ChevronRight,
  ExternalLink,
  Sparkles,
} from 'lucide-react';

const statusTranslationKeys: Record<string, string> = {
  SUBMITTED: 'statusSubmitted', UNDER_VERIFICATION: 'statusUnderVerification', OFFICER_ASSIGNED: 'statusOfficerAssigned', APPROVED: 'statusApproved', REJECTED: 'statusRejected', BENEFIT_DISBURSED: 'statusBenefitDisbursed', ESCALATED: 'statusEscalated'
};

export const ApplicationTracker: React.FC = () => {
  const { applications, t, setActiveTab } = useApp();
  const [selectedApp, setSelectedApp] = useState<Application | null>(applications[0] || null);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'APPROVED':
      case 'BENEFIT_DISBURSED':
        return 'bg-emerald-100 text-emerald-800 border-emerald-300';
      case 'REJECTED':
        return 'bg-rose-100 text-rose-800 border-rose-300';
      case 'UNDER_VERIFICATION':
        return 'bg-amber-100 text-amber-800 border-amber-300';
      default:
        return 'bg-blue-100 text-blue-800 border-blue-300';
    }
  };

  return (
    <div id="application-tracker-view" className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-3 border-b border-slate-200">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900">{t('myApplications')}</h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            {t('applicationJourneyDescription', 'Transparent stage-by-stage journey from submission to benefit disbursement.')}
          </p>
        </div>

        <button
          onClick={() => setActiveTab('SERVICES')}
          className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-colors self-start sm:self-auto"
        >
          + {t('applyNow')}
        </button>
      </div>

      {applications.length === 0 ? (
        <div className="p-12 text-center bg-white rounded-3xl border border-slate-200">
          <FileText className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="text-base font-bold text-slate-900">{t('noApplications', 'No applications filed yet')}</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            {t('discoverServices', 'Discover scholarships and government services from the public services catalog.')}
          </p>
          <button
            onClick={() => setActiveTab('SERVICES')}
            className="mt-4 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-colors"
          >
            {t('publicServices')}
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left: Applications List */}
          <div className="lg:col-span-5 space-y-3">
            {applications.map((app) => (
              <div
                key={app.id}
                id={`app-item-${app.id}`}
                onClick={() => setSelectedApp(app)}
                className={`p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                  selectedApp?.id === app.id
                    ? 'border-slate-900 bg-slate-50 shadow-md'
                    : 'border-slate-200 bg-white hover:border-slate-300'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <span className="text-[10px] font-bold font-mono text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                    {app.id}
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${getStatusBadge(
                      app.status
                    )}`}
                  >
                    {t(statusTranslationKeys[app.status] || app.status, app.status)}
                  </span>
                </div>

                <h3 className="text-xs font-bold text-slate-900 mt-2 line-clamp-1">
                  {app.serviceTitle}
                </h3>
                <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-1">{app.department}</p>

                <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-400">
                  <span>{t('submitted', 'Submitted')}: {new Date(app.submittedAt).toLocaleDateString()}</span>
                  <span className="text-slate-700 font-semibold flex items-center gap-0.5">
                    <span>{t('viewJourney', 'View Journey')}</span>
                    <ChevronRight className="w-3 h-3" />
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Right: Detailed Journey Timeline */}
          <div className="lg:col-span-7">
            {selectedApp ? (
              <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-7 shadow-xs space-y-6">
                {/* Application Meta */}
                <div className="pb-4 border-b border-slate-100">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono font-bold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
                      {selectedApp.id}
                    </span>
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-bold border ${getStatusBadge(
                        selectedApp.status
                      )}`}
                    >
                      {t(statusTranslationKeys[selectedApp.status] || selectedApp.status, selectedApp.status)}
                    </span>
                  </div>

                  <h2 className="text-lg sm:text-xl font-extrabold text-slate-900 mt-2.5">
                    {selectedApp.serviceTitle}
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">{selectedApp.department}</p>
                </div>

                {/* Assigned Officer & Benefit Box */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs">
                    <span className="text-slate-400 block text-[10px] font-semibold">{t('assignedDesk', 'Assigned Desk')}:</span>
                    <span className="font-bold text-slate-900 block mt-0.5">
                      {selectedApp.assignedOfficerName || 'District Welfare Officer Ravi Kumar'}
                    </span>
                    <span className="text-[11px] text-slate-500 font-mono">
                      {selectedApp.assignedOfficerId || 'SMV-OFF-204'}
                    </span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-xs">
                    <span className="text-emerald-800 block text-[10px] font-semibold">{t('sanctionedEntitlement', 'Sanctioned Entitlement')}:</span>
                    <span className="font-bold text-emerald-950 block mt-0.5">
                      {selectedApp.benefitDetails || 'Tuition Fee Waiver + Maintenance Grant'}
                    </span>
                  </div>
                </div>

                {/* Officer Remarks (if any) */}
                {selectedApp.officerRemarks && (
                  <div className="p-4 rounded-2xl bg-blue-50/70 border border-blue-200 text-xs">
                    <span className="font-bold text-blue-900 block mb-1">
                      {t('officialRemarks', 'Official Department Remarks')}:
                    </span>
                    <p className="text-blue-950 leading-relaxed font-medium">
                      "{selectedApp.officerRemarks}"
                    </p>
                  </div>
                )}

                {/* TIMELINE JOURNEY */}
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-4">
                    {t('stageByStageJourney', 'Stage-by-Stage Application Journey')}
                  </h3>

                  <div className="space-y-4 relative before:absolute before:left-3 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
                    {selectedApp.timeline.map((event, idx) => (
                      <div key={idx} className="relative pl-8 text-xs">
                        <div className="absolute left-1.5 top-0.5 w-3.5 h-3.5 rounded-full bg-emerald-600 border-2 border-white shadow-xs"></div>
                        <div className="flex items-baseline justify-between">
                          <span className="font-bold text-slate-900">{t(statusTranslationKeys[event.status] || event.status, event.status)}</span>
                          <span className="text-[10px] text-slate-400">
                            {new Date(event.timestamp).toLocaleString()}
                          </span>
                        </div>
                        <span className="text-[11px] text-slate-500 font-medium block">
                          {t('actor', 'Actor')}: {event.actor}
                        </span>
                        {event.remarks && (
                          <p className="mt-1 text-slate-700 bg-slate-50 p-2.5 rounded-xl border border-slate-100 text-[11px]">
                            {event.remarks}
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : null}
          </div>
        </div>
      )}
    </div>
  );
};
