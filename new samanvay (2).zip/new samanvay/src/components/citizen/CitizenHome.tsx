import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  FileText,
  AlertCircle,
  FolderLock,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Clock,
  Sparkles,
  ChevronRight,
  Building2,
  AlertTriangle,
} from 'lucide-react';

const statusTranslationKeys: Record<string, string> = {
  SUBMITTED: 'statusSubmitted',
  UNDER_VERIFICATION: 'statusUnderVerification',
  OFFICER_ASSIGNED: 'statusOfficerAssigned',
  APPROVED: 'statusApproved',
  REJECTED: 'statusRejected',
  BENEFIT_DISBURSED: 'statusBenefitDisbursed',
  RECEIVED: 'statusReceived',
  ASSIGNED: 'statusAssigned',
  IN_PROGRESS: 'statusInProgress',
  RESOLVED: 'statusResolved',
  ESCALATED: 'statusEscalated',
};

export const CitizenHome: React.FC = () => {
  const {
    t,
    isAuthenticated,
    currentUser,
    profile,
    applications,
    grievances,
    documents,
    setActiveTab,
    setSelectedService,
    services,
  } = useApp();

  const pendingApps = applications.filter((a) => a.status !== 'REJECTED');
  const activeGrievances = grievances.filter((g) => g.status !== 'RESOLVED');

  return (
    <div id="citizen-home-view" className="space-y-8 animate-in fade-in duration-200">
      {/* Welcome Banner */}
      <div className="pb-4 border-b border-slate-200">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              {t('welcomeToSamanvay')}
            </h1>
            <p className="text-sm font-medium text-emerald-800 mt-0.5">
              {t('oneCitizenOneJourney')}
            </p>
            {isAuthenticated && (
              <p className="text-xs text-slate-500 mt-1">
                {t('loggedInAs')} <strong className="font-semibold text-slate-700">{currentUser.name}</strong> • {profile?.district || 'Visakhapatnam'} ({profile?.mandal || 'Gajuwaka'})
              </p>
            )}
          </div>

          {isAuthenticated && (
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-full bg-slate-100 border border-slate-200 text-slate-700 text-xs font-mono font-medium">
                ID: {currentUser.citizenId || 'SMV-CIT-10245'}
              </span>
            </div>
          )}
        </div>
      </div>

      {/* CORE PRODUCT PRINCIPLE: TWO PRIMARY MODULES ONLY */}
      <div>
        <div className="mb-4">
          <span className="text-[11px] font-bold uppercase tracking-widest text-slate-400">
            {t('primaryServiceGateways')}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* 1. PUBLIC SERVICES MODULE */}
          <div
            id="card-primary-public-services"
            onClick={() => setActiveTab('SERVICES')}
            className="group cursor-pointer relative overflow-hidden rounded-2xl border-2 border-slate-200 bg-white p-6 sm:p-8 hover:border-emerald-600 hover:shadow-xl transition-all duration-200 flex flex-col justify-between"
          >
            <div className="flex items-start justify-between">
              <div className="w-14 h-14 rounded-2xl bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-700 group-hover:scale-110 group-hover:bg-emerald-600 group-hover:text-white transition-all shadow-xs">
                <Building2 className="w-7 h-7" />
              </div>
              <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                {t('categorySchemeCount')}
              </span>
            </div>

            <div className="my-6">
              <h2 className="text-xl sm:text-2xl font-bold text-slate-900 group-hover:text-emerald-700 transition-colors">
                {t('publicServices')}
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
                {t('publicServicesDesc')}
              </p>
            </div>

            <div className="flex items-center text-xs font-bold text-emerald-700 group-hover:translate-x-1 transition-transform">
              <span>{t('exploreSchemes')}</span>
              <ArrowRight className="w-4 h-4 ml-1.5" />
            </div>
          </div>

          {/* 2. GRIEVANCES MODULE */}
          <div
            id="card-primary-grievances"
            onClick={() => setActiveTab('GRIEVANCES')}
            className="group cursor-pointer relative overflow-hidden rounded-2xl border-2 border-slate-200 bg-white p-6 sm:p-8 hover:border-amber-600 hover:shadow-xl transition-all duration-200 flex flex-col justify-between"
          >
            <div className="flex items-start justify-between">
              <div className="w-14 h-14 rounded-2xl bg-amber-50 border border-amber-100 flex items-center justify-center text-amber-700 group-hover:scale-110 group-hover:bg-amber-600 group-hover:text-white transition-all shadow-xs">
                <AlertCircle className="w-7 h-7" />
              </div>
              <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-amber-50 text-amber-700 border border-amber-200">
                {t('autoRoutingSla')}
              </span>
            </div>

            <div className="my-6">
              <h2 className="text-xl sm:text-2xl font-bold text-slate-900 group-hover:text-amber-700 transition-colors">
                {t('grievances')}
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
                {t('grievancesDesc')}
              </p>
            </div>

            <div className="flex items-center text-xs font-bold text-amber-700 group-hover:translate-x-1 transition-transform">
              <span>{t('reportCivicProblem')}</span>
              <ArrowRight className="w-4 h-4 ml-1.5" />
            </div>
          </div>
        </div>
      </div>

      {/* Secondary Status Badges: Small Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
        {/* My Applications Card */}
        <div
          id="summary-card-applications"
          onClick={() => setActiveTab('MY_APPLICATIONS')}
          className="p-4 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 cursor-pointer transition-colors flex items-center justify-between"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs text-slate-500 font-medium">{t('myApplications')}</span>
              <h4 className="text-lg font-bold text-slate-900">{applications.length} {t('active')}</h4>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </div>

        {/* My Grievances Card */}
        <div
          id="summary-card-grievances"
          onClick={() => setActiveTab('MY_GRIEVANCES')}
          className="p-4 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 cursor-pointer transition-colors flex items-center justify-between"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center">
              <AlertCircle className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs text-slate-500 font-medium">{t('myGrievances')}</span>
              <h4 className="text-lg font-bold text-slate-900">{grievances.length} {t('tracked')}</h4>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </div>

        {/* Document Locker Card */}
        <div
          id="summary-card-locker"
          onClick={() => setActiveTab('PROFILE')}
          className="p-4 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 cursor-pointer transition-colors flex items-center justify-between"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center">
              <FolderLock className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs text-slate-500 font-medium">{t('verifiedDocuments')}</span>
              <h4 className="text-lg font-bold text-slate-900">{documents.length} {t('stored')}</h4>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </div>
      </div>

      {/* Recent Activity Timeline */}
      <div className="p-6 rounded-2xl border border-slate-200 bg-white">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <Clock className="w-4 h-4 text-slate-500" />
            <span>{t('recentActivity')}</span>
          </h3>
          <span className="text-xs text-slate-400">{t('realTimeSynchronized')}</span>
        </div>

        <div className="space-y-3">
          {applications.slice(0, 2).map((app) => (
            <div
              key={app.id}
              onClick={() => setActiveTab('MY_APPLICATIONS')}
              className="p-3.5 rounded-xl border border-slate-100 bg-slate-50/60 hover:bg-blue-50/30 hover:border-blue-200 transition-colors flex items-center justify-between cursor-pointer"
            >
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center shrink-0 mt-0.5">
                  <FileText className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900">{app.serviceTitle}</h4>
                  <p className="text-[11px] text-slate-500 font-mono mt-0.5">
                    {app.id} • {app.department}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <span
                  className={`px-2.5 py-1 rounded-full text-[11px] font-bold ${
                    app.status === 'APPROVED'
                      ? 'bg-emerald-100 text-emerald-800'
                      : app.status === 'UNDER_VERIFICATION'
                      ? 'bg-amber-100 text-amber-800'
                      : 'bg-blue-100 text-blue-800'
                  }`}
                >
                  {t(statusTranslationKeys[app.status] || app.status, app.status)}
                </span>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </div>
            </div>
          ))}

          {grievances.slice(0, 1).map((grv) => (
            <div
              key={grv.id}
              onClick={() => setActiveTab('MY_GRIEVANCES')}
              className="p-3.5 rounded-xl border border-slate-100 bg-slate-50/60 hover:bg-amber-50/30 hover:border-amber-200 transition-colors flex items-center justify-between cursor-pointer"
            >
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center shrink-0 mt-0.5">
                  <AlertCircle className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900">{grv.issueType}</h4>
                  <p className="text-[11px] text-slate-500 font-mono mt-0.5">
                    {grv.id} • {grv.routedDepartment}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <span
                  className={`px-2.5 py-1 rounded-full text-[11px] font-bold ${
                    grv.status === 'ESCALATED'
                      ? 'bg-rose-100 text-rose-800 animate-pulse'
                      : grv.status === 'RESOLVED'
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  {t(statusTranslationKeys[grv.status] || grv.status, grv.status)}
                </span>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
