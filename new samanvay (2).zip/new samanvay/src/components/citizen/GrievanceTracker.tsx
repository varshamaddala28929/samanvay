import React, { useEffect, useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Grievance } from '../../types';
import {
  AlertCircle,
  Clock,
  MapPin,
  CheckCircle2,
  AlertTriangle,
  ChevronRight,
  ShieldCheck,
  Building2,
  Sparkles,
  MoreVertical,
} from 'lucide-react';

export const GrievanceTracker: React.FC = () => {
  const { grievances, t, setActiveTab, resetDemoGrievances } = useApp();
  const [selectedGrv, setSelectedGrv] = useState<Grievance | null>(grievances[0] || null);
  const [isMoreOpen, setIsMoreOpen] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  useEffect(() => {
    setSelectedGrv((current) => grievances.find((grievance) => grievance.id === current?.id) || grievances[0] || null);
  }, [grievances]);

  const getStatusBadge = (status: string, isSlaBreached: boolean) => {
    if (status === 'ESCALATED' || isSlaBreached) {
      return 'bg-rose-100 text-rose-800 border-rose-300 animate-pulse font-extrabold';
    }
    switch (status) {
      case 'RESOLVED':
        return 'bg-emerald-100 text-emerald-800 border-emerald-300';
      case 'IN_PROGRESS':
        return 'bg-amber-100 text-amber-800 border-amber-300';
      default:
        return 'bg-blue-100 text-blue-800 border-blue-300';
    }
  };

  return (
    <div id="grievance-tracker-view" className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-3 border-b border-slate-200">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900">{t('myGrievances')}</h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Transparent tracking with automated department routing and SLA escalation.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={() => setActiveTab('GRIEVANCES')}
            className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold transition-colors shadow-xs"
          >
            + {t('raiseGrievance')}
          </button>
          <div className="relative">
            <button
              type="button"
              onClick={() => setIsMoreOpen(!isMoreOpen)}
              aria-label="More complaint options"
              aria-expanded={isMoreOpen}
              className="p-2 rounded-xl border border-slate-200 bg-white text-slate-500 hover:bg-slate-50"
            >
              <MoreVertical className="w-4 h-4" />
            </button>
            {isMoreOpen && (
              <div className="absolute right-0 mt-1.5 w-44 rounded-xl bg-white border border-slate-200 shadow-xl p-1.5 z-20">
                <button type="button" onClick={() => { setIsMoreOpen(false); if (selectedGrv) document.getElementById(`grv-item-${selectedGrv.id}`)?.scrollIntoView({ behavior: 'smooth', block: 'center' }); }} className="w-full px-3 py-2 text-left rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-50">View Details</button>
                <button type="button" onClick={() => { setIsMoreOpen(false); setShowResetConfirm(true); }} className="w-full px-3 py-2 text-left rounded-lg text-xs font-semibold text-red-600 hover:bg-red-50">Reset Demo Data</button>
              </div>
            )}
          </div>
        </div>
      </div>

      {grievances.length === 0 ? (
        <div className="p-12 text-center bg-white rounded-3xl border border-slate-200">
          <AlertCircle className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="text-base font-bold text-slate-900">No complaints logged</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            Report any local civic issue, water disruption, road damage or streetlight problem without logging in.
          </p>
          <button
            onClick={() => setActiveTab('GRIEVANCES')}
            className="mt-4 px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold transition-colors"
          >
            {t('raiseGrievance')}
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left: Grievance Cards List */}
          <div className="lg:col-span-5 space-y-3">
            {grievances.map((grv) => (
              <div
                key={grv.id}
                id={`grv-item-${grv.id}`}
                onClick={() => setSelectedGrv(grv)}
                className={`p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                  selectedGrv?.id === grv.id
                    ? 'border-amber-600 bg-amber-50/40 shadow-md'
                    : 'border-slate-200 bg-white hover:border-slate-300'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <span className="text-[10px] font-bold font-mono text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                    {grv.id}
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${getStatusBadge(
                      grv.status,
                      grv.isSlaBreached
                    )}`}
                  >
                    {grv.isSlaBreached ? 'SLA BREACHED' : grv.status}
                  </span>
                </div>

                <h3 className="text-xs font-bold text-slate-900 mt-2 line-clamp-1">
                  {grv.issueType}
                </h3>
                <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-1">{grv.routedDepartment}</p>

                <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between text-[10px]">
                  <span className="text-slate-400">
                    Location: {grv.location.mandal}
                  </span>
                  <span className="text-amber-800 font-semibold flex items-center gap-0.5">
                    <span>View Timeline</span>
                    <ChevronRight className="w-3 h-3" />
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Right: Detailed Grievance Timeline & SLA Monitor */}
          <div className="lg:col-span-7">
            {selectedGrv ? (
              <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-7 shadow-xs space-y-6">
                {/* Header */}
                <div className="pb-4 border-b border-slate-100">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono font-bold text-amber-900 bg-amber-50 px-2.5 py-1 rounded-lg border border-amber-200">
                      {selectedGrv.id}
                    </span>
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-bold border ${getStatusBadge(
                        selectedGrv.status,
                        selectedGrv.isSlaBreached
                      )}`}
                    >
                      {selectedGrv.isSlaBreached ? 'SLA BREACHED & ESCALATED' : selectedGrv.status}
                    </span>
                  </div>

                  <h2 className="text-lg sm:text-xl font-extrabold text-slate-900 mt-2.5">
                    {selectedGrv.issueType}
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Category: {selectedGrv.category} • Routed to {selectedGrv.routedDepartment}
                  </p>
                </div>

                {/* SLA Clock & Jurisdiction Badge */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div
                    className={`p-3.5 rounded-2xl border text-xs ${
                      selectedGrv.isSlaBreached
                        ? 'bg-rose-50 border-rose-200 text-rose-950'
                        : 'bg-emerald-50 border-emerald-200 text-emerald-950'
                    }`}
                  >
                    <span className="block text-[10px] font-bold uppercase tracking-wider">
                      SLA Resolution Clock (7 Days)
                    </span>
                    <span className="font-extrabold text-sm block mt-0.5">
                      {selectedGrv.isSlaBreached ? '7-Day SLA Exceeded (Auto-Escalated)' : 'Within Expected 7-Day Window'}
                    </span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs">
                    <span className="text-slate-400 block text-[10px] font-semibold">Location Jurisdiction:</span>
                    <span className="font-bold text-slate-900 block mt-0.5">
                      {selectedGrv.location.landmark || selectedGrv.location.mandal}
                    </span>
                    <span className="text-[11px] text-slate-500">
                      {selectedGrv.location.district}, {selectedGrv.location.state}
                    </span>
                  </div>
                </div>

                {/* Problem Description */}
                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs">
                  <span className="font-bold text-slate-900 block mb-1">Citizen Statement:</span>
                  <p className="text-slate-700 leading-relaxed font-normal">
                    {selectedGrv.description}
                  </p>
                </div>

                {/* Higher Officer Directives (if escalated) */}
                {selectedGrv.higherOfficerNotes && (
                  <div className="p-4 rounded-2xl bg-purple-50 border border-purple-200 text-xs">
                    <span className="font-bold text-purple-900 flex items-center gap-1.5 mb-1">
                      <Sparkles className="w-3.5 h-3.5 text-purple-700" />
                      <span>Higher Officer (Joint Secretary Priya Sharma) Intervention:</span>
                    </span>
                    <p className="text-purple-950 leading-relaxed font-medium">
                      "{selectedGrv.higherOfficerNotes}"
                    </p>
                  </div>
                )}

                {/* Timeline */}
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-4">
                    Grievance Redressal Timeline
                  </h3>

                  <div className="space-y-4 relative before:absolute before:left-3 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
                    {selectedGrv.timeline.map((event, idx) => (
                      <div key={idx} className="relative pl-8 text-xs">
                        <div
                          className={`absolute left-1.5 top-0.5 w-3.5 h-3.5 rounded-full border-2 border-white shadow-xs ${
                            event.status === 'ESCALATED' ? 'bg-rose-600' : 'bg-amber-600'
                          }`}
                        ></div>
                        <div className="flex items-baseline justify-between">
                          <span className="font-bold text-slate-900">{event.status}</span>
                          <span className="text-[10px] text-slate-400">
                            {new Date(event.timestamp).toLocaleString()}
                          </span>
                        </div>
                        <span className="text-[11px] text-slate-500 font-medium block">
                          Actor: {event.actor}
                        </span>
                        {event.remarks && (
                          <p className="mt-1 text-slate-700 bg-slate-50 p-2.5 rounded-xl border border-slate-100 text-[11px]">
                            {event.remarks}
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : null}
          </div>
        </div>
      )}

      {showResetConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <div className="w-full max-w-sm rounded-2xl bg-white border border-slate-200 shadow-2xl p-6">
            <h3 className="text-base font-bold text-slate-900">Reset demo complaints?</h3>
            <p className="mt-2 text-sm text-slate-600">This will remove all prototype complaints from this device.</p>
            <p className="mt-2 text-[11px] text-slate-400">Prototype/demo data only.</p>
            <div className="mt-6 flex justify-end gap-3">
              <button type="button" onClick={() => setShowResetConfirm(false)} className="px-4 py-2 rounded-xl border border-slate-200 bg-white text-slate-700 text-sm font-semibold hover:bg-slate-50">Cancel</button>
              <button type="button" onClick={async () => { await resetDemoGrievances(); setShowResetConfirm(false); }} className="px-4 py-2 rounded-xl bg-red-600 text-white text-sm font-semibold hover:bg-red-700">Reset</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
