import React, { useRef, useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  AlertCircle,
  MapPin,
  Building2,
  Mic,
  Camera,
  CheckCircle2,
  ArrowRight,
  ArrowLeft,
  Navigation,
  Sparkles,
  Upload,
  ShieldCheck,
  Volume2,
  Home,
} from 'lucide-react';
import { api } from '../../services/api';

const GRIEVANCE_TYPES = [
  {
    id: 'grv_water',
    category: 'Water Supply & Sanitation',
    issueType: 'Drinking Water Pipeline Leak & Supply Disruption',
    deptRecommendation: 'Municipal Water Supply & Sewerage Board',
    icon: '💧',
  },
  {
    id: 'grv_elec',
    category: 'Electricity & Streetlighting',
    issueType: 'Continuous Street Light Blackout & Voltage Fluctuation',
    deptRecommendation: 'Energy & Municipal Electrical Engineering',
    icon: '💡',
  },
  {
    id: 'grv_road',
    category: 'Roads & Infrastructure',
    issueType: 'Dangerous Potholes & Road Damage',
    deptRecommendation: 'Roads & Buildings / Municipal Engineering',
    icon: '🚧',
  },
  {
    id: 'grv_drainage',
    category: 'Drainage & Public Health',
    issueType: 'Clogged Open Drain & Sewage Overflow',
    deptRecommendation: 'Public Health & Sanitation Wing',
    icon: '🚰',
  },
  {
    id: 'grv_ration',
    category: 'Civil Supplies & Food',
    issueType: 'Fair Price Ration Shop Irregularity & Stock Delay',
    deptRecommendation: 'Department of Civil Supplies',
    icon: '🌾',
  },
  {
    id: 'grv_pension',
    category: 'Social Security & Pension',
    issueType: 'Monthly Old Age / Widow Pension Discrepancy',
    deptRecommendation: 'Department of Social Welfare',
    icon: '👵',
  },
  {
    id: 'grv_other',
    category: 'Other Civic Issue',
    issueType: 'Other Civic Issue',
    deptRecommendation: 'Concerned Municipal Department',
    icon: '📣',
  },
];

const ISSUE_LABELS: Record<string, Record<string, string>> = {
  te: { grv_water: 'తాగునీరు / పైప్‌లైన్', grv_elec: 'వీధి లైట్లు / విద్యుత్', grv_road: 'గుంతలు / దెబ్బతిన్న రహదారులు', grv_drainage: 'కాలువ / మురుగునీరు', grv_ration: 'రేషన్ దుకాణం', grv_pension: 'పింఛను / సంక్షేమం', grv_other: 'ఇతర సమస్య' },
  hi: { grv_water: 'पीने का पानी / पाइपलाइन', grv_elec: 'स्ट्रीट लाइट / बिजली', grv_road: 'गड्ढे / खराब सड़क', grv_drainage: 'नाली / सीवेज', grv_ration: 'राशन की दुकान', grv_pension: 'पेंशन / कल्याण', grv_other: 'अन्य समस्या' },
  mr: { grv_water: 'पिण्याचे पाणी / पाईपलाईन', grv_elec: 'पथदिवे / वीज', grv_road: 'खड्डे / खराब रस्ता', grv_drainage: 'नाला / सांडपाणी', grv_ration: 'रेशन दुकान', grv_pension: 'पेन्शन / कल्याण', grv_other: 'इतर समस्या' },
  ta: { grv_water: 'குடிநீர் / குழாய்', grv_elec: 'தெருவிளக்கு / மின்சாரம்', grv_road: 'சாலை பள்ளம் / சேதம்', grv_drainage: 'கால்வாய் / கழிவுநீர்', grv_ration: 'ரேஷன் கடை', grv_pension: 'ஓய்வூதியம் / நலத்திட்டம்', grv_other: 'மற்ற பிரச்சனை' },
  en: { grv_water: 'Drinking Water / Pipeline', grv_elec: 'Street Light / Power', grv_road: 'Potholes / Damaged Roads', grv_drainage: 'Open Drain / Sewage', grv_ration: 'Fair Price / Ration Shop', grv_pension: 'Pension / Welfare', grv_other: 'Other Civic Issue' },
};

export const GrievanceWizard: React.FC = () => {
  const {
    currentUser,
    profile,
    t,
    language,
    refreshAllData,
    addNotification,
    setActiveTab,
  } = useApp();

  const [step, setStep] = useState(1);
  const [selectedType, setSelectedType] = useState(GRIEVANCE_TYPES[0]);
  const [issueTranscript, setIssueTranscript] = useState('');
  const [isIssueListening, setIsIssueListening] = useState(false);
  const [isIssueProcessing, setIsIssueProcessing] = useState(false);
  const [detectedType, setDetectedType] = useState<typeof GRIEVANCE_TYPES[number] | null>(null);
  
  // Location
  const [state, setState] = useState(profile?.state || 'Andhra Pradesh');
  const [district, setDistrict] = useState(profile?.district || 'Visakhapatnam');
  const [mandal, setMandal] = useState(profile?.mandal || 'Gajuwaka');
  const [landmark, setLandmark] = useState('');
  const [gpsCoordinates, setGpsCoordinates] = useState<{ latitude: number; longitude: number } | null>(null);
  const [locationDetecting, setLocationDetecting] = useState(false);

  // Problem description & media
  const [description, setDescription] = useState('');
  const [hasVoiceNote, setHasVoiceNote] = useState(false);
  const [hasPhoto, setHasPhoto] = useState(false);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [cameraPreview, setCameraPreview] = useState<string | null>(null);
  const [cameraError, setCameraError] = useState(false);
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const uploadInputRef = useRef<HTMLInputElement | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedGrievanceId, setSubmittedGrievanceId] = useState<string | null>(null);
  const [duplicateGrievance, setDuplicateGrievance] = useState<any>(null);

  const speechLocale = language === 'te' ? 'te-IN' : language === 'hi' ? 'hi-IN' : language === 'ta' ? 'ta-IN' : language === 'mr' ? 'mr-IN' : 'en-IN';
  const localizedIssueLabel = (type: typeof GRIEVANCE_TYPES[number]) => ISSUE_LABELS[language]?.[type.id] || ISSUE_LABELS.en[type.id];
  const processingLabel = { te: 'మీ సమస్యను అర్థం చేసుకుంటున్నాము...', hi: 'आपकी समस्या समझ रहे हैं...', mr: 'तुमची समस्या समजून घेत आहोत...', ta: 'உங்கள் பிரச்சனையைப் புரிந்துகொள்கிறோம்...', en: 'Understanding your problem...' }[language];

  const findGrievanceType = (result: any) => {
    const intent = String(result?.intent || '').toUpperCase();
    const category = String(result?.grievanceCategory || '').toLowerCase();
    if (intent.includes('WATER') || category.includes('water')) return GRIEVANCE_TYPES.find((gt) => gt.id === 'grv_water');
    if (intent.includes('ELECTRICITY') || category.includes('electric')) return GRIEVANCE_TYPES.find((gt) => gt.id === 'grv_elec');
    if (intent.includes('ROAD') || category.includes('road')) return GRIEVANCE_TYPES.find((gt) => gt.id === 'grv_road');
    if (intent.includes('DRAIN') || category.includes('drain')) return GRIEVANCE_TYPES.find((gt) => gt.id === 'grv_drainage');
    if (intent.includes('RATION') || category.includes('ration')) return GRIEVANCE_TYPES.find((gt) => gt.id === 'grv_ration');
    if (intent.includes('PENSION') || category.includes('pension')) return GRIEVANCE_TYPES.find((gt) => gt.id === 'grv_pension');
    return GRIEVANCE_TYPES.find((gt) => gt.id === 'grv_other');
  };

  const processIssueSpeech = async (speech: string) => {
    setIssueTranscript(speech);
    setIsIssueListening(false);
    setIsIssueProcessing(true);
    try {
      const result = await api.parseVoiceIntent(speech, language);
      setDetectedType(findGrievanceType(result) || GRIEVANCE_TYPES[0]);
    } catch (err) {
      console.error('Complaint voice parse error:', err);
      setDetectedType(GRIEVANCE_TYPES.find((gt) => gt.id === 'grv_other') || GRIEVANCE_TYPES[0]);
    } finally {
      setIsIssueProcessing(false);
    }
  };

  const handleIssueVoice = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      addNotification('warning', 'Voice input unavailable', 'Please select a category manually on this device.');
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = speechLocale;
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    setIsIssueListening(true);
    recognition.onresult = (event: any) => processIssueSpeech(event.results[0][0].transcript);
    recognition.onerror = () => setIsIssueListening(false);
    recognition.onend = () => setIsIssueListening(false);
    recognition.start();
  };

  const handleDetailsVoice = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      addNotification('warning', 'Voice input unavailable', 'Please type the additional details manually.');
      return;
    }
    const recognition = new SpeechRecognition();
    recognition.lang = speechLocale;
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    recognition.onresult = (event: any) => {
      const spokenDetails = event.results[0][0].transcript;
      setDescription((current) => current ? `${current} ${spokenDetails}` : spokenDetails);
      setHasVoiceNote(true);
    };
    recognition.onerror = () => setHasVoiceNote(false);
    recognition.start();
  };

  const stopCamera = () => {
    cameraStream?.getTracks().forEach((track) => track.stop());
    setCameraStream(null);
    setIsCameraOpen(false);
  };

  const handleTakePhoto = async () => {
    setCameraError(false);
    setCameraPreview(null);
    if (!navigator.mediaDevices?.getUserMedia) {
      setCameraError(true);
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      setCameraStream(stream);
      setIsCameraOpen(true);
      if (videoRef.current) videoRef.current.srcObject = stream;
    } catch {
      setCameraError(true);
      stopCamera();
    }
  };

  const handleCapturePhoto = () => {
    const video = videoRef.current;
    if (!video) return;
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    canvas.getContext('2d')?.drawImage(video, 0, 0, canvas.width, canvas.height);
    setCameraPreview(canvas.toDataURL('image/jpeg', 0.85));
    stopCamera();
  };

  const handleUsePhoto = (image: string) => {
    setPhotoPreview(image);
    setHasPhoto(true);
    setCameraPreview(null);
    stopCamera();
  };

  const handleUploadPhoto = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => handleUsePhoto(String(reader.result));
    reader.readAsDataURL(file);
    event.target.value = '';
  };

  const handleDetectGPS = () => {
    setLocationDetecting(true);
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setGpsCoordinates({
            latitude: pos.coords.latitude,
            longitude: pos.coords.longitude,
          });
          setLocationDetecting(false);
          addNotification(
            'info',
            'GPS Jurisdiction Located',
            `Coordinates: ${pos.coords.latitude.toFixed(4)}, ${pos.coords.longitude.toFixed(4)}`
          );
        },
        () => {
          setLocationDetecting(false);
          addNotification('warning', 'Location permission denied', 'Please enter your location manually to continue.');
        }
      );
    } else {
      setLocationDetecting(false);
      addNotification('warning', 'Location unavailable', 'Please enter your location manually to continue.');
    }
  };

  const handleSubmitGrievance = async (allowDuplicate = false) => {
    setIsSubmitting(true);
    try {
      const newGrv = await api.submitGrievance({
        citizenId: currentUser.citizenId || 'SMV-CIT-10245',
        category: selectedType.category,
        issueType: selectedType.issueType,
        description: description || `Reported ${selectedType.issueType} near ${landmark || mandal}.`,
        state,
        district,
        mandal,
        landmark: landmark || `${mandal} Ward Center`,
        coordinates: gpsCoordinates,
        voiceNoteUrl: hasVoiceNote ? 'simulated_audio_note.mp3' : undefined,
        photoUrl: photoPreview || undefined,
        allowDuplicate,
      });

      setIsSubmitting(false);
      setSubmittedGrievanceId(newGrv.id);
      addNotification('success', successCopy.title, `${successCopy.number} ${newGrv.id}. ${successCopy.message}`);
      try {
        await refreshAllData();
      } catch (refreshError) {
        console.error('Complaint status refresh error:', refreshError);
      }
    } catch (err) {
      console.error('Grievance submission error:', err);
      setIsSubmitting(false);
      if ((err as any)?.status === 409 && (err as any)?.existingGrievance) {
        setDuplicateGrievance((err as any).existingGrievance);
      } else {
        addNotification('error', 'Complaint submission failed', 'Please try submitting your complaint again.');
      }
    }
  };

  const successCopy = {
    te: { title: 'మీ ఫిర్యాదు పంపబడింది', number: 'మీ ఫిర్యాదు నంబర్:', message: 'మీ సమస్యను సంబంధిత అధికారికి పంపించాం.', listen: 'వినండి', status: 'ఫిర్యాదు స్థితి చూడండి', home: 'హోమ్‌కి వెళ్లండి' },
    hi: { title: 'आपकी शिकायत भेज दी गई है', number: 'आपकी शिकायत संख्या:', message: 'आपकी समस्या संबंधित अधिकारी को भेज दी गई है।', listen: 'सुनें', status: 'शिकायत की स्थिति देखें', home: 'होम पर जाएं' },
    mr: { title: 'तुमची तक्रार पाठवली आहे', number: 'तुमचा तक्रार क्रमांक:', message: 'तुमची समस्या संबंधित अधिकाऱ्याकडे पाठवली आहे.', listen: 'ऐका', status: 'तक्रारीची स्थिती पहा', home: 'मुख्यपृष्ठावर जा' },
    ta: { title: 'உங்கள் புகார் அனுப்பப்பட்டது', number: 'உங்கள் புகார் எண்:', message: 'உங்கள் பிரச்சனை சம்பந்தப்பட்ட அதிகாரிக்கு அனுப்பப்பட்டது.', listen: 'கேளுங்கள்', status: 'புகார் நிலையைப் பார்க்கவும்', home: 'முகப்புக்குச் செல்லவும்' },
    en: { title: 'Your complaint has been sent.', number: 'Your complaint number:', message: 'Your problem has been sent to the concerned officer.', listen: 'Listen', status: 'View Complaint Status', home: 'Go to Home' },
  }[language];

  const handleListenSuccess = () => {
    if (!('speechSynthesis' in window) || !submittedGrievanceId) return;
    const utterance = new SpeechSynthesisUtterance(`${successCopy.title}. ${successCopy.number} ${submittedGrievanceId}. ${successCopy.message}`);
    utterance.lang = language === 'te' ? 'te-IN' : language === 'hi' ? 'hi-IN' : language === 'mr' ? 'mr-IN' : language === 'ta' ? 'ta-IN' : 'en-IN';
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utterance);
  };

  if (duplicateGrievance) {
    return (
      <div id="duplicate-grievance-dialog" className="max-w-lg mx-auto p-6 sm:p-8 rounded-3xl bg-white border border-amber-200 shadow-xs text-center">
        <h2 className="text-lg font-bold text-slate-900">This complaint appears to have already been submitted.</h2>
        <p className="mt-2 text-xs text-slate-500">Existing Grievance: <strong>{duplicateGrievance.id}</strong></p>
        <div className="mt-6 flex flex-col sm:flex-row justify-center gap-3">
          <button type="button" onClick={() => setActiveTab('MY_GRIEVANCES')} className="px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold">View Existing Complaint</button>
          <button type="button" onClick={() => { setDuplicateGrievance(null); handleSubmitGrievance(true); }} className="px-4 py-2.5 rounded-xl border border-slate-300 bg-white text-slate-700 text-xs font-bold">Submit Anyway</button>
        </div>
      </div>
    );
  }

  if (submittedGrievanceId) {
    return (
      <div id="grievance-success-view" className="max-w-2xl mx-auto animate-in fade-in duration-200">
        <div className="p-6 sm:p-10 rounded-3xl bg-white border border-slate-200 shadow-xs text-center">
          <CheckCircle2 className="w-16 h-16 mx-auto text-emerald-600" />
          <h1 className="mt-5 text-2xl sm:text-3xl font-extrabold text-slate-900">{successCopy.title}</h1>
          <div className="mt-6 p-5 rounded-2xl bg-emerald-50 border border-emerald-200">
            <p className="text-sm font-semibold text-emerald-900">{successCopy.number}</p>
            <p className="mt-2 text-xl font-extrabold tracking-wide text-slate-900">{submittedGrievanceId}</p>
            <p className="mt-3 text-sm text-slate-700">{successCopy.message}</p>
          </div>
          <button
            type="button"
            onClick={handleListenSuccess}
            className="mt-5 px-5 py-2.5 rounded-xl border border-slate-300 bg-white text-slate-700 text-sm font-bold inline-flex items-center gap-2 hover:bg-slate-50"
          >
            <Volume2 className="w-4 h-4" />
            <span>{successCopy.listen}</span>
          </button>
          <div className="mt-7 grid grid-cols-1 sm:grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => setActiveTab('MY_GRIEVANCES')}
              className="min-h-14 px-5 py-3 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-sm font-bold flex items-center justify-center gap-2"
            >
              <MapPin className="w-5 h-5" />
              <span>{successCopy.status}</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('HOME')}
              className="min-h-14 px-5 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-sm font-bold flex items-center justify-center gap-2"
            >
              <Home className="w-5 h-5" />
              <span>{successCopy.home}</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div id="grievance-wizard-view" className="max-w-3xl mx-auto space-y-6 animate-in fade-in duration-200">
      {/* Top Breadcrumb Steps */}
      <div className="p-4 sm:p-6 rounded-3xl bg-white border border-slate-200 shadow-xs">
        <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-100">
          <div>
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900">{t('raiseGrievance')}</h1>
            <p className="text-xs text-slate-500 mt-0.5">
              Intelligent Public Grievance Redressal with Automated Routing
            </p>
          </div>
          <span className="px-3 py-1 rounded-full bg-amber-50 text-amber-800 text-xs font-bold border border-amber-200">
            Step {step} of 4
          </span>
        </div>

        {/* Step Indicator */}
        <div className="grid grid-cols-4 gap-1.5 sm:gap-2 text-center text-[10px] sm:text-xs font-semibold mb-6">
          <div className={`p-1.5 sm:p-2 rounded-xl border truncate ${step >= 1 ? 'bg-slate-900 text-white border-slate-900' : 'bg-slate-50 text-slate-400'}`}>
            1. Issue
          </div>
          <div className={`p-1.5 sm:p-2 rounded-xl border truncate ${step >= 2 ? 'bg-slate-900 text-white border-slate-900' : 'bg-slate-50 text-slate-400'}`}>
            2. Location
          </div>
          <div className={`p-1.5 sm:p-2 rounded-xl border truncate ${step >= 3 ? 'bg-slate-900 text-white border-slate-900' : 'bg-slate-50 text-slate-400'}`}>
            3. Details
          </div>
          <div className={`p-1.5 sm:p-2 rounded-xl border truncate ${step >= 4 ? 'bg-slate-900 text-white border-slate-900' : 'bg-slate-50 text-slate-400'}`}>
            4. Submit
          </div>
        </div>

        {/* STEP 1: SELECT GRIEVANCE TYPE */}
        {step === 1 && (
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-900">
              Speak your problem or select an issue:
            </h3>

            <div className="flex flex-col items-center gap-3 py-2">
              <button
                type="button"
                onClick={isIssueListening ? undefined : handleIssueVoice}
                disabled={isIssueProcessing}
                className={`relative w-24 h-24 rounded-full flex items-center justify-center text-white shadow-lg transition-all disabled:opacity-70 ${
                  isIssueListening ? 'bg-rose-600 animate-pulse scale-105' : isIssueProcessing ? 'bg-amber-600' : 'bg-emerald-600 hover:bg-emerald-700 hover:scale-105'
                }`}
                aria-label="Speak your complaint"
              >
                <Mic className="w-10 h-10" />
                {isIssueListening && <span className="absolute -inset-2 rounded-full border-2 border-rose-400 animate-ping opacity-60" />}
              </button>
              <p className="text-xs font-semibold text-slate-600 text-center">
                {isIssueListening ? t('listening') : isIssueProcessing ? processingLabel : t('speakPrompt')}
              </p>
              {issueTranscript && <p className="max-w-lg px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-700 text-center">“{issueTranscript}”</p>}
            </div>

            {detectedType && (
              <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-center">
                <p className="text-xs font-semibold text-amber-950">{t('voiceConfirmPrompt')}</p>
                <p className="mt-1 text-sm font-bold text-slate-900">{localizedIssueLabel(detectedType)}</p>
                <div className="mt-3 flex justify-center gap-2">
                  <button
                    type="button"
                    onClick={() => { setSelectedType(detectedType); setDetectedType(null); setStep(2); }}
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold"
                  >{t('confirmYes')}</button>
                  <button
                    type="button"
                    onClick={() => { setDetectedType(null); setIssueTranscript(''); handleIssueVoice(); }}
                    className="px-4 py-2 rounded-xl border border-slate-300 bg-white text-slate-700 text-xs font-bold"
                  >{t('confirmNo')}</button>
                </div>
              </div>
            )}

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {GRIEVANCE_TYPES.map((gt) => (
                <button
                  type="button"
                  key={gt.id}
                  onClick={() => setSelectedType(gt)}
                  className={`p-3 rounded-2xl border-2 cursor-pointer transition-all flex flex-col items-center text-center gap-2 ${
                    selectedType.id === gt.id
                      ? 'border-amber-600 bg-amber-50/60 shadow-xs'
                      : 'border-slate-200 bg-white hover:border-slate-300'
                  }`}
                >
                  <span className="text-3xl shrink-0">{gt.icon}</span>
                  <span className="text-[11px] font-bold text-slate-900 leading-tight">{localizedIssueLabel(gt)}</span>
                </button>
              ))}
            </div>

            <div className="pt-4 flex justify-end">
              <button
                onClick={() => setStep(2)}
                className="px-6 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-colors flex items-center gap-2"
              >
                <span>Continue to Location</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: SELECT RELEVANT LOCATION & GPS */}
        {step === 2 && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900">
                Where is this issue occurring?
              </h3>
              <button
                onClick={handleDetectGPS}
                disabled={locationDetecting}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 text-xs font-semibold transition-colors"
              >
                <Navigation className={`w-3.5 h-3.5 ${locationDetecting ? 'animate-spin' : ''}`} />
                <span>{locationDetecting ? 'Detecting...' : 'Use My Current Location'}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="text-[11px] font-semibold text-slate-600 block mb-1">State</label>
                <input
                  type="text"
                  value={state}
                  onChange={(e) => setState(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs text-slate-900 bg-white"
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-600 block mb-1">District</label>
                <input
                  type="text"
                  value={district}
                  onChange={(e) => setDistrict(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs text-slate-900 bg-white"
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-600 block mb-1">Mandal / Municipality</label>
                <input
                  type="text"
                  value={mandal}
                  onChange={(e) => setMandal(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs text-slate-900 bg-white"
                />
              </div>
            </div>

            <div>
              <label className="text-[11px] font-semibold text-slate-600 block mb-1">Enter Location Manually: Landmark / Street / Door No.</label>
              <input
                type="text"
                value={landmark}
                onChange={(e) => setLandmark(e.target.value)}
                placeholder="e.g. Near Gajuwaka High School gate, 3rd Cross Street"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs text-slate-900 bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500"
              />
            </div>

            {gpsCoordinates && (
              <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900 flex items-center gap-2">
                <MapPin className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>
                  Geotagged Coordinates: {gpsCoordinates.latitude.toFixed(4)}° N, {gpsCoordinates.longitude.toFixed(4)}° E (Auto-mapped to Ward Jurisdiction)
                </span>
              </div>
            )}

            <div className="pt-4 flex justify-between">
              <button
                onClick={() => setStep(1)}
                className="px-4 py-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-xs font-semibold text-slate-700 flex items-center gap-1.5"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Back</span>
              </button>
              <button
                onClick={() => setStep(3)}
                className="px-6 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-colors flex items-center gap-2"
              >
                <span>Continue to Details</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: PROBLEM DESCRIPTION (TEXT + VOICE + PHOTO) */}
        {step === 3 && (
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-900">
              Describe the problem in detail:
            </h3>

            <div>
              <textarea
                rows={4}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Please describe what happened, for how many days the issue has persisted, and the impact on local residents..."
                className="w-full p-3.5 rounded-2xl border border-slate-200 text-xs text-slate-900 bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500"
              />
            </div>

            {/* Multimedia Attachments: Voice Note & Photo */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Voice Attachment */}
              <div
                onClick={() => hasVoiceNote ? setHasVoiceNote(false) : handleDetailsVoice()}
                className={`p-3.5 rounded-2xl border-2 cursor-pointer transition-all flex items-center gap-3 ${
                  hasVoiceNote
                    ? 'border-emerald-500 bg-emerald-50 text-emerald-950'
                    : 'border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700'
                }`}
              >
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${hasVoiceNote ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-600'}`}>
                  <Mic className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-bold block">
                    {hasVoiceNote ? 'Voice Recording Attached (0:42s)' : 'Attach Voice Note'}
                  </span>
                  <span className="text-[10px] text-slate-500">
                    {hasVoiceNote ? 'Click to remove' : 'Click to record/attach audio statement'}
                  </span>
                </div>
              </div>

              {/* Photo Attachment */}
              <div
                onClick={handleTakePhoto}
                className={`p-3.5 rounded-2xl border-2 cursor-pointer transition-all flex items-center gap-3 ${
                  hasPhoto
                    ? 'border-emerald-500 bg-emerald-50 text-emerald-950'
                    : 'border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700'
                }`}
              >
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${hasPhoto ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-600'}`}>
                  <Camera className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-bold block">
                    {hasPhoto ? 'Photo Attached' : 'Take Photo'}
                  </span>
                  <span className="text-[10px] text-slate-500">
                    {hasPhoto ? 'Click to replace photo' : 'Use camera or upload from device'}
                  </span>
                </div>
              </div>
            </div>

            <input ref={uploadInputRef} type="file" accept="image/*" onChange={handleUploadPhoto} className="hidden" />

            {(isCameraOpen || cameraPreview || cameraError || photoPreview) && (
              <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50 space-y-3">
                {isCameraOpen && (
                  <div className="space-y-3">
                    <video
                      ref={videoRef}
                      autoPlay
                      playsInline
                      onLoadedMetadata={(event) => { event.currentTarget.srcObject = cameraStream; }}
                      className="w-full max-h-64 rounded-xl bg-slate-900 object-cover"
                    />
                    <div className="flex justify-center gap-2">
                      <button type="button" onClick={handleCapturePhoto} className="px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-bold">Capture Photo</button>
                      <button type="button" onClick={stopCamera} className="px-4 py-2 rounded-xl border border-slate-300 bg-white text-slate-700 text-xs font-bold">Cancel</button>
                    </div>
                  </div>
                )}

                {cameraError && !isCameraOpen && (
                  <div className="space-y-3">
                    <p className="text-xs font-semibold text-rose-700">Camera access was not allowed.</p>
                    <div className="flex flex-wrap gap-2">
                      <button type="button" onClick={() => uploadInputRef.current?.click()} className="px-4 py-2 rounded-xl bg-slate-900 text-white text-xs font-bold flex items-center gap-1.5"><Upload className="w-3.5 h-3.5" />Upload from Device</button>
                      <button type="button" onClick={handleTakePhoto} className="px-4 py-2 rounded-xl border border-slate-300 bg-white text-slate-700 text-xs font-bold">Try Camera Again</button>
                    </div>
                  </div>
                )}

                {cameraPreview && !isCameraOpen && (
                  <div className="space-y-3">
                    <img src={cameraPreview} alt="Captured complaint preview" className="w-full max-h-64 rounded-xl object-cover" />
                    <div className="flex justify-center gap-2">
                      <button type="button" onClick={() => handleUsePhoto(cameraPreview)} className="px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-bold">Use Photo</button>
                      <button type="button" onClick={handleTakePhoto} className="px-4 py-2 rounded-xl border border-slate-300 bg-white text-slate-700 text-xs font-bold">Retake</button>
                    </div>
                  </div>
                )}

                {photoPreview && !isCameraOpen && !cameraPreview && (
                  <div className="space-y-2">
                    <img src={photoPreview} alt="Complaint attachment preview" className="w-full max-h-64 rounded-xl object-cover" />
                    <div className="flex justify-center gap-2">
                      <button type="button" onClick={handleTakePhoto} className="px-4 py-2 rounded-xl border border-slate-300 bg-white text-slate-700 text-xs font-bold">Retake / Replace</button>
                      <button type="button" onClick={() => uploadInputRef.current?.click()} className="px-4 py-2 rounded-xl bg-slate-900 text-white text-xs font-bold">Upload Another</button>
                    </div>
                  </div>
                )}
              </div>
            )}

            <div className="pt-4 flex justify-between">
              <button
                onClick={() => setStep(2)}
                className="px-4 py-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-xs font-semibold text-slate-700 flex items-center gap-1.5"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Back</span>
              </button>
              <button
                onClick={() => setStep(4)}
                className="px-6 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-colors flex items-center gap-2"
              >
                <span>Review & Route</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 4: REVIEW & AUTOMATIC ROUTING PREVIEW */}
        {step === 4 && (
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-900">
              Review & Submit to Samanvay Auto-Routing Engine
            </h3>

            {/* Routing Preview Card */}
            <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200 space-y-3">
              <div className="flex items-center gap-2 text-xs font-bold text-amber-950">
                <Sparkles className="w-4 h-4 text-amber-700" />
                <span>Intelligent Routing Preview:</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="bg-white p-3 rounded-xl border border-amber-100">
                  <span className="text-slate-500 block text-[10px]">Target Department:</span>
                  <span className="font-bold text-slate-900">{selectedType.deptRecommendation}</span>
                </div>

                <div className="bg-white p-3 rounded-xl border border-amber-100">
                  <span className="text-slate-500 block text-[10px]">Jurisdiction:</span>
                  <span className="font-bold text-slate-900">{district} • {mandal}</span>
                </div>

                <div className="bg-white p-3 rounded-xl border border-amber-100">
                  <span className="text-slate-500 block text-[10px]">Assigned Officer:</span>
                  <span className="font-bold text-slate-900">Ravi Kumar (SMV-OFF-204)</span>
                </div>

                <div className="bg-white p-3 rounded-xl border border-amber-100">
                  <span className="text-slate-500 block text-[10px]">Service Level Agreement (SLA):</span>
                  <span className="font-bold text-emerald-700">7 Days Guaranteed Resolution</span>
                </div>
              </div>

              <div className="bg-white p-3 rounded-xl border border-amber-100 text-xs">
                <span className="text-slate-500 block text-[10px]">Issue Description:</span>
                <span className="text-slate-800 mt-0.5 block">
                  {description || `Reported ${selectedType.issueType} in ${mandal}.`}
                </span>
                {(hasVoiceNote || hasPhoto) && (
                  <div className="mt-2 flex items-center gap-2 text-[11px] text-emerald-800 font-semibold">
                    {hasVoiceNote && <span>✓ Voice Recording</span>}
                    {hasPhoto && <span>✓ Photo Proof</span>}
                  </div>
                )}
              </div>
            </div>

            <div className="pt-4 flex justify-between">
              <button
                onClick={() => setStep(3)}
                className="px-4 py-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-xs font-semibold text-slate-700 flex items-center gap-1.5"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Back</span>
              </button>
              <button
                id="btn-submit-grievance-now"
                type="button"
                onClick={() => handleSubmitGrievance()}
                disabled={isSubmitting}
                className="px-8 py-3 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold shadow-md transition-all flex items-center gap-2 disabled:opacity-50"
              >
                {isSubmitting ? (
                  <span>Routing to Officer Desk...</span>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Submit & Generate Grievance ID</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
