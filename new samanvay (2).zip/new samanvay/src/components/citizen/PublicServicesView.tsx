import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ServiceItem, ServiceCategory } from '../../types';
import {
  GraduationCap,
  FileCheck2,
  HeartPulse,
  Home,
  ShieldAlert,
  Utensils,
  Sprout,
  Briefcase,
  Search,
  ArrowRight,
  Clock,
  CheckCircle2,
  Sparkles,
  Layers,
  ChevronRight,
} from 'lucide-react';

const CATEGORY_ICON_MAP: Record<string, React.ReactNode> = {
  'cat-education': <GraduationCap className="w-4 h-4" />,
  'cat-certificates': <FileCheck2 className="w-4 h-4" />,
  'cat-health': <HeartPulse className="w-4 h-4" />,
  'cat-housing': <Home className="w-4 h-4" />,
  'cat-pension': <ShieldAlert className="w-4 h-4" />,
  'cat-food': <Utensils className="w-4 h-4" />,
  'cat-agriculture': <Sprout className="w-4 h-4" />,
  'cat-employment': <Briefcase className="w-4 h-4" />,
};

export const PublicServicesView: React.FC = () => {
  const { categories, services, setSelectedService, t } = useApp();
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredServices = services.filter((s) => {
    const matchesCategory = selectedCategory === 'ALL' || s.categoryId === selectedCategory;
    const matchesSearch =
      searchQuery === '' ||
      s.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.shortDescription.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  return (
    <div id="public-services-view" className="space-y-6 animate-in fade-in duration-200">
      {/* Header & Search */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-3 border-b border-slate-200">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">{t('publicServices')}</h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            {t('servicesIntro')}
          </p>
        </div>

        {/* Search input */}
        <div className="relative w-full sm:w-80 shrink-0">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t('searchServices')}
            className="w-full pl-9 pr-4 py-2 rounded-xl border border-slate-300 bg-white text-xs sm:text-sm text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 focus:border-transparent shadow-xs"
          />
        </div>
      </div>

      {/* Category Pills (Progressive selection) */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 -mx-3 px-3 sm:mx-0 sm:px-0">
        <button
          onClick={() => setSelectedCategory('ALL')}
          className={`min-h-[40px] px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 shrink-0 ${
            selectedCategory === 'ALL'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>{t('allSchemes')} ({services.length})</span>
        </button>

        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id)}
            className={`min-h-[40px] px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-2 shrink-0 ${
              selectedCategory === cat.id
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            <span className={selectedCategory === cat.id ? 'text-white' : 'text-emerald-700'}>
              {CATEGORY_ICON_MAP[cat.id] || <Layers className="w-4 h-4" />}
            </span>
            <span>{t(cat.titleKey)}</span>
          </button>
        ))}
      </div>

      {/* Services Responsive Grid (1-col mobile, 2-col tablet/laptop, 3-col large monitors) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 gap-5">
        {filteredServices.map((service) => (
          <div
            key={service.id}
            id={`service-card-${service.id}`}
            onClick={() => setSelectedService(service)}
            className="group cursor-pointer rounded-2xl border border-slate-200 bg-white p-5 sm:p-6 hover:border-emerald-600 hover:shadow-lg transition-all duration-150 flex flex-col justify-between"
          >
            <div>
              <div className="flex items-start justify-between gap-2">
                <span className="text-[11px] font-bold text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                  {service.department}
                </span>
                <span className="flex items-center gap-1 text-[11px] text-slate-500 font-medium shrink-0">
                  <Clock className="w-3 h-3 text-slate-400" />
                  <span>{service.processingTimeDays} Days SLA</span>
                </span>
              </div>

              <h3 className="text-base sm:text-lg font-bold text-slate-900 group-hover:text-emerald-700 transition-colors mt-3">
                {service.title}
              </h3>

              <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed line-clamp-2">
                {service.shortDescription}
              </p>

              <div className="mt-4 p-3 rounded-xl bg-slate-50 border border-slate-100 text-xs">
                <span className="font-bold text-slate-900 block mb-0.5">{t('keyBenefit')}</span>
                <span className="text-slate-600 text-[11px] sm:text-xs leading-relaxed">{service.benefits}</span>
              </div>
            </div>

            <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
              <span className="text-[11px] text-slate-400 truncate">
                Deadline: {service.applicationDeadline}
              </span>

              <button
                type="button"
                className="min-h-[38px] px-3.5 py-1.5 rounded-xl bg-slate-900 group-hover:bg-emerald-600 text-white text-xs font-bold transition-colors flex items-center gap-1.5 shadow-xs shrink-0"
              >
                <span>{t('checkEligibility')}</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {filteredServices.length === 0 && (
        <div className="p-12 text-center bg-white rounded-2xl border border-slate-200">
          <p className="text-slate-500 text-sm">No government services match your current query.</p>
        </div>
      )}
    </div>
  );
};
