import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  CheckCircle2,
  AlertCircle,
  ShieldCheck,
  FileText,
  Camera,
  FolderLock,
  ArrowRight,
  Clock,
  Sparkles,
  Building2,
  Info,
  Calendar,
  Lock,
} from 'lucide-react';
import { api, EligibilityResponse } from '../../services/api';

const DOC_NAME_MAP: Record<string, string> = {
  AADHAAR: 'Aadhaar Card (UIDAI)',
  MARKS_MEMO: 'Class 12 / Intermediate Marks Memo',
  INCOME_CERTIFICATE: 'Annual Family Income Certificate',
  CASTE_CERTIFICATE: 'Integrated Caste & Community Certificate',
  RESIDENCE_CERTIFICATE: 'Residence / Domicile Certificate',
  RATION_CARD: 'Smart Ration Card (NFSA)',
  BONAFIDE_CERTIFICATE: 'College Bonafide / Study Certificate',
  DISABILITY_CERTIFICATE: 'Disability Certificate',
};

export const ServiceDetailsModal: React.FC = () => {
  const {
    selectedService,
    setSelectedService,
    isAuthenticated,
    setIsAuthModalOpen,
    currentUser,
    profile,
    t,
    refreshAllData,
    refreshProfile,
    addNotification,
    setActiveTab,
    setIsDigiLockerModalOpen,
    setIsCameraModalOpen,
    setCameraTargetDocType,
    documents,
  } = useApp();

  const [eligibilityData, setEligibilityData] = useState<EligibilityResponse | null>(null);
  const [loadingEligibility, setLoadingEligibility] = useState(true);
  const [isApplying, setIsApplying] = useState(false);

  useEffect(() => {
    if (selectedService) {
      setLoadingEligibility(true);
      const cid = currentUser?.citizenId || 'SMV-CIT-10245';
      api
        .checkEligibility(selectedService.id, cid)
        .then((data) => {
          setEligibilityData(data);
          setLoadingEligibility(false);
        })
        .catch((err) => {
          console.error('Eligibility check error:', err);
          setLoadingEligibility(false);
        });
    }
  }, [selectedService, currentUser?.citizenId, documents]);

  if (!selectedService) return null;

  const handleApply = async () => {
    if (!isAuthenticated) {
      addNotification('info', 'Authentication Required', 'Please login with your mobile number, Citizen ID, or DigiLocker to submit your application.');
      setIsAuthModalOpen(true);
      return;
    }

    setIsApplying(true);
    try {
      const newApp = await api.submitApplication(
        selectedService.id,
        currentUser.citizenId || 'SMV-CIT-10245'
      );
      await refreshAllData();
      await refreshProfile();

      setIsApplying(false);
      setSelectedService(null);
      setActiveTab('MY_APPLICATIONS');

      addNotification(
        'success',
        'Application Submitted Successfully',
        `Universal ID: ${newApp.id} has been transmitted to ${selectedService.department} for officer verification.`
      );
    } catch (err) {
      console.error('Application submit error:', err);
      setIsApplying(false);
    }
  };

  const handleMissingDocScan = (docType: string) => {
    setCameraTargetDocType(docType);
    setIsCameraModalOpen(true);
  };

  const allDocumentsReady = eligibilityData?.missingCount === 0;

  return (
    <div
      id="service-details-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200 overflow-y-auto"
    >
      <div
        id="service-details-dialog"
        className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative my-8"
      >
        {/* Header */}
        <div className="flex items-start justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <span className="text-[11px] font-bold text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
              {selectedService.department}
            </span>
            <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 mt-2">
              {selectedService.title}
            </h2>
          </div>
          <button
            onClick={() => setSelectedService(null)}
            className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="my-5 space-y-5 max-h-[60vh] sm:max-h-[65vh] overflow-y-auto pr-1">
          {/* Key Scheme Benefits */}
          <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200">
            <div className="flex items-center gap-2 text-xs font-bold text-emerald-900 mb-1">
              <Sparkles className="w-4 h-4 text-emerald-700 shrink-0" />
              <span>Entitlement & Benefits</span>
            </div>
            <p className="text-xs sm:text-sm text-emerald-950 font-medium leading-relaxed">
              {selectedService.benefits}
            </p>
            <div className="mt-3 flex flex-wrap items-center gap-3 sm:gap-4 text-xs text-emerald-800">
              <span className="flex items-center gap-1 font-medium">
                <Clock className="w-3.5 h-3.5 shrink-0" />
                <span>Processing Time: {selectedService.processingTimeDays} Days SLA</span>
              </span>
              <span className="flex items-center gap-1 font-medium">
                <Calendar className="w-3.5 h-3.5 shrink-0" />
                <span>Deadline: {selectedService.applicationDeadline}</span>
              </span>
            </div>
          </div>

          {/* ELIGIBILITY RULES ENGINE SECTION */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-slate-600" />
                <span>Preliminary Eligibility Check</span>
              </h3>
              {loadingEligibility ? (
                <span className="text-xs text-slate-400 animate-pulse">Evaluating profile...</span>
              ) : eligibilityData?.isEligible ? (
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-xs font-extrabold flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>ELIGIBLE</span>
                </span>
              ) : (
                <span className="px-2.5 py-0.5 rounded-full bg-rose-100 text-rose-800 text-xs font-extrabold flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>NOT ELIGIBLE</span>
                </span>
              )}
            </div>

            {/* Itemized Criteria Evaluation */}
            <div className="rounded-2xl border border-slate-200 bg-slate-50/70 p-3.5 space-y-2">
              {eligibilityData?.ruleEvaluations.map((rule) => (
                <div
                  key={rule.ruleId}
                  className="flex items-start gap-2.5 p-2 rounded-xl bg-white border border-slate-100 text-xs"
                >
                  {rule.passed ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  )}
                  <div className="flex-1 min-w-0">
                    <span className="font-medium text-slate-900 block">{rule.description}</span>
                    <span
                      className={`text-[11px] mt-0.5 block ${
                        rule.passed ? 'text-emerald-700 font-semibold' : 'text-rose-600 font-bold'
                      }`}
                    >
                      {rule.passed ? 'Verified from Profile' : rule.reason}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            <p className="text-[11px] text-slate-400 italic">
              *Samanvay performs automated preliminary eligibility verification. Final statutory sanction is granted by the concerned department officer.
            </p>
          </div>

          {/* SMART DOCUMENT REUSE & MISSING DOCUMENT IDENTIFIER */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <FolderLock className="w-4 h-4 text-slate-600" />
                <span>Smart Document System</span>
              </h3>
              <span className="text-xs text-slate-500 font-medium">
                {eligibilityData?.availableCount} available • {eligibilityData?.missingCount} missing
              </span>
            </div>

            <div className="space-y-2">
              {eligibilityData?.documentStatus.map((item) => (
                <div
                  key={item.type}
                  className={`p-3 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs transition-colors ${
                    item.available
                      ? 'bg-emerald-50/40 border-emerald-200'
                      : 'bg-amber-50/50 border-amber-300'
                  }`}
                >
                  <div className="flex items-start gap-2.5">
                    {item.available ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    ) : (
                      <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    )}
                    <div>
                      <span className="font-bold text-slate-900">
                        {DOC_NAME_MAP[item.type] || item.type}
                      </span>
                      {item.available && item.documentItem ? (
                        <p className="text-[11px] text-slate-500 font-mono mt-0.5">
                          {item.documentItem.source === 'DIGILOCKER' ? 'DigiLocker Verified' : 'Scanned & Verified'} • #{item.documentItem.documentNumber}
                        </p>
                      ) : (
                        <p className="text-[11px] text-amber-700 font-semibold mt-0.5">
                          Missing in your profile — Add once, reuse everywhere.
                        </p>
                      )}
                    </div>
                  </div>

                  {/* If missing, offer DigiLocker & Camera Scan buttons */}
                  {!item.available && (
                    <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                      <button
                        onClick={() => setIsDigiLockerModalOpen(true)}
                        className="px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-bold transition-colors flex items-center gap-1"
                      >
                        <span>DigiLocker</span>
                      </button>
                      <button
                        onClick={() => handleMissingDocScan(item.type)}
                        className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-900 text-white text-[11px] font-bold transition-colors flex items-center gap-1"
                      >
                        <Camera className="w-3 h-3" />
                        <span>Camera</span>
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Action Footer */}
        <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="text-[11px] text-slate-500">
            {allDocumentsReady
              ? 'All required documents are verified and ready for instant submission.'
              : 'Add missing document(s) above to enable 1-click submission.'}
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={() => setSelectedService(null)}
              className="w-full sm:w-auto px-4 py-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-xs font-semibold text-slate-700"
            >
              Close
            </button>

            <button
              id="btn-apply-service-now"
              onClick={handleApply}
              disabled={isApplying || !eligibilityData?.isEligible}
              className={`w-full sm:w-auto px-6 py-2.5 rounded-xl text-xs font-bold text-white shadow-md transition-all flex items-center justify-center gap-1.5 ${
                eligibilityData?.isEligible
                  ? 'bg-emerald-600 hover:bg-emerald-700 hover:scale-105'
                  : 'bg-slate-400 cursor-not-allowed opacity-60'
              }`}
            >
              {isApplying ? (
                <span>Generating Universal Application...</span>
              ) : (
                <>
                  <span>{t('applyNow')}</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
