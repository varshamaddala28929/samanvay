import React, { useEffect, useState } from 'react';
import { useApp } from '../context/AppContext';
import { Grievance, Application } from '../types';
import {
  TrendingUp,
  AlertTriangle,
  ShieldAlert,
  CheckCircle2,
  Clock,
  Send,
  Building2,
  MapPin,
  Sparkles,
  Zap,
  BarChart3,
  Users,
  Search,
} from 'lucide-react';
import { api } from '../services/api';

export const HigherOfficerDashboard: React.FC = () => {
  const {
    currentUser,
    applications,
    grievances,
    t,
    refreshAllData,
    addNotification,
    demoDesk,
  } = useApp();

  const [selectedGrv, setSelectedGrv] = useState<Grievance | null>(
    grievances.find((g) => g.isSlaBreached || g.status === 'ESCALATED') || grievances[0] || null
  );
  const [executiveDirective, setExecutiveDirective] = useState('');
  const [isSendingDirective, setIsSendingDirective] = useState(false);

  const breachedGrievances = grievances.filter((g) => g.isSlaBreached || g.status === 'ESCALATED');
  const resolvedGrievances = grievances.filter((g) => g.status === 'RESOLVED');
  const approvedApplications = applications.filter((a) => a.status === 'APPROVED');
  const escalatedApplications = applications.filter((a) => a.status === 'ESCALATED');

  useEffect(() => {
    setSelectedGrv((current) => breachedGrievances.find((grievance) => grievance.id === current?.id) || breachedGrievances[0] || null);
  }, [grievances]);

  const slaComplianceRate = Math.round(
    ((grievances.length - breachedGrievances.length) / Math.max(1, grievances.length)) * 100
  );

  const handleSendDirective = async () => {
    if (!selectedGrv || !executiveDirective) return;
    setIsSendingDirective(true);

    try {
      await api.higherOfficerIntervene(selectedGrv.id, 'DIRECTIVE', executiveDirective);

      await refreshAllData();
      setIsSendingDirective(false);
      setExecutiveDirective('');

      addNotification(
        'success',
        'Executive Directive Dispatched',
        `Official order sent to Officer Ravi Kumar for Grievance ${selectedGrv.id}.`
      );
    } catch (err) {
      console.error('Directive error:', err);
      setIsSendingDirective(false);
    }
  };

  const handleResolveApplication = async (applicationId: string) => {
    try {
      await api.updateApplicationStatus(applicationId, 'APPROVED', 'Final review completed by Higher Officer.', currentUser.name, 'HIGHER_OFFICER');
      await refreshAllData();
      addNotification('success', 'Application Resolved', `Application ${applicationId} approved after higher-officer review.`);
    } catch (err) {
      console.error('Application resolution error:', err);
    }
  };

  const handleSimulateBreach = async () => {
    try {
      const targetId = selectedGrv?.id || 'SMV-GRV-2026-0001';
      await api.simulateSlaBreach(targetId);
      await refreshAllData();
      addNotification(
        'warning',
        'SLA Breach Simulated',
        'Timer exceeded 7-day limit. Auto-escalated to Joint Secretary dashboard.'
      );
    } catch (err) {
      console.error('Simulate error:', err);
    }
  };

  return (
    <div id="higher-officer-dashboard-view" className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-3 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-2xl font-extrabold text-slate-900">
              State & District Monitoring Dashboard
            </h1>
            <span className="px-2.5 py-0.5 rounded-full bg-purple-100 text-purple-800 text-xs font-bold font-mono">
              {currentUser.id}
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            <strong>{currentUser.name}</strong> • {currentUser.designation} • {currentUser.department}
          </p>
        </div>

        {/* Demo trigger */}
        <button
          onClick={handleSimulateBreach}
          className="px-3.5 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200 text-xs font-bold transition-colors flex items-center gap-1.5 self-start md:self-auto"
        >
          <Zap className="w-3.5 h-3.5 text-rose-600" />
          <span>Simulate SLA Breach</span>
        </button>
      </div>

      {/* High-Level Executive Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 block">SLA Compliance Rate</span>
          <span className="text-2xl font-extrabold text-emerald-600 block mt-1">{slaComplianceRate}%</span>
          <span className="text-[10px] text-emerald-700 font-medium">Within 7-day statutory standard</span>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 block">SLA Overdue / Breached</span>
          <span className="text-2xl font-extrabold text-rose-600 block mt-1">{breachedGrievances.length}</span>
          <span className="text-[10px] text-rose-700 font-medium">Automatic escalation triggered</span>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 block">Total Public Schemes Processed</span>
          <span className="text-2xl font-extrabold text-slate-900 block mt-1">{applications.length}</span>
          <span className="text-[10px] text-blue-600 font-medium">{approvedApplications.length} Approved & Sanctioned</span>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 block">Average Redressal Time</span>
          <span className="text-2xl font-extrabold text-purple-700 block mt-1">3.8 Days</span>
          <span className="text-[10px] text-slate-500 font-medium">Target: &lt; 7.0 Days</span>
        </div>
      </div>

      {/* Escalated Tickets & Direct Executive Intervention Desk */}
      {demoDesk === 'PUBLIC_SERVICES_HIGHER' && escalatedApplications.length > 0 && (
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Escalated Public-Service Applications ({escalatedApplications.length})</h3>
          {escalatedApplications.map((application) => (
            <div key={application.id} className="p-3 rounded-xl border border-purple-200 bg-purple-50/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <span className="text-[10px] font-mono font-bold text-slate-500">{application.id}</span>
                <p className="text-xs font-bold text-slate-900 mt-1">{application.serviceTitle}</p>
                <p className="text-[11px] text-slate-500">{application.citizenId} • {application.status}</p>
              </div>
              <button type="button" onClick={() => handleResolveApplication(application.id)} className="px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold">Approve &amp; Sanction Benefit</button>
            </div>
          ))}
        </div>
      )}

      <div className={`${demoDesk === 'GRIEVANCES_HIGHER' ? '' : 'hidden'} grid grid-cols-1 lg:grid-cols-12 gap-6`}>
        {/* Left: Escalated Grievance Queue */}
        <div className="lg:col-span-5 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Escalated / At-Risk Grievance Tickets ({breachedGrievances.length})
            </h3>
          </div>

          {breachedGrievances.map((grv) => (
            <div
              key={grv.id}
              onClick={() => setSelectedGrv(grv)}
              className={`p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                selectedGrv?.id === grv.id
                  ? 'border-purple-600 bg-purple-50/40 shadow-md'
                  : 'border-slate-200 bg-white hover:border-slate-300'
              }`}
            >
              <div className="flex items-start justify-between">
                <span className="text-[10px] font-mono font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                  {grv.id}
                </span>
                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                    grv.isSlaBreached || grv.status === 'ESCALATED'
                      ? 'bg-rose-100 text-rose-800 animate-pulse'
                      : 'bg-emerald-100 text-emerald-800'
                  }`}
                >
                  {grv.isSlaBreached ? 'SLA OVERDUE' : grv.status}
                </span>
              </div>

              <h4 className="text-xs font-bold text-slate-900 mt-2">{grv.issueType}</h4>
              <p className="text-[11px] text-slate-500 mt-0.5">
                District: <strong>{grv.location.district}</strong> • Mandal: {grv.location.mandal}
              </p>
              <span className="text-[10px] text-slate-400 block mt-2">
                Assigned: {grv.assignedOfficerName || 'Ravi Kumar'} ({grv.assignedOfficerId || 'SMV-OFF-204'})
              </span>
            </div>
          ))}
        </div>

        {/* Right: Executive Intervention & Directives */}
        <div className="lg:col-span-7">
          {selectedGrv ? (
            <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-5">
              <div className="flex items-start justify-between pb-3 border-b border-slate-100">
                <div>
                  <span className="text-xs font-mono font-bold text-slate-500">{selectedGrv.id}</span>
                  <h3 className="text-base font-extrabold text-slate-900 mt-1">
                    {selectedGrv.issueType}
                  </h3>
                </div>
                <span
                  className={`px-3 py-1 rounded-full text-xs font-bold ${
                    selectedGrv.isSlaBreached
                      ? 'bg-rose-100 text-rose-800 animate-pulse'
                      : 'bg-emerald-100 text-emerald-800'
                  }`}
                >
                  {selectedGrv.isSlaBreached ? 'ESCALATION ACTIVE' : selectedGrv.status}
                </span>
              </div>

              {/* Location & Officer Details */}
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200">
                  <span className="text-slate-400 block text-[10px]">Jurisdiction:</span>
                  <span className="font-bold text-slate-900 block mt-0.5">
                    {selectedGrv.location.landmark || selectedGrv.location.mandal}, {selectedGrv.location.district}
                  </span>
                </div>

                <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200">
                  <span className="text-slate-400 block text-[10px]">Responsible Officer:</span>
                  <span className="font-bold text-slate-900 block mt-0.5">
                    {selectedGrv.assignedOfficerName || 'Ravi Kumar'} ({selectedGrv.assignedOfficerId || 'SMV-OFF-204'})
                  </span>
                </div>
              </div>

              {/* Citizen Grievance Statement */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs">
                <span className="font-bold text-slate-900 block mb-1">Citizen Statement:</span>
                <p className="text-slate-700 leading-relaxed font-normal">
                  "{selectedGrv.description}"
                </p>
                  {selectedGrv.escalationReason && (
                    <p className="mt-2 text-rose-700 font-semibold">Escalation reason: {selectedGrv.escalationReason}</p>
                  )}
              </div>

              {/* Direct Executive Order Form */}
              <div className="p-4 rounded-2xl bg-purple-50/70 border border-purple-200 space-y-3">
                <div className="flex items-center gap-2 text-xs font-bold text-purple-950">
                  <Sparkles className="w-4 h-4 text-purple-700" />
                  <span>Issue Statutory Directive / Priority Resolution Order</span>
                </div>

                <div>
                  <textarea
                    rows={3}
                    value={executiveDirective}
                    onChange={(e) => setExecutiveDirective(e.target.value)}
                    placeholder="e.g. Issue urgent order to Municipal Health Officer to clear clogged drain within 24 hours and report back to Secretariat."
                    className="w-full p-3 rounded-xl border border-purple-200 text-xs bg-white text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                <div className="flex items-center justify-between pt-1">
                  <span className="text-[11px] text-purple-900 font-medium">
                    Instantly notifies assigned officer desk and updates citizen status.
                  </span>

                  <button
                    id="btn-send-executive-directive"
                    onClick={handleSendDirective}
                    disabled={isSendingDirective || !executiveDirective}
                    className="min-h-[40px] px-5 py-2.5 rounded-xl bg-purple-700 hover:bg-purple-800 text-white text-xs font-bold transition-colors flex items-center gap-1.5 shadow-md disabled:opacity-50"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Dispatch Directive</span>
                  </button>
                </div>
              </div>
            </div>
          ) : null}
        </div>
      </div>

      {/* District Performance & Statutory Redressal SLA Table (Responsive horizontal scroll for mobile/tablet, full multi-column on desktop) */}
      <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
          <div>
            <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-purple-700" />
              <span>Statewide District SLA Compliance & Resolution Performance</span>
            </h3>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Live monitoring across municipal corporations and rural mandals.
            </p>
          </div>
          <span className="text-[10px] text-slate-400 font-mono self-start sm:self-auto bg-slate-50 px-2.5 py-1 rounded-lg border border-slate-200">
            Updated: Live Sync
          </span>
        </div>

        <div className="overflow-x-auto -mx-5 sm:mx-0 px-5 sm:px-0">
          <table className="w-full text-left text-xs border-collapse min-w-[620px]">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/70 text-slate-500 font-semibold text-[11px]">
                <th className="py-2.5 px-3 rounded-l-xl">District Jurisdiction</th>
                <th className="py-2.5 px-3">Total Registered</th>
                <th className="py-2.5 px-3">Resolved</th>
                <th className="py-2.5 px-3">Avg SLA</th>
                <th className="py-2.5 px-3">Escalations</th>
                <th className="py-2.5 px-3 rounded-r-xl">Compliance Rate</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              <tr className="hover:bg-slate-50/80 transition-colors">
                <td className="py-3 px-3 font-bold text-slate-900 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  <span>Visakhapatnam (HQ)</span>
                </td>
                <td className="py-3 px-3 font-semibold text-slate-700">{grievances.length + 142}</td>
                <td className="py-3 px-3 text-emerald-700 font-bold">{resolvedGrievances.length + 138}</td>
                <td className="py-3 px-3 text-slate-600 font-mono">2.9 Days</td>
                <td className="py-3 px-3 text-rose-600 font-bold">{breachedGrievances.length}</td>
                <td className="py-3 px-3">
                  <div className="flex items-center gap-2">
                    <div className="w-24 bg-slate-100 rounded-full h-2 overflow-hidden">
                      <div className="bg-emerald-500 h-2 rounded-full" style={{ width: '96%' }}></div>
                    </div>
                    <span className="font-bold text-emerald-700">96.4%</span>
                  </div>
                </td>
              </tr>
              <tr className="hover:bg-slate-50/80 transition-colors">
                <td className="py-3 px-3 font-bold text-slate-900 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  <span>Vijayawada / NTR</span>
                </td>
                <td className="py-3 px-3 font-semibold text-slate-700">118</td>
                <td className="py-3 px-3 text-emerald-700 font-bold">112</td>
                <td className="py-3 px-3 text-slate-600 font-mono">3.4 Days</td>
                <td className="py-3 px-3 text-slate-500 font-bold">2</td>
                <td className="py-3 px-3">
                  <div className="flex items-center gap-2">
                    <div className="w-24 bg-slate-100 rounded-full h-2 overflow-hidden">
                      <div className="bg-emerald-500 h-2 rounded-full" style={{ width: '94%' }}></div>
                    </div>
                    <span className="font-bold text-emerald-700">94.9%</span>
                  </div>
                </td>
              </tr>
              <tr className="hover:bg-slate-50/80 transition-colors">
                <td className="py-3 px-3 font-bold text-slate-900 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                  <span>Guntur Urban</span>
                </td>
                <td className="py-3 px-3 font-semibold text-slate-700">96</td>
                <td className="py-3 px-3 text-emerald-700 font-bold">88</td>
                <td className="py-3 px-3 text-slate-600 font-mono">4.1 Days</td>
                <td className="py-3 px-3 text-amber-600 font-bold">4</td>
                <td className="py-3 px-3">
                  <div className="flex items-center gap-2">
                    <div className="w-24 bg-slate-100 rounded-full h-2 overflow-hidden">
                      <div className="bg-amber-500 h-2 rounded-full" style={{ width: '91%' }}></div>
                    </div>
                    <span className="font-bold text-amber-700">91.6%</span>
                  </div>
                </td>
              </tr>
              <tr className="hover:bg-slate-50/80 transition-colors">
                <td className="py-3 px-3 font-bold text-slate-900 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  <span>Tirupati / Chittoor</span>
                </td>
                <td className="py-3 px-3 font-semibold text-slate-700">84</td>
                <td className="py-3 px-3 text-emerald-700 font-bold">81</td>
                <td className="py-3 px-3 text-slate-600 font-mono">3.1 Days</td>
                <td className="py-3 px-3 text-slate-500 font-bold">1</td>
                <td className="py-3 px-3">
                  <div className="flex items-center gap-2">
                    <div className="w-24 bg-slate-100 rounded-full h-2 overflow-hidden">
                      <div className="bg-emerald-500 h-2 rounded-full" style={{ width: '96%' }}></div>
                    </div>
                    <span className="font-bold text-emerald-700">96.4%</span>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
