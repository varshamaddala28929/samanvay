import {
  Application,
  CitizenProfile,
  DocumentItem,
  Grievance,
  Role,
  ServiceCategory,
  ServiceItem,
  User,
} from '../types';

export interface EligibilityResponse {
  success: boolean;
  isEligible: boolean;
  ruleEvaluations: Array<{
    ruleId: string;
    description: string;
    passed: boolean;
    field: string;
    expected: any;
    actual: any;
    reason: string;
  }>;
  documentStatus: Array<{
    type: string;
    available: boolean;
    documentItem: DocumentItem | null;
  }>;
  availableCount: number;
  missingCount: number;
  totalRequired: number;
  service: ServiceItem;
  profile: CitizenProfile;
}

export const api = {
  // Authentication
  async login(identifier?: string, role?: Role): Promise<{ user: User; profile: CitizenProfile | null }> {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ identifier, role }),
    });
    const data = await res.json();
    return data;
  },

  async enrollScholarshipFace(identifier: string, descriptor: number[]): Promise<void> {
    const res = await fetch('/api/auth/face/enroll', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ identifier, descriptor }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Face enrollment unavailable');
  },

  async verifyScholarshipFace(identifier: string, descriptor: number[]): Promise<void> {
    const res = await fetch('/api/auth/face/verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ identifier, descriptor }),
    });
    const data = await res.json();
    if (!res.ok) {
      const error = new Error(data.error || 'Face not recognized. Please try again.') as Error & { status?: number };
      error.status = res.status;
      throw error;
    }
  },

  async signUp(payload: Partial<CitizenProfile> & { faceDescriptor?: number[] }): Promise<{ user: User; profile: CitizenProfile; citizenId: string }> {
    const res = await fetch('/api/auth/signup', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    return res.json();
  },

  // Profile
  async getProfile(citizenId: string): Promise<CitizenProfile> {
    const res = await fetch(`/api/profile/${citizenId}`);
    const data = await res.json();
    return data.profile;
  },

  async updateProfile(citizenId: string, profile: Partial<CitizenProfile>): Promise<CitizenProfile> {
    const res = await fetch(`/api/profile/${citizenId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(profile),
    });
    const data = await res.json();
    return data.profile;
  },

  // Services
  async getServices(): Promise<{ categories: ServiceCategory[]; services: ServiceItem[] }> {
    const res = await fetch('/api/services');
    return res.json();
  },

  async checkEligibility(serviceId: string, citizenId: string): Promise<EligibilityResponse> {
    const res = await fetch('/api/eligibility/check', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ serviceId, citizenId }),
    });
    return res.json();
  },

  // Documents
  async getDocuments(citizenId: string): Promise<DocumentItem[]> {
    const res = await fetch(`/api/documents/${citizenId}`);
    const data = await res.json();
    return data.documents || [];
  },

  async uploadDocument(doc: Partial<DocumentItem>): Promise<DocumentItem> {
    const res = await fetch('/api/documents/upload', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(doc),
    });
    const data = await res.json();
    return data.document;
  },

  async fetchDigiLockerDoc(citizenId: string, docType: string): Promise<DocumentItem> {
    const res = await fetch('/api/documents/mock-digilocker/fetch', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ citizenId, docType }),
    });
    const data = await res.json();
    return data.document;
  },

  async getDigiLockerVault(): Promise<any[]> {
    const res = await fetch('/api/documents/mock-digilocker/vault');
    const data = await res.json();
    return data.vault || [];
  },

  // Applications
  async getApplications(params?: { citizenId?: string; officerId?: string }): Promise<Application[]> {
    const query = new URLSearchParams();
    if (params?.citizenId) query.append('citizenId', params.citizenId);
    if (params?.officerId) query.append('officerId', params.officerId);

    const res = await fetch(`/api/applications?${query.toString()}`);
    const data = await res.json();
    return data.applications || [];
  },

  async submitApplication(serviceId: string, citizenId: string): Promise<Application> {
    const res = await fetch('/api/applications', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ serviceId, citizenId }),
    });
    const data = await res.json();
    return data.application;
  },

  async updateApplicationStatus(
    id: string,
    status: string,
    remarks?: string,
    actorName?: string,
    actorRole?: string
  ): Promise<Application> {
    const res = await fetch(`/api/applications/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status, remarks, actorName, actorRole }),
    });
    const data = await res.json();
    return data.application;
  },

  async escalateApplication(id: string, remarks?: string, actorName?: string): Promise<Application> {
    const res = await fetch(`/api/applications/${id}/escalate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ remarks, actorName }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Application escalation failed');
    return data.application;
  },

  // Grievances
  async getGrievances(params?: { citizenId?: string; officerId?: string }): Promise<Grievance[]> {
    const query = new URLSearchParams();
    if (params?.citizenId) query.append('citizenId', params.citizenId);
    if (params?.officerId) query.append('officerId', params.officerId);

    const res = await fetch(`/api/grievances?${query.toString()}`);
    const data = await res.json();
    return data.grievances || [];
  },

  async submitGrievance(payload: any): Promise<Grievance> {
    const res = await fetch('/api/grievances', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok) {
      const error = new Error(data.error || 'Complaint submission failed') as Error & { status?: number; existingGrievance?: Grievance };
      error.status = res.status;
      error.existingGrievance = data.existingGrievance;
      throw error;
    }
    if (!data.success || !data.grievance?.id) {
      throw new Error('Complaint submission returned an invalid success response');
    }
    return data.grievance;
  },

  async resetDemoGrievances(): Promise<void> {
    const res = await fetch('/api/grievances/demo/reset', { method: 'POST' });
    if (!res.ok) {
      throw new Error(`Complaint reset failed (${res.status})`);
    }
  },

  async updateGrievanceStatus(id: string, status: string, remarks?: string, actorName?: string): Promise<Grievance> {
    const res = await fetch(`/api/grievances/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status, remarks, actorName }),
    });
    const data = await res.json();
    return data.grievance;
  },

  async forwardGrievance(id: string, remarks?: string, actorName?: string): Promise<Grievance> {
    const res = await fetch(`/api/grievances/${id}/forward`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ remarks, actorName }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Grievance forwarding failed');
    return data.grievance;
  },

  async simulateSlaBreach(id: string): Promise<Grievance> {
    const res = await fetch(`/api/grievances/${id}/simulate-breach`, {
      method: 'POST',
    });
    const data = await res.json();
    return data.grievance;
  },

  async higherOfficerIntervene(id: string, action: 'RESOLVE' | 'DIRECTIVE', notes: string): Promise<Grievance> {
    const res = await fetch(`/api/grievances/${id}/higher-officer-intervention`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, notes }),
    });
    const data = await res.json();
    return data.grievance;
  },

  // Stats
  async getStats(): Promise<any> {
    const res = await fetch('/api/stats');
    return res.json();
  },

  // Voice Intent
  async parseVoiceIntent(transcript: string, language: string): Promise<any> {
    const res = await fetch('/api/voice/intent', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ transcript, language }),
    });
    const data = await res.json();
    return data.result;
  },

  // Reset Demo
  async resetDemo(): Promise<void> {
    await fetch('/api/demo/reset', { method: 'POST' });
  },
};
