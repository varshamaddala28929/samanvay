export type Role = 'CITIZEN' | 'OFFICER' | 'HIGHER_OFFICER';

export type Language = 'te' | 'en' | 'hi' | 'mr' | 'ta';

export interface User {
  id: string;
  role: Role;
  name: string;
  citizenId?: string; // e.g. "SMV-CIT-10245"
  officerId?: string; // e.g. "SMV-OFF-204"
  higherOfficerId?: string; // e.g. "SMV-HO-301"
  mobile: string;
  email?: string;
  department?: string;
  designation?: string;
  jurisdiction?: {
    state: string;
    district: string;
    mandal?: string;
  };
}

export interface CitizenProfile {
  id: string;
  citizenId: string;
  fullName: string;
  dateOfBirth: string; // YYYY-MM-DD
  age: number;
  gender: 'Female' | 'Male' | 'Other';
  mobile: string;
  email: string;
  address: string;
  state: string;
  district: string;
  mandal: string;
  pincode: string;
  educationLevel: 'High School' | 'Intermediate' | 'Undergraduate' | 'Postgraduate' | 'None';
  currentCourse?: string;
  marksPercentage?: number;
  annualFamilyIncome: number; // in INR
  socialCategory: 'General' | 'OBC' | 'SC' | 'ST' | 'EWS';
  occupation: string;
  disabilityStatus: boolean;
  rationCardNumber?: string;
  bankAccountLinked: boolean;
}

export interface DocumentItem {
  id: string;
  citizenId: string;
  type: DocumentType;
  title: string;
  documentNumber: string;
  issuer: string;
  issueDate: string;
  source: 'DIGILOCKER' | 'CAMERA_SCAN' | 'MANUAL_UPLOAD';
  verified: boolean;
  fileUrl?: string;
  extractedDetails?: Record<string, string | number>;
  uploadedAt: string;
}

export type DocumentType =
  | 'AADHAAR'
  | 'INCOME_CERTIFICATE'
  | 'CASTE_CERTIFICATE'
  | 'MARKS_MEMO'
  | 'RESIDENCE_CERTIFICATE'
  | 'RATION_CARD'
  | 'DISABILITY_CERTIFICATE'
  | 'BONAFIDE_CERTIFICATE';

export interface ServiceCategory {
  id: string;
  titleKey: string;
  iconName: string;
  descriptionKey: string;
}

export interface EligibilityRule {
  id: string;
  field: keyof CitizenProfile;
  operator: 'gte' | 'lte' | 'eq' | 'in';
  value: any;
  description: string;
}

export interface ServiceItem {
  id: string;
  categoryId: string;
  title: string;
  department: string;
  shortDescription: string;
  benefits: string;
  applicationDeadline: string;
  processingTimeDays: number;
  eligibilityRules: EligibilityRule[];
  requiredDocumentTypes: DocumentType[];
  tags: string[];
}

export type ApplicationStatus =
  | 'SUBMITTED'
  | 'UNDER_VERIFICATION'
  | 'DOCUMENTS_REQUIRED'
  | 'ESCALATED'
  | 'OFFICER_ASSIGNED'
  | 'APPROVED'
  | 'REJECTED'
  | 'BENEFIT_DISBURSED';

export interface ApplicationTimelineEvent {
  status: ApplicationStatus;
  timestamp: string;
  actor: string;
  remarks?: string;
}

export interface Application {
  id: string; // e.g. "SMV-APP-2026-0001"
  serviceId: string;
  serviceTitle: string;
  department: string;
  citizenId: string;
  citizenName: string;
  citizenMobile: string;
  citizenIncome: number;
  citizenCategory: string;
  citizenDistrict: string;
  citizenMandal: string;
  submittedAt: string;
  status: ApplicationStatus;
  assignedOfficerId?: string;
  assignedOfficerName?: string;
  attachedDocumentIds: string[];
  timeline: ApplicationTimelineEvent[];
  officerRemarks?: string;
  benefitDetails?: string;
  updatedAt: string;
}

export type GrievanceStatus =
  | 'SUBMITTED'
  | 'RECEIVED'
  | 'ASSIGNED'
  | 'ASSIGNED'
  | 'IN_PROGRESS'
  | 'RESOLVED'
  | 'REJECTED'
  | 'ESCALATED';

export interface GrievanceTimelineEvent {
  status: GrievanceStatus;
  timestamp: string;
  actor: string;
  remarks?: string;
}

export interface Grievance {
  id: string; // e.g. "SMV-GRV-2026-0001"
  followUpReference?: string;
  citizenId: string;
  citizenName: string;
  citizenMobile: string;
  category: string;
  issueType: string;
  description: string;
  voiceNoteUrl?: string;
  photoUrl?: string;
  location: {
    state: string;
    district: string;
    mandal: string;
    landmark?: string;
    coordinates?: {
      latitude: number;
      longitude: number;
    };
  };
  routedDepartment: string;
  assignedOfficerId: string;
  assignedOfficerName: string;
  status: GrievanceStatus;
  slaDays: number;
  slaDueDate: string;
  isSlaBreached: boolean;
  escalationLevel?: 'NONE' | 'DISTRICT_COLLECTOR' | 'STATE_SECRETARY' | 'HIGHER_OFFICER';
  escalationReason?: string;
  timeline: GrievanceTimelineEvent[];
  officerRemarks?: string;
  higherOfficerNotes?: string;
  submittedAt: string;
  updatedAt: string;
}

export interface DepartmentStat {
  department: string;
  totalApplications: number;
  approvedApplications: number;
  pendingApplications: number;
  totalGrievances: number;
  resolvedGrievances: number;
  slaBreaches: number;
  avgResolutionDays: number;
}
