import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  useRef,
  ReactNode,
} from 'react';
import {
  Application,
  CitizenProfile,
  DocumentItem,
  Grievance,
  Language,
  Role,
  ServiceCategory,
  ServiceItem,
  User,
} from '../types';
import { TRANSLATIONS } from '../i18n/translations';
import { api } from '../services/api';
import { INITIAL_USERS } from '../data/initialData';

interface ToastNotification {
  id: string;
  type: 'success' | 'info' | 'warning' | 'error';
  title: string;
  message: string;
  timestamp: Date;
}

interface AppContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string, fallback?: string) => string;
  
  // Authentication & Session
  isAuthenticated: boolean;
  setIsAuthenticated: (auth: boolean) => void;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  loginUser: (identifier?: string, role?: Role) => Promise<boolean>;
  signUpUser: (data: Partial<CitizenProfile>) => Promise<boolean>;
  loginWithDigiLocker: () => Promise<boolean>;
  logout: () => void;

  currentUser: User;
  activeRole: Role;
  setCurrentUser: (user: User) => void;
  switchRole: (role: Role, desk?: DemoDesk) => Promise<void>;
  demoDesk: DemoDesk;
  
  profile: CitizenProfile | null;
  setProfile: React.Dispatch<React.SetStateAction<CitizenProfile | null>>;
  refreshProfile: () => Promise<void>;
  
  categories: ServiceCategory[];
  services: ServiceItem[];
  
  applications: Application[];
  grievances: Grievance[];
  documents: DocumentItem[];
  
  refreshAllData: () => Promise<void>;
  
  // Navigation
  activeTab: 'HOME' | 'SERVICES' | 'GRIEVANCES' | 'MY_APPLICATIONS' | 'MY_GRIEVANCES' | 'PROFILE' | 'OFFICER_DESK' | 'HIGHER_OFFICER_DESK';
  setActiveTab: (tab: any) => void;
  
  // Modals & Triggers
  selectedService: ServiceItem | null;
  setSelectedService: (s: ServiceItem | null) => void;
  isVoiceModalOpen: boolean;
  setIsVoiceModalOpen: (open: boolean) => void;
  isLiveDemoModalOpen: boolean;
  setIsLiveDemoModalOpen: (open: boolean) => void;
  isDigiLockerModalOpen: boolean;
  setIsDigiLockerModalOpen: (open: boolean) => void;
  isCameraModalOpen: boolean;
  setIsCameraModalOpen: (open: boolean) => void;
  cameraTargetDocType: string | null;
  setCameraTargetDocType: (docType: string | null) => void;
  
  // Notifications
  notifications: ToastNotification[];
  dismissNotification: (id: string) => void;
  addNotification: (type: 'success' | 'info' | 'warning' | 'error', title: string, message: string) => void;
  
  // Demo Helpers
  isRealTimeConnected: boolean;
  resetDemoData: () => Promise<void>;
  resetDemoGrievances: () => Promise<void>;
}

export type DemoDesk = 'CITIZEN' | 'PUBLIC_SERVICES' | 'PUBLIC_SERVICES_HIGHER' | 'GRIEVANCES' | 'GRIEVANCES_HIGHER';

const getDefaultDemoDesk = (): DemoDesk => {
  if (typeof window !== 'undefined') {
    const saved = localStorage.getItem('samanvay_demo_desk') as DemoDesk | null;
    if (saved) return saved;
  }
  return 'CITIZEN';
};

const AppContext = createContext<AppContextType | undefined>(undefined);

const broadcast = typeof window !== 'undefined' && 'BroadcastChannel' in window ? new BroadcastChannel('samanvay_sync') : null;

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    return (localStorage.getItem('samanvay_lang') as Language) || 'te';
  });

  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    const saved = localStorage.getItem('samanvay_auth');
    if (saved === 'true') return true;
    return false;
  });
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  const [currentUser, setCurrentUserState] = useState<User>(() => {
    const saved = localStorage.getItem('samanvay_auth_user');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return INITIAL_USERS[0];
      }
    }
    return INITIAL_USERS[0];
  });
  const [activeRole, setActiveRole] = useState<Role>(() => currentUser.role || 'CITIZEN');
  const [demoDesk, setDemoDesk] = useState<DemoDesk>(getDefaultDemoDesk);
  const [profile, setProfile] = useState<CitizenProfile | null>(null);

  const [categories, setCategories] = useState<ServiceCategory[]>([]);
  const [services, setServices] = useState<ServiceItem[]>([]);
  const [applications, setApplications] = useState<Application[]>([]);
  const [grievances, setGrievances] = useState<Grievance[]>([]);
  const grievanceRefreshVersion = useRef(0);
  const [documents, setDocuments] = useState<DocumentItem[]>([]);

  const [activeTab, setActiveTab] = useState<any>('HOME');
  const [selectedService, setSelectedService] = useState<ServiceItem | null>(null);

  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState(false);
  const [isLiveDemoModalOpen, setIsLiveDemoModalOpen] = useState(false);
  const [isDigiLockerModalOpen, setIsDigiLockerModalOpen] = useState(false);
  const [isCameraModalOpen, setIsCameraModalOpen] = useState(false);
  const [cameraTargetDocType, setCameraTargetDocType] = useState<string | null>(null);

  const [notifications, setNotifications] = useState<ToastNotification[]>([]);
  const [isRealTimeConnected, setIsRealTimeConnected] = useState(false);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('samanvay_lang', lang);
  };

  const t = useCallback(
    (key: string, fallback?: string): string => {
      const dict = TRANSLATIONS[language] || TRANSLATIONS.en;
      return dict[key] || TRANSLATIONS.en[key] || fallback || key;
    },
    [language]
  );

  const addNotification = useCallback((type: 'success' | 'info' | 'warning' | 'error', title: string, message: string) => {
    const newNotif: ToastNotification = {
      id: `notif_${Date.now()}_${Math.random()}`,
      type,
      title,
      message,
      timestamp: new Date(),
    };
    setNotifications((prev) => [newNotif, ...prev.slice(0, 5)]);

    setTimeout(() => {
      setNotifications((prev) => prev.filter((n) => n.id !== newNotif.id));
    }, 6000);
  }, []);

  const dismissNotification = (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  };

  const refreshProfile = useCallback(async () => {
    if (!isAuthenticated) {
      setProfile(null);
      return;
    }

    if (currentUser.citizenId) {
      try {
        const prof = await api.getProfile(currentUser.citizenId);
        setProfile(prof);
      } catch (err) {
        console.error('Failed to load profile:', err);
      }
    }
  }, [currentUser.citizenId, isAuthenticated]);

  const refreshAllData = useCallback(async () => {
    const requestVersion = grievanceRefreshVersion.current;
    if (!isAuthenticated) {
      try {
        const [srvRes, publicGrievances] = await Promise.all([
          api.getServices(),
          api.getGrievances({ citizenId: currentUser.citizenId || 'SMV-CIT-10245' }),
        ]);
        setCategories(srvRes.categories || []);
        setServices(srvRes.services || []);
        setApplications([]);
        if (requestVersion === grievanceRefreshVersion.current) setGrievances(publicGrievances || []);
        setDocuments([]);
      } catch (err) {
        console.error('Error fetching public services:', err);
        setCategories([]);
        setServices([]);
        setApplications([]);
        setGrievances([]);
        setDocuments([]);
      }
      return;
    }

    try {
      const [srvRes, apps, grvs, docs] = await Promise.all([
        api.getServices(),
        api.getApplications(
          activeRole === 'CITIZEN'
            ? { citizenId: currentUser.citizenId }
            : activeRole === 'OFFICER'
            ? { officerId: currentUser.officerId }
            : {}
        ),
        api.getGrievances(
          activeRole === 'CITIZEN'
            ? { citizenId: currentUser.citizenId }
            : activeRole === 'OFFICER'
            ? { officerId: currentUser.officerId }
            : {}
        ),
        currentUser.citizenId ? api.getDocuments(currentUser.citizenId) : Promise.resolve([]),
      ]);

      setCategories(srvRes.categories || []);
      setServices(srvRes.services || []);
      setApplications(apps || []);
      if (requestVersion === grievanceRefreshVersion.current) setGrievances(grvs || []);
      setDocuments(docs || []);
    } catch (err) {
      console.error('Error fetching Samanvay data:', err);
    }
  }, [activeRole, currentUser.citizenId, isAuthenticated]);

  const loginUser = async (identifier?: string, role?: Role): Promise<boolean> => {
    try {
      const res = await api.login(identifier, role);
      if (res && res.user) {
        setCurrentUserState(res.user);
        setActiveRole(res.user.role);
        setIsAuthenticated(true);
        setIsAuthModalOpen(false);
        localStorage.setItem('samanvay_auth', 'true');
        localStorage.setItem('samanvay_auth_user', JSON.stringify(res.user));

        if (res.user.role === 'CITIZEN') {
          setActiveTab('HOME');
          if (res.profile) {
            setProfile(res.profile);
          } else if (res.user.citizenId) {
            const prof = await api.getProfile(res.user.citizenId);
            setProfile(prof);
          }
        } else if (res.user.role === 'OFFICER') {
          setActiveTab('OFFICER_DESK');
        } else if (res.user.role === 'HIGHER_OFFICER') {
          setActiveTab('HIGHER_OFFICER_DESK');
        }

        await refreshAllData();
        addNotification('success', 'Logged in Successfully', `Welcome to Samanvay, ${res.user.name}`);
        return true;
      }
      return false;
    } catch (err) {
      console.error('Login error:', err);
      return false;
    }
  };

  const signUpUser = async (payload: Partial<CitizenProfile>): Promise<boolean> => {
    try {
      const res = await api.signUp(payload);
      if (res && res.user) {
        setCurrentUserState(res.user);
        setActiveRole('CITIZEN');
        setProfile(res.profile);
        setIsAuthenticated(true);
        setIsAuthModalOpen(false);
        localStorage.setItem('samanvay_auth', 'true');
        localStorage.setItem('samanvay_auth_user', JSON.stringify(res.user));
        setActiveTab('HOME');
        await refreshAllData();
        addNotification('success', 'Citizen Account Created', `Welcome to Samanvay, ${res.user.name}. Citizen ID: ${res.citizenId}`);
        return true;
      }
      return false;
    } catch (err) {
      console.error('Signup error:', err);
      return false;
    }
  };

  const loginWithDigiLocker = async (): Promise<boolean> => {
    try {
      // Connect to DigiLocker and authenticate as verified citizen with instant pre-fetched records
      const res = await api.login('SMV-CIT-10245', 'CITIZEN');
      if (res && res.user) {
        setCurrentUserState(res.user);
        setActiveRole('CITIZEN');
        setIsAuthenticated(true);
        setIsAuthModalOpen(false);
        localStorage.setItem('samanvay_auth', 'true');
        localStorage.setItem('samanvay_auth_user', JSON.stringify(res.user));
        setActiveTab('HOME');
        if (res.profile) setProfile(res.profile);
        await refreshAllData();
        addNotification('success', 'DigiLocker Connected', 'Authenticated via DigiLocker with verified government records.');
        return true;
      }
      return false;
    } catch (err) {
      console.error('DigiLocker auth error:', err);
      return false;
    }
  };

  const logout = () => {
    setIsAuthenticated(false);
    setCurrentUserState(INITIAL_USERS[0]);
    setActiveRole('CITIZEN');
    setProfile(null);
    setCategories([]);
    setServices([]);
    setApplications([]);
    setGrievances([]);
    setDocuments([]);
    setSelectedService(null);
    setActiveTab('HOME');
    localStorage.removeItem('samanvay_auth');
    localStorage.removeItem('samanvay_auth_user');
    localStorage.removeItem('samanvay_scholarship_face_verified_at');
    addNotification('info', 'Logged Out', 'Your session has been securely ended.');
  };

  const switchRole = async (newRole: Role, desk: DemoDesk = newRole === 'CITIZEN' ? 'CITIZEN' : newRole === 'OFFICER' ? 'PUBLIC_SERVICES' : 'PUBLIC_SERVICES_HIGHER') => {
    setActiveRole(newRole);
    setDemoDesk(desk);
    localStorage.setItem('samanvay_demo_desk', desk);
    const matchedUser = INITIAL_USERS.find((u) => u.role === newRole) || INITIAL_USERS[0];
    setCurrentUserState(matchedUser);
    setIsAuthenticated(true);
    setIsAuthModalOpen(false);
    localStorage.setItem('samanvay_auth', 'true');
    localStorage.setItem('samanvay_auth_user', JSON.stringify(matchedUser));

    if (newRole === 'CITIZEN') {
      setActiveTab('HOME');
      if (matchedUser.citizenId) {
        const prof = await api.getProfile(matchedUser.citizenId);
        setProfile(prof);
      }
    } else if (newRole === 'OFFICER') {
      setActiveTab('OFFICER_DESK');
    } else if (newRole === 'HIGHER_OFFICER') {
      setActiveTab('HIGHER_OFFICER_DESK');
    }

    addNotification(
      'info',
      t('activeRole'),
      `${t('welcomeBack')}, ${matchedUser.name} (${newRole === 'CITIZEN' ? 'Citizen' : newRole === 'OFFICER' ? 'Officer' : 'Higher Authority'})`
    );
  };

  // Initial Load
  useEffect(() => {
    refreshAllData();
    refreshProfile();
  }, [refreshAllData, refreshProfile]);

  // Server-Sent Events (SSE) for Real-Time Cross-Device Live Sync
  useEffect(() => {
    let eventSource: EventSource | null = null;

    try {
      eventSource = new EventSource('/api/events');

      eventSource.onopen = () => {
        setIsRealTimeConnected(true);
      };

      eventSource.addEventListener('init', () => {
        setIsRealTimeConnected(true);
      });

      eventSource.addEventListener('APPLICATION_CREATED', (e) => {
        const payload = JSON.parse(e.data);
        refreshAllData();
        addNotification('info', 'New Application Submitted', `${payload.application.serviceTitle} (${payload.application.id})`);
        if (broadcast) broadcast.postMessage({ type: 'SYNC' });
      });

      eventSource.addEventListener('APPLICATION_UPDATED', (e) => {
        const payload = JSON.parse(e.data);
        refreshAllData();
        addNotification(
          payload.application.status === 'APPROVED' ? 'success' : 'info',
          `Application ${payload.application.status}`,
          `${payload.application.serviceTitle} — ${payload.application.officerRemarks || ''}`
        );
        if (broadcast) broadcast.postMessage({ type: 'SYNC' });
      });

      eventSource.addEventListener('GRIEVANCE_CREATED', (e) => {
        const payload = JSON.parse(e.data);
        refreshAllData();
        addNotification('info', 'New Grievance Registered', `${payload.grievance.issueType} (${payload.grievance.id})`);
        if (broadcast) broadcast.postMessage({ type: 'SYNC' });
      });

      eventSource.addEventListener('GRIEVANCE_UPDATED', (e) => {
        const payload = JSON.parse(e.data);
        refreshAllData();
        addNotification(
          payload.grievance.status === 'RESOLVED' ? 'success' : 'info',
          `Grievance ${payload.grievance.status}`,
          `${payload.grievance.id}: ${payload.grievance.officerRemarks || payload.grievance.higherOfficerNotes || ''}`
        );
        if (broadcast) broadcast.postMessage({ type: 'SYNC' });
      });

      eventSource.addEventListener('GRIEVANCE_ESCALATED', (e) => {
        const payload = JSON.parse(e.data);
        refreshAllData();
        addNotification(
          'warning',
          'SLA Breached & Escalated',
          `Grievance ${payload.grievance.id} has been escalated to Higher Officer.`
        );
        if (broadcast) broadcast.postMessage({ type: 'SYNC' });
      });

      eventSource.addEventListener('DOCUMENT_ADDED', () => {
        refreshAllData();
        refreshProfile();
      });

      eventSource.addEventListener('STATE_RESET', () => {
        refreshAllData();
        refreshProfile();
        addNotification('info', 'System Reset', 'Demo data re-seeded to initial state.');
      });

      eventSource.onerror = () => {
        setIsRealTimeConnected(false);
      };
    } catch (err) {
      console.warn('SSE Error:', err);
    }

    if (broadcast) {
      broadcast.onmessage = () => {
        refreshAllData();
      };
    }

    // Polling fallback every 6 seconds to ensure ultra-robust multi-tab sync
    const pollInterval = setInterval(() => {
      refreshAllData();
    }, 6000);

    return () => {
      if (eventSource) eventSource.close();
      clearInterval(pollInterval);
    };
  }, [refreshAllData, refreshProfile, addNotification]);

  const resetDemoData = async () => {
    await api.resetDemo();
    await refreshAllData();
    await refreshProfile();
  };

  const resetDemoGrievances = async () => {
    grievanceRefreshVersion.current += 1;
    await api.resetDemoGrievances();
    const complaintKeys = [
      'samanvay_demo_grievances',
      'samanvay_grievances',
      'samanvay_selected_grievance',
      'samanvay_complaint_status',
      'samanvay_complaint_timeline',
    ];
    complaintKeys.forEach((key) => {
      localStorage.removeItem(key);
      sessionStorage.removeItem(key);
    });
    setGrievances([]);
  };

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        t,
        isAuthenticated,
        setIsAuthenticated,
        isAuthModalOpen,
        setIsAuthModalOpen,
        loginUser,
        signUpUser,
        loginWithDigiLocker,
        logout,
        currentUser,
        activeRole,
        demoDesk,
        setCurrentUser: setCurrentUserState,
        switchRole,
        profile,
        setProfile,
        refreshProfile,
        categories,
        services,
        applications,
        grievances,
        documents,
        refreshAllData,
        activeTab,
        setActiveTab,
        selectedService,
        setSelectedService,
        isVoiceModalOpen,
        setIsVoiceModalOpen,
        isLiveDemoModalOpen,
        setIsLiveDemoModalOpen,
        isDigiLockerModalOpen,
        setIsDigiLockerModalOpen,
        isCameraModalOpen,
        setIsCameraModalOpen,
        cameraTargetDocType,
        setCameraTargetDocType,
        notifications,
        dismissNotification,
        addNotification,
        isRealTimeConnected,
        resetDemoData,
        resetDemoGrievances,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
